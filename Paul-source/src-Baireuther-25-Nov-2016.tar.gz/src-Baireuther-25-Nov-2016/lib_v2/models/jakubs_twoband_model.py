
#!/usr/bin/env python
# Filename franz_model.py 

import use_lib_v2; use_lib_v2.init()

# libraries
import numpy as np
from numpy import sin as sin
from numpy import cos as cos
from numpy import pi as PI
import kwant

# my libraries
from paulimatrices import *
from memory import SimpleNamespace
from memory import get_var

""" 
TABLE OF CONTENTS

Twoband
"""


"""Twoband is Jakubs two-band model which is - up to O(b_0^3) -
equivalent to the Franz model arXiv:1303.5784. The x-dimension is
discretized on a 1D tight binding chain. In y- and z-direction we
assume periodic boundary conditions. This makes ky,kz good quantum
numbers.

"""
class Twoband_1D(object):

    def __init__( self,params=None ):
	self.type = 'Jakubs two-band model -- on 1D lattice in x'
	self.dimension = 1
	self.lat = kwant.lattice.general( ( (1,), ) )
	self.params = params


    def hop( self,pos1,pos2,p ):
		
	# verify that the hopping is acutally a hopping
	tolerance = 10**(-6)
	direction = [ pos2[d]-pos1[d] for d in range(self.dimension) ]
	distance2 = sum( [ dis**2 for dis in direction ] )
	if abs(distance2)<tolerance:
	    raise ValueError( "The hopping must have a finite distance" )

	x, = pos1
	tp =get_var(self.params,p,'tp')
	tz =get_var(self.params,p,'tz')
	t  =get_var(self.params,p,'t')
	mu =get_var(self.params,p,'mu')
	ky =get_var(self.params,p,'ky')
	kz =get_var(self.params,p,'kz')
	b0 =get_var(self.params,p,'b0')
	alpha =get_var(self.params,p,'alpha')
	nu  =get_var(self.params,p,'nu')
	
	if abs( distance2-direction[0]**2 )<tolerance:

	    sinkz = np.sin(kz); coskz = np.cos(kz)
	    sinky = np.sin(ky); cosky = np.cos(ky)
	    mu0 = mu-t*(1+cosky+coskz)
	    lam0 = np.sqrt( mu0**2 + (tz*sinkz)**2 )
	    hop0 = -0.5j*tp/alpha *sigma1 - 0.5*nu*t*mu0/lam0/alpha**2 *sigma3
	    hop1 = -0.5*b0/2. *tz*sinkz/lam0 *t*mu0/lam0**2 /alpha**2 *sigma0
	    return hop0+hop1
	else:
	    raise ValueError( "The hopping in " + str(direction) + " is not part of the model" )


    def onsite( self, pos, p ):

	(x,) = pos

	tp   =get_var(self.params,p,'tp')
	tz   =get_var(self.params,p,'tz')
	t    =get_var(self.params,p,'t')
	mu   =get_var(self.params,p,'mu')
	ky   =get_var(self.params,p,'ky')
	kz   =get_var(self.params,p,'kz')
	lBinv2=get_var(self.params,p,'lBinv2')
	b0   =get_var(self.params,p,'b0')
	bz   =get_var(self.params,p,'bz')

	alpha =get_var(self.params,p,'alpha')
	nu    =get_var(self.params,p,'nu')

	sinkz = np.sin(kz); coskz = np.cos(kz)
	sinky = np.sin(ky); cosky = np.cos(ky)
	mu0   = mu-t*(1+cosky+coskz)
	lam0  = np.sqrt( mu0**2 + (tz*sinkz)**2 )
	ky_p  = ky + 2.*PI*lBinv2*float(x)

	onsite0 = tp*sin(ky_p) *sigma2 + (bz/2. + nu*lam0 + nu*t*mu0/lam0/alpha**2) *sigma3
	onsite1 = -b0/2.*tz*sinkz/lam0 *(1 - t*mu0/lam0**2/alpha**2) *sigma0
	return onsite0 + onsite1




	
"""Twoband is Jakubs two-band model which is - up to O(b_0^3) -
equivalent to the Franz model arXiv:1303.5784. The x- and y-directions
are discretized on a 1D tight binding chain. In z-direction we assume
periodic boundary conditions. This makes kz a good quantum number.

"""
class Twoband_2D(object):

    def __init__( self,params=None ):
	self.type = 'Jakubs two-band model -- on 2D lattice in x,y'
	self.dimension = 2
	self.lat = kwant.lattice.general( ((1,0),(0,1)) )
	self.params = params

	
    def hop( self,pos1,pos2,p ):
		
	# verify that the hopping is acutally a hopping
	tolerance = 10**(-6)
	direction = [ pos2[d]-pos1[d] for d in range(self.dimension) ]
	distance2 = sum( [ dis**2 for dis in direction ] )
	if abs(distance2)<tolerance:
	    raise ValueError( "The hopping must have a finite distance" )

	x,y = pos1
	tp =get_var(self.params,p,'tp')
	tz =get_var(self.params,p,'tz')
	t  =get_var(self.params,p,'t')
	mu =get_var(self.params,p,'mu')
	kz =get_var(self.params,p,'kz')
	b0 =get_var(self.params,p,'b0')
	nu  =get_var(self.params,p,'nu')
	alpha =get_var(self.params,p,'alpha')

	# precalculate
	sinkz = np.sin(kz); coskz = np.cos(kz)
	mu0 = mu-t*(2+coskz)
	lam0 = np.sqrt( mu0**2 + (tz*sinkz)**2 )
		
	if abs( distance2-direction[0]**2 )<tolerance:
	    
	    hop0 = -0.5j *tp *sigma1 - 0.5*nu *t*mu0/lam0 *sigma3
	    hop1 = -0.5  *b0 *tz*sinkz/lam0 *t*mu0/lam0**2 *sigma0
	    return hop0+hop1
	elif abs( distance2-direction[1]**2 )<tolerance:
	    hop0 = -0.5j *tp *sigma2 - 0.5*nu *t*mu0/lam0 *sigma3
	    hop1 = -0.5  *b0 *tz*sinkz/lam0 *t*mu0/lam0**2 *sigma0
	    return hop0+hop1
	else:
	    raise ValueError( "The hopping in " + str(direction) + " is not part of the model" )


    def onsite( self, pos, p ):

	(x,y) = pos
	tp   =get_var(self.params,p,'tp')
	tz   =get_var(self.params,p,'tz')
	t    =get_var(self.params,p,'t')
	mu   =get_var(self.params,p,'mu')
	kz   =get_var(self.params,p,'kz')
	b0   =get_var(self.params,p,'b0')
	bz   =get_var(self.params,p,'bz')
	nu    =get_var(self.params,p,'nu')
	alpha =get_var(self.params,p,'alpha')

	# precalculate
	sinkz = np.sin(kz); coskz = np.cos(kz)
	mu0   = mu-t*(2+coskz)
	lam0  = np.sqrt( mu0**2 + (tz*sinkz)**2 )

	onsite0 = (bz + nu*lam0 + nu*2*t*mu0/lam0) *sigma3
	onsite1 = -b0*tz*sinkz/lam0 * (1 - 2*t*mu0/lam0**2) *sigma0
	return onsite0+onsite1




	
