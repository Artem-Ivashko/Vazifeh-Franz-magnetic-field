#!/usr/bin/env python
# Filename standard_models.py

# libraries
from __future__ import division
import numpy as np
import kwant

""" 
TABLE OF CONTENTS

ElectronGas
"""

"""ElectronGas is the parent class for all n-dimensional electron
gases. It contains all the hoppings and onsite energies.

Input
-----
dimension -- the dimension of the model

"""
class ElectronGas(object):

	def __init__(self, dimension):
		self.type = 'electron-gas base class'
		self.dimension=dimension

	def onsite( self, pos, p ):
		return -p.mu*s0s0
	
	def hop( self,pos1,pos2,p ):

		# verify that the hopping is acutally a hopping
		tolerance = 10**(-6)
		direction=[]
		for d in range(self.dimension):
			direction.append(pos2[d]-pos1[d])
		distance2 = sum( [ dis**2 for dis in direction ] )
		if abs(distance2)<tolerance:
			raise ValueError( "The hopping must have a finite distance" )

		return -p.t*s0s0
