#!/usr/bin/env python
# Filename weyl_SC.py 

# libraries
import numpy as np
from numpy import pi as PI
import kwant

# my libraries
from paulimatrices import *
from memory import SimpleNamespace
from memory import get_var


""" Base class for metallic superconductors with local pairing """
class MetallicSC(object):

    def __init__( self,params=None ):
	self.type = 'Metallic superconductor'
	self.params = params

    _tolerance = 10**(-6)

    # hoppings        
    def _hop_x( self,p ):
        met_tx =get_var(self.params,p,'met_tx')
        alpha  =get_var(self.params,p,'alpha')
        return -0.5*met_tx/alpha**2 *sigma_0
    def _hop_y( self,p ):
        met_ty =get_var(self.params,p,'met_ty')
        alpha  =get_var(self.params,p,'alpha')
        return -0.5*met_ty/alpha**2 *sigma_0
    def _hop_z( self,p ):
        met_tz =get_var(self.params,p,'met_tz')
        alpha  =get_var(self.params,p,'alpha')
        return -0.5*met_tz/alpha**2 *sigma_0

    # onsite energies
    def _onsite( self,p ):
        tx =get_var(self.params,p,'met_tx')
        ty =get_var(self.params,p,'met_ty')
        tz =get_var(self.params,p,'met_tz')
        met_mu =get_var(self.params,p,'met_mu')
        alpha  =get_var(self.params,p,'alpha')
        return ( (tx+ty+tz)/alpha**2 -met_mu )*sigma_0
    def _x_term( self,p ):
        tx    =get_var(self.params,p,'met_tx')
        kx    =get_var(self.params,p,'kx')
        alpha =get_var(self.params,p,'alpha')
        return -tx*np.cos(kx)/alpha**2 *sigma_0
    def _y_term( self,p ):
        ty  =get_var(self.params,p,'met_ty')
        ky   =get_var(self.params,p,'ky')
        alpha =get_var(self.params,p,'alpha')
        return -ty*np.cos(ky)/alpha**2 *sigma_0
    def _z_term( self,p ):
        tz =get_var(self.params,p,'met_tz')
        kz     =get_var(self.params,p,'kz')
        alpha =get_var(self.params,p,'alpha')
        return -tz*np.cos(kz)/alpha**2 *sigma_0
    
    # pairing (is also a hopping between electron and hole lattice)
    def pairing( self,site2,site1,p ):
        pos1=site1.pos; pos2=site2.pos
        if pos1!=pos2: raise ValueError("Pairing must be local")
        met_D =get_var(self.params,p,'met_D')
        return met_D*sigma_0

    

class MetallicSC1D_x(MetallicSC):

    def __init__( self,params=None ):
	self.type = '1D metallic superconductor in x-direction'
	self.dimension= 1
	self.lat_e = kwant.lattice.general( ( (1,), ), name='e' )
        self.lat_h = kwant.lattice.general( ( (1,), ), name='h' )
	self.params = params

    # hoppings
    def hop_e( self,site2,site1,p ):
        pos1=site1.pos; pos2=site2.pos
 	direction = [ pos2[d]-pos1[d] for d in range(self.dimension) ]
        distance2 = sum( [ dis**2 for dis in direction ] )
	if abs( distance2-direction[0]**2 )<self._tolerance:
            return self._hop_x(p)
	else:
	    raise ValueError( "The hopping in " + str(direction) + " is not part of the model" )

    def hop_h( self,site2,site1,p ):
        return -self.hop_e( site2,site1,p )
            
    def onsite_e( self, site, p ):
        return self._onsite(p) + self._y_term(p) + self._z_term(p)

    def onsite_h( self, site, p ):
        return -self.onsite_e( site,p )


class MetallicSC1D_y(MetallicSC):

    def __init__( self,params=None ):
	self.type = '1D metallic superconductor in y-direction'
	self.dimension= 1
	self.lat_e = kwant.lattice.general( ( (1,), ), name='e' )
        self.lat_h = kwant.lattice.general( ( (1,), ), name='h' )
	self.params = params

    # hoppings
    def hop_e( self,site2,site1,p ):
        pos1=site1.pos; pos2=site2.pos
 	direction = [ pos2[d]-pos1[d] for d in range(self.dimension) ]
        distance2 = sum( [ dis**2 for dis in direction ] )
	if abs( distance2-direction[0]**2 )<self._tolerance:
            return self._hop_y(p)
	else:
	    raise ValueError( "The hopping in " + str(direction) + " is not part of the model" )

    def hop_h( self,site2,site1,p ):
        return -self.hop_e( site2,site1,p )
            
    def onsite_e( self, site, p ):
        return self._onsite(p) + self._x_term(p) + self._z_term(p)

    def onsite_h( self, site, p ):
        return -self.onsite_e( site,p )

    
    
class MetallicSC1D_z(MetallicSC):

    def __init__( self,params=None ):
	self.type = '1D metallic superconductor in z-direction'
	self.dimension= 1
	self.lat_e = kwant.lattice.general( ( (1,), ), name='e' )
        self.lat_h = kwant.lattice.general( ( (1,), ), name='h' )
	self.params = params

    # hoppings
    def hop_e( self,site2,site1,p ):
        pos1=site1.pos; pos2=site2.pos
 	direction = [ pos2[d]-pos1[d] for d in range(self.dimension) ]
        distance2 = sum( [ dis**2 for dis in direction ] )
	if abs( distance2-direction[0]**2 )<self._tolerance:
            return self._hop_z(p)
	else:
	    raise ValueError( "The hopping in " + str(direction) + " is not part of the model" )

    def hop_h( self,site2,site1,p ):
        return -self.hop_e(site2,site1,p)
        
    def onsite_e( self, site, p ):
        return self._onsite(p) + self._x_term(p) + self._y_term(p)

    def onsite_h( self, site, p ):
        return -self.onsite_e( site,p )


class MetallicSC2D_xy(MetallicSC):

    def __init__( self,params=None ):
	self.type = '2D metallic superconductor in xy-direction'
	self.dimension= 2
	self.lat_e = kwant.lattice.general( ( (1,0),(0,1) ), name='e' )
        self.lat_h = kwant.lattice.general( ( (1,0),(0,1) ), name='h' )
	self.params = params

    # hoppings
    def hop_e( self,site2,site1,p ):
        pos1=site1.pos; pos2=site2.pos
 	direction = [ pos2[d]-pos1[d] for d in range(self.dimension) ]
        distance2 = sum( [ dis**2 for dis in direction ] )
	if abs( distance2-direction[0]**2 )<self._tolerance:
            return self._hop_x(p)
        elif abs( distance2-direction[1]**2 )<self._tolerance:
            return self._hop_y(p)
	else:
	    raise ValueError( "The hopping in " + str(direction) + " is not part of the model" )

    def hop_h( self,site2,site1,p ):
        return -self.hop_e(site2,site1,p)
        
    def onsite_e( self, site, p ):
        return self._onsite(p) + self._z_term(p)

    def onsite_h( self, site, p ):
        return -self.onsite_e( site,p )
    

class MetallicSC2D_xz(MetallicSC):

    def __init__( self,params=None ):
	self.type = '2D metallic superconductor in xz-direction'
	self.dimension= 2
	self.lat_e = kwant.lattice.general( ( (1,0),(0,1) ), name='e' )
        self.lat_h = kwant.lattice.general( ( (1,0),(0,1) ), name='h' )
	self.params = params

    # hoppings
    def hop_e( self,site2,site1,p ):
        pos1=site1.pos; pos2=site2.pos
 	direction = [ pos2[d]-pos1[d] for d in range(self.dimension) ]
        distance2 = sum( [ dis**2 for dis in direction ] )
	if abs( distance2-direction[0]**2 )<self._tolerance:
            return self._hop_x(p)
        elif abs( distance2-direction[1]**2 )<self._tolerance:
            return self._hop_z(p)
	else:
	    raise ValueError( "The hopping in " + str(direction) + " is not part of the model" )

    def hop_h( self,site2,site1,p ):
        return -self.hop_e(site2,site1,p)
        
    def onsite_e( self, site, p ):
        return self._onsite(p) + self._y_term(p)

    def onsite_h( self, site, p ):
        return -self.onsite_e( site,p )


class MetallicSC2D_yz(MetallicSC):

    def __init__( self,params=None ):
	self.type = '2D metallic superconductor in yz-direction'
	self.dimension= 2
	self.lat_e = kwant.lattice.general( ( (1,), ), name='e' )
        self.lat_h = kwant.lattice.general( ( (1,), ), name='h' )
	self.params = params

    # hoppings
    def hop_e( self,site2,site1,p ):
        pos1=site1.pos; pos2=site2.pos
 	direction = [ pos2[d]-pos1[d] for d in range(self.dimension) ]
        distance2 = sum( [ dis**2 for dis in direction ] )
	if abs( distance2-direction[0]**2 )<self._tolerance:
            return self._hop_y(p)
        elif abs( distance2-direction[1]**2 )<self._tolerance:
            return self._hop_z(p)
	else:
	    raise ValueError( "The hopping in " + str(direction) + " is not part of the model" )

    def hop_h( self,site2,site1,p ):
        return -self.hop_e(site2,site1,p)
        
    def onsite_e( self, site, p ):
        return self._onsite(p) + self._x_term(p)

    def onsite_h( self, site, p ):
        return -self.onsite_e( site,p )

    


