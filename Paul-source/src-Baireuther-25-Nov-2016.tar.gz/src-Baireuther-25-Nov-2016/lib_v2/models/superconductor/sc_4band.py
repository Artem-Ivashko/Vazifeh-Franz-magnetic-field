#!/usr/bin/env python
# Filename weyl_SC.py 

# libraries    
import numpy as np
from numpy import pi as PI
import kwant

# my libraries
from paulimatrices import *
from memory import SimpleNamespace
from memory import get_var


""" Base class for metallic superconductors with local pairing """
class MetallicSC(object):

    def __init__( self,params=None ):
	self.type = 'Metallic superconductor'
	self.params = params
    _tolerance = 10**(-6)

    # hoppings        
    def _hop_x( self,p ):
        alpha=get_var(self.params,p,'alpha')
        tx =get_var(self.params,p,'met_tx')/alpha**2
        return -0.5*tx *s0s0
    def _hop_y( self,p ):
        alpha=get_var(self.params,p,'alpha')
        ty =get_var(self.params,p,'met_ty')/alpha**2
        return -0.5*ty *s0s0
    def _hop_z( self,p ):
        tz =get_var(self.params,p,'met_tz')
        return -0.5*tz *s0s0

    # onsite energies
    def _onsite( self,p ):
        alpha=get_var(self.params,p,'alpha')
        tx =get_var(self.params,p,'met_tx')/alpha**2
        ty =get_var(self.params,p,'met_ty')/alpha**2
        tz =get_var(self.params,p,'met_tz')
        mu =get_var(self.params,p,'met_mu')
        return (tx+ty+tz-mu)*s0s0
    def _x_term( self,p ):
        alpha=get_var(self.params,p,'alpha')
        tx =get_var(self.params,p,'met_tx')/alpha**2
        kx =get_var(self.params,p,'kx')
        return -tx*np.cos(kx*alpha)*s0s0
    def _y_term( self,p ):
        alpha=get_var(self.params,p,'alpha')
        ty =get_var(self.params,p,'met_ty')/alpha**2
        ky  =get_var(self.params,p,'ky')
        return -ty*np.cos(ky*alpha)*s0s0
        
    def _z_term( self,p ):
        tz =get_var(self.params,p,'met_tz')
        kz =get_var(self.params,p,'kz')
        return -tz*np.cos(kz)*s0s0
    
    # pairing (is also a hopping between electron and hole lattice)
    def pairing( self,site2,site1,p ):
        pos1=site1.pos; pos2=site2.pos
        if pos1!=pos2: raise ValueError("Pairing must be local")
        met_D =get_var(self.params,p,'met_D')
        return met_D*s0s0
    

class MetallicSC1D_x(MetallicSC):

    def __init__( self,params=None ):
	self.type = '1D metallic superconductor in x-direction'
	self.dimension= 1
	self.lat_e = kwant.lattice.general( ( (1,), ), name='e' )
        self.lat_h = kwant.lattice.general( ( (1,), ), name='h' )
	self.params = params

    def _y_term_e( self,p ):
        alpha=get_var(self.params,p,'alpha')
        ty =get_var(self.params,p,'met_ty')/alpha**2
        ky =get_var(self.params,p,'ky')
        
        #if we want to include a vector potential Ay in the superconductor
        ky_shift =get_var(self.params,p,'ky_shift')
        ky_p     =ky + ky_shift
        #print ky_shift
        return -ty*np.cos(ky_p*alpha)*s0s0

    def _y_term_h( self,p ):
        alpha=get_var(self.params,p,'alpha')
        ty =get_var(self.params,p,'met_ty')/alpha**2
        ky  =get_var(self.params,p,'ky')
        
        #if we want to include a vector potential Ay in the superconductor
        ky_shift =get_var(self.params,p,'ky_shift')
        ky_p     =ky - ky_shift
        #print 'hole'
        return -ty*np.cos(ky_p*alpha)*s0s0

        
    # hoppings
    def hop_e( self,site2,site1,p ):
        pos1=site1.pos; pos2=site2.pos
 	direction = [ pos2[d]-pos1[d] for d in range(self.dimension) ]
        distance2 = sum( [ dis**2 for dis in direction ] )
	if abs( distance2-direction[0]**2 )<self._tolerance:
            return self._hop_x(p)
	else:
	    raise ValueError( "The hopping in " + str(direction) + " is not part of the model" )
    def hop_h( self,site2,site1,p ):
        return -self.hop_e( site2,site1,p )

    # onsite energies
    def onsite_e( self, site, p ):
        return self._onsite(p) + self._y_term_e(p) + self._z_term(p)
    def onsite_h( self, site, p ):
        return -self._onsite(p) - self._y_term_h(p) - self._z_term(p)


class MetallicSC1D_y(MetallicSC):

    def __init__( self,params=None ):
	self.type = '1D metallic superconductor in y-direction'
	self.dimension= 1
	self.lat_e = kwant.lattice.general( ( (1,), ), name='e' )
        self.lat_h = kwant.lattice.general( ( (1,), ), name='h' )
	self.params = params

    # hoppings
    def hop_e( self,site2,site1,p ):
        pos1=site1.pos; pos2=site2.pos
 	direction = [ pos2[d]-pos1[d] for d in range(self.dimension) ]
        distance2 = sum( [ dis**2 for dis in direction ] )
	if abs( distance2-direction[0]**2 )<self._tolerance:
            return self._hop_y(p)
	else:
	    raise ValueError( "The hopping in " + str(direction) + " is not part of the model" )
    def hop_h( self,site2,site1,p ):
        return -self.hop_e( site2,site1,p )

    # onsite energies
    def onsite_e( self, site, p ):
        return self._onsite(p) + self._x_term(p) + self._z_term(p)
    def onsite_h( self, site, p ):
        return -self.onsite_e( site,p )

    
class MetallicSC1D_z(MetallicSC):

    def __init__( self,params=None ):
	self.type = '1D metallic superconductor in z-direction'
	self.dimension= 1
	self.lat_e = kwant.lattice.general( ( (1,), ), name='e' )
        self.lat_h = kwant.lattice.general( ( (1,), ), name='h' )
	self.params = params

    # hoppings
    def hop_e( self,site2,site1,p ):
        pos1=site1.pos; pos2=site2.pos
 	direction = [ pos2[d]-pos1[d] for d in range(self.dimension) ]
        distance2 = sum( [ dis**2 for dis in direction ] )
	if abs( distance2-direction[0]**2 )<self._tolerance:
            return self._hop_z(p)
	else:
	    raise ValueError( "The hopping in " + str(direction) + " is not part of the model" )
    def hop_h( self,site2,site1,p ):
        return -self.hop_e(site2,site1,p)

    # onsite energies
    def onsite_e( self, site, p ):
        return self._onsite(p) + self._x_term(p) + self._y_term(p)
    def onsite_h( self, site, p ):
        return -self.onsite_e( site,p )


class MetallicSC2D_xy(MetallicSC):

    def __init__( self,params=None ):
	self.type = '2D metallic superconductor in xy-direction'
	self.dimension= 2
	self.lat_e = kwant.lattice.general( ( (1,0),(0,1) ), name='e' )
        self.lat_h = kwant.lattice.general( ( (1,0),(0,1) ), name='h' )
	self.params = params

    # hoppings
    def hop_e( self,site2,site1,p ):
        pos1=site1.pos; pos2=site2.pos
 	direction = [ pos2[d]-pos1[d] for d in range(self.dimension) ]
        distance2 = sum( [ dis**2 for dis in direction ] )
	if abs( distance2-direction[0]**2 )<self._tolerance:
            return self._hop_x(p)
        elif abs( distance2-direction[1]**2 )<self._tolerance:
            return self._hop_y(p)
	else:
	    raise ValueError( "The hopping in " + str(direction) + " is not part of the model" )
    def hop_h( self,site2,site1,p ):
        return -self.hop_e(site2,site1,p)

    # onsite energies
    def onsite_e( self, site, p ):
        return self._onsite(p) + self._z_term(p)
    def onsite_h( self, site, p ):
        return -self.onsite_e( site,p )
    

class MetallicSC2D_xz(MetallicSC):

    def __init__( self,params=None ):
	self.type = '2D metallic superconductor in xz-direction'
	self.dimension= 2
	self.lat_e = kwant.lattice.general( ( (1,0),(0,1) ), name='e' )
        self.lat_h = kwant.lattice.general( ( (1,0),(0,1) ), name='h' )
	self.params = params

    # hoppings
    def hop_e( self,site2,site1,p ):
        pos1=site1.pos; pos2=site2.pos
 	direction = [ pos2[d]-pos1[d] for d in range(self.dimension) ]
        distance2 = sum( [ dis**2 for dis in direction ] )
	if abs( distance2-direction[0]**2 )<self._tolerance:
            return self._hop_x(p)
        elif abs( distance2-direction[1]**2 )<self._tolerance:
            return self._hop_z(p)
	else:
	    raise ValueError( "The hopping in " + str(direction) + " is not part of the model" )
    def hop_h( self,site2,site1,p ):
        return -self.hop_e(site2,site1,p)

    # onsite energies
    def onsite_e( self, site, p ):
        return self._onsite(p) + self._y_term(p)
    def onsite_h( self, site, p ):
        return -self.onsite_e( site,p )


class MetallicSC2D_yz(MetallicSC):

    def __init__( self,params=None ):
	self.type = '2D metallic superconductor in yz-direction'
	self.dimension= 2
	self.lat_e = kwant.lattice.general( ( (1,0),(0,1) ), name='e' )
        self.lat_h = kwant.lattice.general( ( (1,0),(0,1) ), name='h' )
	self.params = params

    # hoppings
    def hop_e( self,site2,site1,p ):
        pos1=site1.pos; pos2=site2.pos
 	direction = [ pos2[d]-pos1[d] for d in range(self.dimension) ]
        distance2 = sum( [ dis**2 for dis in direction ] )
	if abs( distance2-direction[0]**2 )<self._tolerance:
            return self._hop_y(p)
        elif abs( distance2-direction[1]**2 )<self._tolerance:
            return self._hop_z(p)
	else:
	    raise ValueError( "The hopping in " + str(direction) + " is not part of the model" )
    def hop_h( self,site2,site1,p ):
        return -self.hop_e(site2,site1,p)

    # onsite energies
    def onsite_e( self, site, p ):
        return self._onsite(p) + self._x_term(p)
    def onsite_h( self, site, p ):
        return -self.onsite_e( site,p )

    
class MetallicSC3D(MetallicSC):

    def __init__( self,params=None ):
	self.type = '3D metallic superconductor'
	self.dimension= 3
        self.lat_e = kwant.lattice.general( ( (1,0,0),(0,1,0),(0,0,1) ), name='e' )
        self.lat_h = kwant.lattice.general( ( (1,0,0),(0,1,0),(0,0,1) ), name='h' )
	self.params = params

    # hoppings
    def hop_e( self,site2,site1,p ):
        pos1=site1.pos; pos2=site2.pos
 	direction = [ pos2[d]-pos1[d] for d in range(self.dimension) ]
        distance2 = sum( [ dis**2 for dis in direction ] )
	if abs( distance2-direction[0]**2 )<self._tolerance:
            return self._hop_x(p)
        elif abs( distance2-direction[1]**2 )<self._tolerance:
            return self._hop_y(p)
	else:
            return self._hop_z(p)
    def hop_h( self,site2,site1,p ):
        return -self.hop_e(site2,site1,p)

    # onsite energies
    def onsite_e( self, site, p ):
        return self._onsite(p)
    def onsite_h( self, site, p ):
        return -self.onsite_e( site,p )

    
