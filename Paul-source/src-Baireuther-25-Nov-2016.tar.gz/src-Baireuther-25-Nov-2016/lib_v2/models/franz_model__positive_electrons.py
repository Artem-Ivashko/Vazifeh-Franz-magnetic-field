#!/usr/bin/env python
# Filename franz_model.py 

# libraries
import numpy as np
from numpy import pi as PI
import kwant

# my libraries
from paulimatrices import *
from memory import SimpleNamespace
from memory import get_var

""" 
TABLE OF CONTENTS

1.   Franz parent class
2.1  Franz1D
2.2a Franz2D_xy
2.2b Franz2D_xz
2.3  Franz3D
"""


"""1. Franz is the parent class for the Franz model. It contains all the
hoppings and onsite energies.

"""
class Franz(object):

    def __init__( self,params=None ):
	self.type = 'Franz model'
	self.params = params

    def hop( self,pos2,pos1,p ):

        x1,y1,z1=pos1
        x2,y2,z2=pos2
		
	# verify that the hopping is acutally a hopping
	tolerance = 10**(-6)
	direction = [ pos2[d]-pos1[d] for d in range(self.dimension) ]
	distance2 = sum( [ dis**2 for dis in direction ] )
	if abs(distance2)<tolerance:
	    raise ValueError( "The hopping must have a finite distance" )

	#x,y,z = pos1
	tp =get_var(self.params,p,'tp')
	tzp=get_var(self.params,p,'tzp')
        tz =get_var(self.params,p,'tz')
	t  =get_var(self.params,p,'t')
        lBinv2 =get_var(self.params,p,'lBinv2')

        try:
            x_shift = p.x_shift
        except:
            raise ValueError( "x_shift not defined" )

                
	if abs( distance2-direction[0]**2 )<tolerance:
	    return -0.5j*tp*s3s1 - 0.5*t*s1s0
	elif abs( distance2-direction[1]**2 )<tolerance:
            # Peierl's phase
            phase = np.exp( -1j * lBinv2*(y2-y1)*(x1+x2-2*x_shift)/2. )
            return -0.5j*tp*phase*s3s2 - 0.5*t*phase*s1s0
	elif abs( distance2-direction[2]**2 )<tolerance:
	    return -0.5j*tzp*s2s0 - 0.5*tz*s1s0
	else:
	    raise ValueError( "The hopping in " + str(direction) + " is not part of the model" )

    def onsite( self, pos, p ):

	(x, y, z) = pos
	mu  =get_var(self.params,p,'mu')
	b0  =get_var(self.params,p,'b0')
	bx  =get_var(self.params,p,'bx')
	by  =get_var(self.params,p,'by')
	bz  =get_var(self.params,p,'bz')
	
	termb0 = b0*s2s3
	termbvec = bx*s1s2 + by*s1s1 + bz*s0s3
	return mu*s1s0 + termb0 + termbvec
    


"""2.1 Franz1D is the parent class for the Franz model on a 1D tight
binding chain in x-direction. In y- and z-direction we assume periodic
boundary conditions. This makes ky,kz good quantum numbers. The y- and
z-dimension are included in the onsite energies.

"""
class Franz1D(Franz):

    def __init__( self,params=None ):
	self.type = '1D Franz model'
	self.dimension= 1
	self.lat = kwant.lattice.general( ( (1,), ) )
	self.params = params
		

    def hop( self,pos1,pos2,p ):
		
	# verify that the hopping is acutally a hopping
	tolerance = 10**(-6)
	direction = [ pos2[d]-pos1[d] for d in range(self.dimension) ]
	distance2 = sum( [ dis**2 for dis in direction ] )
	if abs(distance2)<tolerance:
	    raise ValueError( "The hopping must have a finite distance" )

	x, = pos1
	tp =get_var(self.params,p,'tp')
	tzp=get_var(self.params,p,'tzp')
        tz =get_var(self.params,p,'tz')
	t  =get_var(self.params,p,'t')
	
	if abs( distance2-direction[0]**2 )<tolerance:
	    return -0.5j*tp*s3s1 -0.5*t*s1s0
	else:
	    raise ValueError( "The hopping in " + str(direction) + " is not part of the model" )


    def onsite( self, pos, p ):

	(x,) = pos
	tp   =get_var(self.params,p,'tp')
	tzp  =get_var(self.params,p,'tzp')
        tz   =get_var(self.params,p,'tz')
	t    =get_var(self.params,p,'t')
	mu   =get_var(self.params,p,'mu')
	ky   =get_var(self.params,p,'ky')
	kz   =get_var(self.params,p,'kz')
	#Phi_x=get_var(self.params,p,'Phi_x')
	lBinv2   =get_var(self.params,p,'lBinv2')
	b0   =get_var(self.params,p,'b0')
	bx   =get_var(self.params,p,'bx')
	by   =get_var(self.params,p,'by')
	bz   =get_var(self.params,p,'bz')
	try:
	    muinf=p.muinf; x0=p.x0;
	except:
	    muinf=0; x0=0	

        try:
            x_shift = p.x_shift
            ky_p    = ky - float(x-x_shift)*float(lBinv2)
        except:
            raise ValueError( "x_shift not defined" )
            
	term_y = +tp*np.sin(ky_p)*s3s2 -t*np.cos(ky_p)*s1s0
	term_z = +tzp*np.sin(kz)*s2s0 -tz*np.cos(kz)*s1s0

	term_b0   = b0*s2s3
	term_bvec = bx*s1s2 + by*s1s1 + bz*s0s3
	return mu*s1s0 + muinf*(x-x0)**2*s1s0 + term_y + term_z + term_b0 + term_bvec


"""2.2a Franz2D_xy is a 2D tight binding model in x- and y-direction. In
z-direction we assume periodic boundary conditions/translation
invariance. This makes kz a good quantum number.
"""
class Franz2D_xy(Franz):

    def __init__( self,params=None ):
	self.type = '2D Franz model'
	self.dimension = 2
	self.lat = kwant.lattice.general( ( (1,0),(0,1) ) )
	self.params = params


    def hop( self,pos1,pos2,p ):
		
	# verify that the hopping is acutally a hopping
	tolerance = 10**(-6)
	direction = [ pos2[d]-pos1[d] for d in range(self.dimension) ]
	distance2 = sum( [ dis**2 for dis in direction ] )
	if abs(distance2)<tolerance:
	    raise ValueError( "The hopping must have a finite distance" )

	x1,y1 = pos1
        x2,y2 = pos2
	tp =get_var(self.params,p,'tp')
	tzp =get_var(self.params,p,'tzp')
        tz =get_var(self.params,p,'tz')
	t  =get_var(self.params,p,'t')
        lBinv2   =get_var(self.params,p,'lBinv2')

        try:
            x_shift = p.x_shift
        except:
            raise ValueError( "x_shift not defined" )
	
	if abs( distance2-direction[0]**2 )<tolerance:
	    return -0.5j*tp*s3s1 -0.5*t*s1s0
	elif abs( distance2-direction[1]**2 )<tolerance:
            # Peierl's phase
            phase = np.exp( -1j * lBinv2*(y2-y1)*(x1+x2-2*x_shift)/2. )
            return -0.5j*tp*phase*s3s2 - 0.5*t*phase*s1s0
        else:
	    raise ValueError( "The hopping in " + str(direction) + " is not part of the model" )


    def onsite( self, pos, p ):

	(x,z) = pos
	#tp   =get_var(self.params,p,'tp')
	tzp   =get_var(self.params,p,'tzp')
        #tz   =get_var(self.params,p,'tz')
	t    =get_var(self.params,p,'t')
	mu   =get_var(self.params,p,'mu')
        #lBinv2   =get_var(self.params,p,'lBinv2')
	b0   =get_var(self.params,p,'b0')
	bx   =get_var(self.params,p,'bx')
	by   =get_var(self.params,p,'by')
	bz   =get_var(self.params,p,'bz')
        kz   =get_var(self.params,p,'kz')
                

        term_z    = tzp*np.sin(kz)*s2s0 -t*np.cos(kz)*s1s0
	term_b0   = b0*s2s3
	term_bvec = bx*s1s2 + by*s1s1 + bz*s0s3
	return mu*s1s0 + term_z + term_b0 + term_bvec



"""2.2b Franz2D_xz is a 2D tight binding model in x- and z-direction. In
y-direction we assume periodic boundary conditions/translation
invariance. This makes ky a good quantum number.
"""
class Franz2D_xz(Franz):

    def __init__( self,params=None ):
	self.type = '2D Franz model, lattice in x- and z-direction'
	self.dimension = 2
	self.lat = kwant.lattice.general( ( (1,0),(0,1) ) )
	self.params = params


    def hop( self,pos1,pos2,p ):
		
	# verify that the hopping is acutally a hopping
	tolerance = 10**(-6)
	direction = [ pos2[d]-pos1[d] for d in range(self.dimension) ]
	distance2 = sum( [ dis**2 for dis in direction ] )
	if abs(distance2)<tolerance:
	    raise ValueError( "The hopping must have a finite distance" )
		
	x1,y1 = pos1
        x2,y2 = pos2
	tp =get_var(self.params,p,'tp')
	tzp =get_var(self.params,p,'tzp')
        tz =get_var(self.params,p,'tz')
	t  =get_var(self.params,p,'t')
        lBinv2   =get_var(self.params,p,'lBinv2')
	
	if abs( distance2-direction[0]**2 )<tolerance:
	    return -0.5j*tp*s3s1 -0.5*t*s1s0
	elif abs( distance2-direction[1]**2 )<tolerance:
	    return -0.5j*tzp*s2s0 - 0.5*tz*s1s0
        else:
	    raise ValueError( "The hopping in " + str(direction) + " is not part of the model" )


    def onsite( self, pos, p ):

	(x,z) = pos
	tp    =get_var(self.params,p,'tp')
	#tzp    =get_var(self.params,p,'tzp')
        #tz    =get_var(self.params,p,'tz')
	t      =get_var(self.params,p,'t')
	mu     =get_var(self.params,p,'mu')
        lBinv2 =get_var(self.params,p,'lBinv2')
	b0     =get_var(self.params,p,'b0')
	bx     =get_var(self.params,p,'bx')
	by     =get_var(self.params,p,'by')
	bz     =get_var(self.params,p,'bz')
        ky     =get_var(self.params,p,'ky')

	try:
	    muinf=p.muinf; x0=p.x0;
	except:
	    muinf=0; x0=0	

        try:
            x_shift = p.x_shift
            ky_p    = ky - float(x-x_shift)*float(lBinv2)
        except:
            raise ValueError( "x_shift not defined" )

	term_y = +tp*np.sin(ky_p)*s3s2 -t*np.cos(ky_p)*s1s0
	term_b0   = b0*s2s3
	term_bvec = bx*s1s2 + by*s1s1 + bz*s0s3
		
	return mu*s1s0 + muinf*(x-x0)**2*s1s0 + term_y + term_b0 + term_bvec



"""2.3 Franz3D is a 3D tight binding lattice."""
class Franz3D(Franz):

    def __init__( self,params=None ):
	self.type = '3D Franz model'
	self.dimension = 3
	self.lat = kwant.lattice.general( ((1,0,0),(0,1,0),(0,0,1)) )
	self.params = params






	
