#!/usr/bin/env python
# Filename parallel_AQH_stack.py 

# libraries
import numpy as np
from numpy import pi as PI
import kwant

# my libraries
from paulimatrices import *
from memory import SimpleNamespace
from memory import get_var


class AQHStack(object):
	'''
	This is the 3D parent class for the AQH stack with parallel layers
	'''

	def __init__( self,params=None ):
		self.type = 'AQH parent class'
		self.params = params

	def hop( self,pos1,pos2,p ):
		
		# verify that the hopping is acutally a hopping
		tolerance = 10**(-6)
		direction = [ pos2[d]-pos1[d] for d in range(self.dimension) ]
		distance2 = sum( [ dis**2 for dis in direction ] )
		if abs(distance2)<tolerance:
			raise ValueError( "The hopping must have a finite distance" )

		x,y,z = pos1
		tz = get_var(self.params,p,'tz')		

		if abs( distance2-direction[0]**2 )<tolerance:
			return ( 1j*sigma_x - sigma_z )/2.0
		elif abs( distance2-direction[1]**2 )<tolerance:
			return ( 1j*sigma_y - sigma_z )/2.0
		elif abs( distance2-direction[2]**2 )<tolerance:
			return 1j*tz *sigma_z/2.0
		else:
			raise ValueError( "The hopping in " + str(direction) + " is not part of the model" )

	def onsite( self, pos, p ):

		(x, y, z) = pos
		mu = get_var(self.params,p,'mu')
		try:
			U = get_var(self.params,p,'U')
		except:
			return mu*sigma_z
		return mu*sigma_z + U[int(x),int(y),int(z)]*sigma_0


class AQHStack3D(AQHStack):
	'''
	This class describes a 3D parallel Anomalous Quantum Hall stack
	'''
	def __init__( self,params=None ):
		self.type = '3D AQH stack'
		self.dimension = 3
		self.lat = kwant.lattice.general( ( (1,0,0),(0,1,0),(0,0,1) ) )
		self.params = params


	

