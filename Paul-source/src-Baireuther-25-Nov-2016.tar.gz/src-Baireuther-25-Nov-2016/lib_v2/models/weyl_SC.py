#!/usr/bin/env python
# Filename weyl_SC.py 

# libraries
import numpy as np
from numpy import pi as PI
from numpy import sin,cos,sqrt
import kwant

# my libraries
from paulimatrices import *
from memory import SimpleNamespace
from memory import get_var


""" Base class for metallic superconductors with local pairing """
class MetallicSC(object):

    def __init__( self,params=None ):
	self.type = 'Metallic superconductor'
	self.params = params

    _tolerance = 10**(-6)

    # hoppings        
    def _hop_x( self,p ):
        met_tx =get_var(self.params,p,'met_tx')
        return -0.5*met_tx*s0s0
    def _hop_y( self,p ):
        met_ty =get_var(self.params,p,'met_ty')
        return -0.5*met_ty*s0s0
    def _hop_z( self,p ):
        met_tz =get_var(self.params,p,'met_tz')
        return -0.5*met_tz*s0s0

    # onsite energies
    def _onsite( self,p ):
        met_mu =get_var(self.params,p,'met_mu')
        return -met_mu*s0s0
    def _x_term( self,p ):
        met_tx =get_var(self.params,p,'met_tx')
        kx     =get_var(self.params,p,'kx')
        return -met_tx*np.cos(kx)*s0s0
    def _y_term( self,p ):
        met_ty   =get_var(self.params,p,'met_ty')
        ky       =get_var(self.params,p,'ky')
        ky_shift =get_var(self.params,p,'ky_shift')
        ky_p     =ky + ky_shift
        #print -met_ty*np.cos(ky_p)
        return -met_ty*np.cos(ky_p)*s0s0

    def _z_term( self,p ):
        met_tz =get_var(self.params,p,'met_tz')
        kz     =get_var(self.params,p,'kz')
        return -met_tz*np.cos(kz)*s0s0
    
    # pairing (is also a hopping between electron and hole lattice)
    def pairing( self,site2,site1,p ):
        pos1=site1.pos; pos2=site2.pos
        if pos1!=pos2: raise ValueError("Pairing must be local")
        met_D =get_var(self.params,p,'met_D')
        return met_D*s0s0
    

class MetallicSC1D_x(MetallicSC):

    def __init__( self,params=None ):
	self.type = '1D metallic superconductor in x-direction'
	self.dimension= 1
	self.lat_e = kwant.lattice.general( ( (1,), ), name='e' )
        self.lat_h = kwant.lattice.general( ( (1,), ), name='h' )
	self.params = params

    # hoppings
    def hop_e( self,site2,site1,p ):
        pos1=site1.pos; pos2=site2.pos
 	direction = [ pos2[d]-pos1[d] for d in range(self.dimension) ]
        distance2 = sum( [ dis**2 for dis in direction ] )
	if abs( distance2-direction[0]**2 )<self._tolerance:
            return self._hop_x(p)
	else:
	    raise ValueError( "The hopping in " + str(direction) + " is not part of the model" )

    def hop_h( self,site2,site1,p ):
        return -self.hop_e( site2,site1,p )
            
    def onsite_e( self, site, p ):
        return self._onsite(p) + self._y_term(p) + self._z_term(p)

    def onsite_h( self, site, p ):
        return -self.onsite_e( site,p )


class MetallicSC1D_y(MetallicSC):

    def __init__( self,params=None ):
	self.type = '1D metallic superconductor in y-direction'
	self.dimension= 1
	self.lat_e = kwant.lattice.general( ( (1,), ), name='e' )
        self.lat_h = kwant.lattice.general( ( (1,), ), name='h' )
	self.params = params

    # hoppings
    def hop_e( self,site2,site1,p ):
        pos1=site1.pos; pos2=site2.pos
 	direction = [ pos2[d]-pos1[d] for d in range(self.dimension) ]
        distance2 = sum( [ dis**2 for dis in direction ] )
	if abs( distance2-direction[0]**2 )<self._tolerance:
            return self._hop_y(p)
	else:
	    raise ValueError( "The hopping in " + str(direction) + " is not part of the model" )

    def hop_h( self,site2,site1,p ):
        return -self.hop_e( site2,site1,p )
            
    def onsite_e( self, site, p ):
        return self._onsite(p) + self._x_term(p) + self._z_term(p)

    def onsite_h( self, site, p ):
        return -self.onsite_e( site,p )

    
    
class MetallicSC1D_z(MetallicSC):

    def __init__( self,params=None ):
	self.type = '1D metallic superconductor in z-direction'
	self.dimension= 1
	self.lat_e = kwant.lattice.general( ( (1,), ), name='e' )
        self.lat_h = kwant.lattice.general( ( (1,), ), name='h' )
	self.params = params

    # hoppings
    def hop_e( self,site2,site1,p ):
        pos1=site1.pos; pos2=site2.pos
 	direction = [ pos2[d]-pos1[d] for d in range(self.dimension) ]
        distance2 = sum( [ dis**2 for dis in direction ] )
	if abs( distance2-direction[0]**2 )<self._tolerance:
            return self._hop_z(p)
	else:
	    raise ValueError( "The hopping in " + str(direction) + " is not part of the model" )

    def hop_h( self,site2,site1,p ):
        return -self.hop_e(site2,site1,p)
        
    def onsite_e( self, site, p ):
        return self._onsite(p) + self._x_term(p) + self._y_term(p)

    def onsite_h( self, site, p ):
        return -self.onsite_e( site,p )


class MetallicSC2D_xy(MetallicSC):

    def __init__( self,params=None ):
	self.type = '2D metallic superconductor in xy-direction'
	self.dimension= 2
	self.lat_e = kwant.lattice.general( ( (1,0),(0,1) ), name='e' )
        self.lat_h = kwant.lattice.general( ( (1,0),(0,1) ), name='h' )
	self.params = params

    # hoppings
    def hop_e( self,site2,site1,p ):
        pos1=site1.pos; pos2=site2.pos
 	direction = [ pos2[d]-pos1[d] for d in range(self.dimension) ]
        distance2 = sum( [ dis**2 for dis in direction ] )
	if abs( distance2-direction[0]**2 )<self._tolerance:
            return self._hop_x(p)
        elif abs( distance2-direction[1]**2 )<self._tolerance:
            return self._hop_y(p)
	else:
	    raise ValueError( "The hopping in " + str(direction) + " is not part of the model" )

    def hop_h( self,site2,site1,p ):
        return -self.hop_e(site2,site1,p)
        
    def onsite_e( self, site, p ):
        return self._onsite(p) + self._z_term(p)

    def onsite_h( self, site, p ):
        return -self.onsite_e( site,p )
    

class MetallicSC2D_xz(MetallicSC):

    def __init__( self,params=None ):
	self.type = '2D metallic superconductor in xz-direction'
	self.dimension= 2
	self.lat_e = kwant.lattice.general( ( (1,0),(0,1) ), name='e' )
        self.lat_h = kwant.lattice.general( ( (1,0),(0,1) ), name='h' )
	self.params = params

    # hoppings
    def hop_e( self,site2,site1,p ):
        pos1=site1.pos; pos2=site2.pos
 	direction = [ pos2[d]-pos1[d] for d in range(self.dimension) ]
        distance2 = sum( [ dis**2 for dis in direction ] )
	if abs( distance2-direction[0]**2 )<self._tolerance:
            return self._hop_x(p)
        elif abs( distance2-direction[1]**2 )<self._tolerance:
            return self._hop_z(p)
	else:
	    raise ValueError( "The hopping in " + str(direction) + " is not part of the model" )

    def hop_h( self,site2,site1,p ):
        return -self.hop_e(site2,site1,p)
        
    def onsite_e( self, site, p ):
        return self._onsite(p) + self._y_term(p)

    def onsite_h( self, site, p ):
        return -self.onsite_e( site,p )


class MetallicSC2D_yz(MetallicSC):

    def __init__( self,params=None ):
	self.type = '2D metallic superconductor in yz-direction'
	self.dimension= 2
	self.lat_e = kwant.lattice.general( ( (1,), ), name='e' )
        self.lat_h = kwant.lattice.general( ( (1,), ), name='h' )
	self.params = params

    # hoppings
    def hop_e( self,site2,site1,p ):
        pos1=site1.pos; pos2=site2.pos
 	direction = [ pos2[d]-pos1[d] for d in range(self.dimension) ]
        distance2 = sum( [ dis**2 for dis in direction ] )
	if abs( distance2-direction[0]**2 )<self._tolerance:
            return self._hop_y(p)
        elif abs( distance2-direction[1]**2 )<self._tolerance:
            return self._hop_z(p)
	else:
	    raise ValueError( "The hopping in " + str(direction) + " is not part of the model" )

    def hop_h( self,site2,site1,p ):
        return -self.hop_e(site2,site1,p)
        
    def onsite_e( self, site, p ):
        return self._onsite(p) + self._x_term(p)

    def onsite_h( self, site, p ):
        return -self.onsite_e( site,p )

    



    




    
""" Basis class of a Weyl-superconductor in Nambu basis """
class WeylSC(object):

    def __init__( self,params=None ):
	self.type = 'Weyl superconductor'
	self.params = params
        
    _tolerance = 10**(-6)

    # hoppings
    def _hop_x( self,p ):
        tp  =get_var(self.params,p,'tp')
	t   =get_var(self.params,p,'t')
        return -0.5j*tp*s3s1  - 0.5*t*s1s0
    def _hop_y( self,p ):
        tp  =get_var(self.params,p,'tp')
	t   =get_var(self.params,p,'t')
        return -0.5j*tp*s3s2  - 0.5*t*s1s0
    def _hop_z( self,p ):
        tzp =get_var(self.params,p,'tzp')
        tz  =get_var(self.params,p,'tz')
        return -0.5j*tzp*s2s0 - 0.5*tz*s1s0
    
    def hop_e( self,site2,site1,p ):
        pos1=site1.pos; pos2=site2.pos
	direction = [ pos2[d]-pos1[d] for d in range(self.dimension) ]
        distance2 = sum( [ dis**2 for dis in direction ] )
	if abs( distance2-direction[0]**2 )<self._tolerance:
	    return self._hop_x(p)
	elif abs( distance2-direction[1]**2 )<self._tolerance:
            return self._hop_y(p)
	elif abs( distance2-direction[2]**2 )<self._tolerance:
	    return self._hop_z(p)
	else:
	    raise ValueError( "The hopping in " + str(direction) + " is not part of the model" )

    def hop_h( self,site2,site1,p ):
        return -self.hop_e(site2,site1,p)


    # onsite energies
    def _term_chempot( self,p ):
        mu_W =get_var(self.params,p,'mu_W')
        return -mu_W*s0s0
    def _term_Mk( self,p ):
        t  =get_var(self.params,p,'t')
        tz =get_var(self.params,p,'tz')
        M0 =get_var(self.params,p,'M0')
        return ( M0 + 2*t + tz ) * s1s0
    def _term_invbr( self,p ):
        b0 =get_var(self.params,p,'b0')
        return 0.5*b0*s2s3
    def _term_TRbr( self,p ):
        betax  =get_var(self.params,p,'betax')
        betay  =get_var(self.params,p,'betay')
        betaz  =get_var(self.params,p,'betaz')
        return 0.5*betax*s1s2 - 0.5*betay*s1s1 + 0.5*betaz*s0s3
    def _term_strain( self, p ):
        Lambda  =get_var(self.params,p,'Lambda')
        return 0.5*Lambda*s2s0

    def _term_x( self,p ):
        tp =get_var(self.params,p,'tp')
        t  =get_var(self.params,p,'t')
        kx =get_var(self.params,p,'kx')
        return +tp*np.sin(kx)*s3s1 - t*np.cos(kx)*s1s0
    def _term_y( self,p,x ):
        tp     =get_var(self.params,p,'tp')
        t      =get_var(self.params,p,'t')
        ky     =get_var(self.params,p,'ky')
        lBinv2 =get_var(self.params,p,'lBinv2')
        x_shift=get_var(self.params,p,'x_shift')
        ky_p   = ky + float(x-x_shift)*float(lBinv2)
        #print x,ky_p
        return +tp*np.sin(ky_p)*s3s2 - t*np.cos(ky_p)*s1s0
    def _term_z( self,p ):
        tzp =get_var(self.params,p,'tzp')
        tz  =get_var(self.params,p,'tz')
        kz  =get_var(self.params,p,'kz')
        return +tzp*np.sin(kz)*s2s0 - tz*np.cos(kz)*s1s0

    def onsite_e( self, site, p ):
        return self._term_Mk(p) + self._term_chempot(p) + self._term_invbr(p) \
            + self._term_TRbr(p) + self._term_strain(p)
    
    def onsite_h( self, site, p ):
        return -self._term_Mk(p) - self._term_chempot(p) - self._term_invbr(p) \
            + self._term_TRbr(p) + self._term_strain(p)

    # pairing (is also a hopping between electron and hole lattice)
    def pairing( self,site2,site1,p ):
        pos1=site1.pos; pos2=site2.pos
        if pos1!=pos2: raise ValueError("Pairing must be local")
	D0 =get_var(self.params,p,'D0')
        D1 =get_var(self.params,p,'D1')
        return D0*s0s0+D1*s1s0


    
class WeylSC1D_x(WeylSC):

    def __init__( self,params=None ):
	self.type = '1D Weyl superconductor in x-direction'
	self.dimension= 1
	self.lat_e = kwant.lattice.general( ( (1,), ), name='e' )
        self.lat_h = kwant.lattice.general( ( (1,), ), name='h' )
	self.params = params

    # hoppings
    def hop_e( self,site2,site1,p ):
        pos1=site1.pos; pos2=site2.pos
	direction = [ pos2[d]-pos1[d] for d in range(self.dimension) ]
        distance2 = sum( [ dis**2 for dis in direction ] )
	if abs( distance2-direction[0]**2 )<self._tolerance:
            return self._hop_x(p)
	else:
	    raise ValueError( "The hopping in " + str(direction) + " is not part of the model" )

    def hop_h( self,site2,site1,p ):
        return -self.hop_e(site2,site1,p)
            
    # onsite
    def onsite_e( self, site, p ):
        x,=site.pos
	return self._term_y(p,x) + self._term_z(p) + self._term_Mk(p) \
            + self._term_chempot(p) + self._term_invbr(p) \
            + self._term_TRbr(p) + self._term_strain(p)

    def onsite_h( self, site, p ):
        x,=site.pos
        return -self._term_y(p,-x+2*p.x_shift) - self._term_z(p) - self._term_Mk(p) \
            - self._term_chempot(p) - self._term_invbr(p) \
            + self._term_TRbr(p) + self._term_strain(p)

        
class WeylSC1D_z(WeylSC):

    def __init__( self,params=None ):
	self.type = '1D Weyl superconductor in z-direction'
	self.dimension= 1
	self.lat_e = kwant.lattice.general( ( (1,), ), name='e' )
        self.lat_h = kwant.lattice.general( ( (1,), ), name='h' )
	self.params = params
        WeylSC.__init__(self)

    # hoppings
    def hop_e( self,site2,site1,p ):
        pos1=site1.pos; pos2=site2.pos
	direction = [ pos2[d]-pos1[d] for d in range(self.dimension) ]
        distance2 = sum( [ dis**2 for dis in direction ] )
	if abs( distance2-direction[0]**2 )<self._tolerance:
            return self._hop_z(p)
	else:
	    raise ValueError( "The hopping in " + str(direction) + " is not part of the model" )

    def hop_h( self,site2,site1,p ):
        return -self.hop_e(site2,site1,p)
            
    # onsite
    def onsite_e( self, site, p ):
        lBinv2  =get_var(self.params,p,'lBinv2')
        if abs(lBinv2)>10**(-12): raise ValueError( "weyl_SC.py: Magnetic field not implemented" )
	return self._term_x(p) + self._term_y(p,x=0) + self._term_Mk(p) \
            + self._term_chempot(p) + self._term_invbr(p) \
            + self._term_TRbr(p) + self._term_strain(p)

    def onsite_h( self, site, p ):
        lBinv2  =get_var(self.params,p,'lBinv2')
        if abs(lBinv2)>10**(-12): raise ValueError( "weyl_SC.py: Magnetic field not implemented" )
        return -self._term_x(p) - self._term_y(p,x=0) - self._term_Mk(p) \
            - self._term_chempot(p) - self._term_invbr(p) \
            + self._term_TRbr(p) + self._term_strain(p)

    
class WeylSC2D_xy(WeylSC):

    def __init__( self,params=None ):
	self.type = '2D Weyl superconductor in xy-direction'
	self.dimension= 2
        self.lat_e = kwant.lattice.general( ( (1,0),(0,1) ), name='e' )
        self.lat_h = kwant.lattice.general( ( (1,0),(0,1) ), name='h' )
        self.params = params

    # hoppings
    def hop_e( self,site2,site1,p ):
        pos1=site1.pos; pos2=site2.pos
	direction = [ pos2[d]-pos1[d] for d in range(self.dimension) ]
        distance2 = sum( [ dis**2 for dis in direction ] )
	if abs( distance2-direction[0]**2 )<self._tolerance:
            return self._hop_x(p)
        elif abs( distance2-direction[1]**2 )<self._tolerance:
            x1,y1=pos1
            x2,y2=pos2

            tp  =get_var(self.params,p,'tp')
	    t   =get_var(self.params,p,'t')
            lBinv2 =get_var(self.params,p,'lBinv2')
            #return -0.5j*tp*s3s2  - 0.5*t*s1s0
            
            # Peierl's phase
            phase = np.exp( -1j * lBinv2*(y2-y1)*(x1+x2)/2. )
            return -0.5j*tp*phase*s3s2 - 0.5*t*phase*s1s0
            #return self._hop_y(p)
	else:
	    raise ValueError( "The hopping in " + str(direction) + " is not part of the model" )

    def hop_h( self,site2,site1,p ):
        pos1=site1.pos; pos2=site2.pos
	direction = [ pos2[d]-pos1[d] for d in range(self.dimension) ]
        distance2 = sum( [ dis**2 for dis in direction ] )
	if abs( distance2-direction[0]**2 )<self._tolerance:
            return -self._hop_x(p)
        elif abs( distance2-direction[1]**2 )<self._tolerance:
            x1,y1=pos1
            x2,y2=pos2

            tp  =get_var(self.params,p,'tp')
	    t   =get_var(self.params,p,'t')
            lBinv2 =get_var(self.params,p,'lBinv2')
            #return -0.5j*tp*s3s2  - 0.5*t*s1s0
            
            # Peierl's phase
            phase = np.exp( 1j * lBinv2*(y2-y1)*(x1+x2)/2. )
            return 0.5j*tp*phase*s3s2 + 0.5*t*phase*s1s0
            #return self._hop_y(p)
	else:
	    raise ValueError( "The hopping in " + str(direction) + " is not part of the model" )
        
        #return -self.hop_e(site2,site1,p)
            
    # onsite
    def onsite_e( self, site, p ):
	return self._term_z(p) + self._term_Mk(p) + self._term_chempot(p) + self._term_invbr(p) \
            + self._term_TRbr(p) + self._term_strain(p)

    def onsite_h( self, site, p ):
        return -self._term_z(p) - self._term_Mk(p) - self._term_chempot(p) - self._term_invbr(p) \
            + self._term_TRbr(p) + self._term_strain(p)

    
class WeylSC2D_xz(WeylSC):

    def __init__( self,params=None ):
	self.type = '2D Weyl superconductor in xz-direction'
	self.dimension= 2
	self.lat_e = kwant.lattice.general( ( (1,0),(0,1) ), name='e' )
        self.lat_h = kwant.lattice.general( ( (1,0),(0,1) ), name='h' )
	self.params = params

    # hoppings
    def hop_e( self,site2,site1,p ):
        pos1=site1.pos; pos2=site2.pos
	direction = [ pos2[d]-pos1[d] for d in range(self.dimension) ]
        distance2 = sum( [ dis**2 for dis in direction ] )
	if abs( distance2-direction[0]**2 )<self._tolerance:
            return self._hop_x(p)
        elif abs( distance2-direction[1]**2 )<self._tolerance:
            return self._hop_z(p)
	else:
	    raise ValueError( "The hopping in " + str(direction) + " is not part of the model" )

    def hop_h( self,site2,site1,p ):
        return -self.hop_e(site2,site1,p)
            
    # onsite
    def onsite_e( self, site, p ):
        x,z=site.pos
	return self._term_y(p,x) + self._term_Mk(p) + self._term_chempot(p) + self._term_invbr(p) \
            + self._term_TRbr(p) + self._term_strain(p)

    def onsite_h( self, site, p ):
        x,z=site.pos
        return -self._term_y(p,-x+2*p.x_shift) - self._term_Mk(p) - self._term_chempot(p) \
            - self._term_invbr(p) + self._term_TRbr(p) + self._term_strain(p)


class WeylSC2D_yz(WeylSC):

    def __init__( self,params=None ):
	self.type = '2D Weyl superconductor in yz-direction'
	self.dimension= 2
        self.lat_e = kwant.lattice.general( ( (1,0),(0,1) ), name='e' )
        self.lat_h = kwant.lattice.general( ( (1,0),(0,1) ), name='h' )
	self.params = params

    # hoppings
    def hop_e( self,site2,site1,p ):
        pos1=site1.pos; pos2=site2.pos
	direction = [ pos2[d]-pos1[d] for d in range(self.dimension) ]
        distance2 = sum( [ dis**2 for dis in direction ] )
	if abs( distance2-direction[0]**2 )<self._tolerance:
            return self._hop_y(p)
        elif abs( distance2-direction[1]**2 )<self._tolerance:
            return self._hop_z(p)
	else:
	    raise ValueError( "The hopping in " + str(direction) + " is not part of the model" )

    def hop_h( self,site2,site1,p ):
        return -self.hop_e(site2,site1,p)
            
    # onsite
    def onsite_e( self, site, p ):
	return self._term_x(p) + self._term_Mk(p) + self._term_chempot(p) \
            + self._term_invbr(p) + self._term_TRbr(p) + self._term_strain(p)

    def onsite_h( self, site, p ):
        return -self._term_x(p) - self._term_Mk(p) - self._term_chempot(p) \
            - self._term_invbr(p) + self._term_TRbr(p) + self._term_strain(p)





"""Twoband is Jakubs two-band model which is - up to O(b_0^3) -
equivalent to the Franz model arXiv:1303.5784. The x-dimension is
discretized on a 1D tight binding chain. In y- and z-direction we
assume periodic boundary conditions. This makes ky,kz good quantum
numbers.

"""
class Twoband_1D(object):

    def __init__( self,params=None ):
	self.type = 'Jakubs two-band model -- on 1D lattice in x'
	self.dimension= 1
	self.lat_e = kwant.lattice.general( ( (1,), ), name='e' )
        self.lat_h = kwant.lattice.general( ( (1,), ), name='h' )
	self.params = params


    def hop( self,site2,site1,p ):

        pos1,pos2=site1.pos,site2.pos
	# verify that the hopping is acutally a hopping
	tolerance = 10**(-6)
	direction = [ pos2[d]-pos1[d] for d in range(self.dimension) ]
	distance2 = sum( [ dis**2 for dis in direction ] )
	if abs(distance2)<tolerance:
	    raise ValueError( "The hopping must have a finite distance" )

	x1, = site1.pos
	tp =get_var(self.params,p,'tp')
	tz =get_var(self.params,p,'tz')
	t  =get_var(self.params,p,'t')
	M0 =get_var(self.params,p,'M0')
	ky =get_var(self.params,p,'ky')
	kz =get_var(self.params,p,'kz')
	b0 =get_var(self.params,p,'b0')
	alpha =get_var(self.params,p,'alpha')
	nu  =get_var(self.params,p,'nu')
	
	if abs( distance2-direction[0]**2 )<tolerance:

	    sinkz = np.sin(kz); coskz = np.cos(kz)
	    sinky = np.sin(ky); cosky = np.cos(ky)
            mu0   = M0+t*(1-cosky)+tz*(1-coskz)
	    lam0 = np.sqrt( mu0**2 + (tz*sinkz)**2 )
	    hop0_a = - 0.5j*tp/alpha *sigma1
            hop0_b = - 0.5*nu*t*mu0/lam0/alpha**2 *sigma3
	    hop1 = -0.5*b0/2. *tz*sinkz/lam0 *t*mu0/lam0**2 /alpha**2 *sigma0
            #print "hop"
            #print - 0.5j*tp/alpha,- 2*0.5*nu*t*mu0/lam0/alpha**2
	    return hop0_a,hop0_b,hop1
	else:
	    raise ValueError( "The hopping in " + str(direction) + " is not part of the model" )

    def hop_e( self,site2,site1,p ):
        hop0_a,hop0_b,hop1=self.hop(site2,site1,p)
        return hop0_a+hop0_b+hop1

    def hop_h( self,site2,site1,p ):
        hop0_a,hop0_b,hop1=self.hop(site2,site1,p)
        return -(hop0_a-hop0_b-hop1)

    
    def onsite( self, site, p ):

	x, = site.pos
	tp   =get_var(self.params,p,'tp')
	tz   =get_var(self.params,p,'tz')
	t    =get_var(self.params,p,'t')
	M0   =get_var(self.params,p,'M0')
	ky   =get_var(self.params,p,'ky')
	kz   =get_var(self.params,p,'kz')
	lBinv2=get_var(self.params,p,'lBinv2')
	b0   =get_var(self.params,p,'b0')
	betaz   =get_var(self.params,p,'betaz')

	alpha =get_var(self.params,p,'alpha')
	nu    =get_var(self.params,p,'nu')

	sinky,cosky = np.sin(ky),np.cos(ky)
	sinkz,coskz = np.sin(kz),np.cos(kz)
	mu0   = M0+t*(1-cosky)+tz*(1-coskz)
	lam0  = np.sqrt( mu0**2 + (tz*sinkz)**2 )
        #print "onsite"
        #print mu0,lam0
	ky_p  = ky + 2.*PI*lBinv2*float(x)

        #print tp*sin(ky_p),nu*lam0,nu*t*mu0/lam0/alpha**2
	onsite0 = tp*sin(ky_p) *sigma2 + (betaz/2. + nu*lam0 + nu*t*mu0/lam0/alpha**2) *sigma3
	onsite1 = -b0/2.*tz*sinkz/lam0 *(1 - t*mu0/lam0**2/alpha**2) *sigma0
	return onsite0,onsite1

    def onsite_e( self,site,p ):
        mu_W =get_var(self.params,p,'mu_W')
        onsite0,onsite1=self.onsite(site,p)
        return onsite0+onsite1+mu_W*sigma_0

    def onsite_h( self,site,p ):
        mu_W =get_var(self.params,p,'mu_W')
        onsite0,onsite1=self.onsite(site,p)
        return -(-onsite0-onsite1+mu_W*sigma_0)

