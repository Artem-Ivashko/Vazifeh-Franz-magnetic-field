#!/usr/bin/env python
# Filename weyl_SC.py 

# libraries    
import numpy as np
from numpy import pi as PI
import kwant

# my libraries
from paulimatrices import *
from memory import SimpleNamespace
from memory import get_var

    
""" Basis class of a Weyl-superconductor in Nambu basis """
class WeylSC(object):

    def __init__( self,params=None ):
	self.type = 'Weyl superconductor'
	self.params = params
    _tolerance = 10**(-6)

    # hoppings
    def _hop_x( self,p ):
        alpha=get_var(self.params,p,'alpha')
        tp   =get_var(self.params,p,'tp')/alpha
	t    =get_var(self.params,p,'t')/alpha**2
        return -0.5j*tp*s3s1  - 0.5*t*s1s0
    def _hop_y( self,p ):
        alpha=get_var(self.params,p,'alpha')
        tp  =get_var(self.params,p,'tp')/alpha
	t   =get_var(self.params,p,'t')/alpha**2
        return -0.5j*tp*s3s2  - 0.5*t*s1s0
    def _hop_z( self,p ):
        tzp =get_var(self.params,p,'tzp')
        tz  =get_var(self.params,p,'tz')
        return -0.5j*tzp*s2s0 - 0.5*tz*s1s0
    def hop_e( self,site2,site1,p ):
        pos1=site1.pos; pos2=site2.pos
	direction = [ pos2[d]-pos1[d] for d in range(self.dimension) ]
        distance2 = sum( [ dis**2 for dis in direction ] )
	if abs( distance2-direction[0]**2 )<self._tolerance:
	    return self._hop_x(p)
	elif abs( distance2-direction[1]**2 )<self._tolerance:
            return self._hop_y(p)
	elif abs( distance2-direction[2]**2 )<self._tolerance:
	    return self._hop_z(p)
	else:
	    raise ValueError( "The hopping in " + str(direction) + " is not part of the model" )
    def hop_h( self,site2,site1,p ):
        return -self.hop_e(site2,site1,p)

    # onsite energies
    def _term_chempot( self,p ):
        mu_W =get_var(self.params,p,'mu_W')
        return -mu_W*s0s0
    def _term_Mk( self,p ):
        alpha=get_var(self.params,p,'alpha')
        t  =get_var(self.params,p,'t')/alpha**2
        tz =get_var(self.params,p,'tz')
        M0 =get_var(self.params,p,'M0')
        return ( M0 + 2*t + tz ) * s1s0
    def _term_invbr( self,p ):
        b0 =get_var(self.params,p,'b0')
        return 0.5*b0*s2s3
    def _term_TRbr( self,p ):
        #betax  =get_var(self.params,p,'betax')
        #betay  =get_var(self.params,p,'betay')
        betaz  =get_var(self.params,p,'betaz')
        return 0.5*betaz*s0s3
    def _term_strain( self, p ):
        Lambda  =get_var(self.params,p,'Lambda')
        return Lambda*s2s0
    def _term_x( self,p ):
        alpha=get_var(self.params,p,'alpha')
        tp =get_var(self.params,p,'tp')/alpha
        t  =get_var(self.params,p,'t')/alpha**2
        kx =get_var(self.params,p,'kx')
        return +tp*np.sin(kx*alpha)*s3s1 - t*np.cos(kx*alpha)*s1s0
    def _term_y( self,p,x ):
        alpha=get_var(self.params,p,'alpha')
        tp     =get_var(self.params,p,'tp')/alpha
        t      =get_var(self.params,p,'t')/alpha**2
        ky     =get_var(self.params,p,'ky')
        return +tp*np.sin(ky*alpha)*s3s2 - t*np.cos(ky*alpha)*s1s0
    def _term_z( self,p ):
        tzp =get_var(self.params,p,'tzp')
        tz  =get_var(self.params,p,'tz')
        kz  =get_var(self.params,p,'kz')
        return +tzp*np.sin(kz)*s2s0 - tz*np.cos(kz)*s1s0
    def onsite_e( self, site, p ):
        return self._term_Mk(p) + self._term_chempot(p) + self._term_invbr(p) \
            + self._term_TRbr(p) + self._term_strain(p)
    def onsite_h( self, site, p ):
        return -self._term_Mk(p) - self._term_chempot(p) - self._term_invbr(p) \
            + self._term_TRbr(p) + self._term_strain(p)

    # pairing (is also a hopping between electron and hole lattice)
    def pairing( self,site2,site1,p ):
        pos1=site1.pos; pos2=site2.pos
        if pos1!=pos2: raise ValueError("Pairing must be local")
	Delta_W =get_var(self.params,p,'Delta_W')
        return Delta_W*s0s0


    
class WeylSC1D_x(WeylSC):

    def __init__( self,params=None ):
	self.type = '1D Weyl superconductor in x-direction'
	self.dimension= 1
	self.lat_e = kwant.lattice.general( ( (1,), ), name='e' )
        self.lat_h = kwant.lattice.general( ( (1,), ), name='h' )
	self.params = params

    def _term_y( self,p,x ):
        alpha=get_var(self.params,p,'alpha')
        tp     =get_var(self.params,p,'tp')/alpha
        t      =get_var(self.params,p,'t')/alpha**2
        ky     =get_var(self.params,p,'ky')
        lBinv2 =get_var(self.params,p,'lBinv2')
        x_shift=get_var(self.params,p,'x_shift')
        ky_p   = ky - float(x-x_shift)*float(lBinv2)
        return +tp*np.sin(ky_p*alpha)*s3s2 - t*np.cos(ky_p*alpha)*s1s0

        
    # hoppings
    def hop_e( self,site2,site1,p ):
        pos1=site1.pos; pos2=site2.pos
	direction = [ pos2[d]-pos1[d] for d in range(self.dimension) ]
        distance2 = sum( [ dis**2 for dis in direction ] )
	if abs( distance2-direction[0]**2 )<self._tolerance:
            return self._hop_x(p)
	else:
	    raise ValueError( "The hopping in " + str(direction) + " is not part of the model" )
    def hop_h( self,site2,site1,p ):
        return -self.hop_e(site2,site1,p)
            
    # onsite energies
    def onsite_e( self, site, p ):
        x,=site.pos
	return self._term_y(p,x) + self._term_z(p) + self._term_Mk(p) \
            + self._term_chempot(p) + self._term_invbr(p) \
            + self._term_TRbr(p) + self._term_strain(p)
    def onsite_h( self, site, p ):
        x,=site.pos
        return -self._term_y(p,-x+2*p.x_shift) - self._term_z(p) - self._term_Mk(p) \
            - self._term_chempot(p) - self._term_invbr(p) \
            + self._term_TRbr(p) + self._term_strain(p)

        
class WeylSC1D_z(WeylSC):

    def __init__( self,params=None ):
	self.type = '1D Weyl superconductor in z-direction'
	self.dimension= 1
	self.lat_e = kwant.lattice.general( ( (1,), ), name='e' )
        self.lat_h = kwant.lattice.general( ( (1,), ), name='h' )
	self.params = params
        WeylSC.__init__(self)

    # hoppings
    def hop_e( self,site2,site1,p ):
        pos1=site1.pos; pos2=site2.pos
	direction = [ pos2[d]-pos1[d] for d in range(self.dimension) ]
        distance2 = sum( [ dis**2 for dis in direction ] )
	if abs( distance2-direction[0]**2 )<self._tolerance:
            return self._hop_z(p)
	else:
	    raise ValueError( "The hopping in " + str(direction) + " is not part of the model" )
    def hop_h( self,site2,site1,p ):
        return -self.hop_e(site2,site1,p)
            
    # onsite energies
    def onsite_e( self, site, p ):
        lBinv2  =get_var(self.params,p,'lBinv2')
        x_shift=get_var(self.params,p,'x_shift')
        if abs(lBinv2)>10**(-12): raise ValueError( "weyl_SC.py: Magnetic field not implemented" )
	return self._term_x(p) + self._term_y(p,x=x_shift) + self._term_Mk(p) \
            + self._term_chempot(p) + self._term_invbr(p) \
            + self._term_TRbr(p) + self._term_strain(p)
    def onsite_h( self, site, p ):
        lBinv2  =get_var(self.params,p,'lBinv2')
        x_shift=get_var(self.params,p,'x_shift')
        if abs(lBinv2)>10**(-12): raise ValueError( "weyl_SC.py: Magnetic field not implemented" )
        return -self._term_x(p) - self._term_y(p,x=x_shift) - self._term_Mk(p) \
            - self._term_chempot(p) - self._term_invbr(p) \
            + self._term_TRbr(p) + self._term_strain(p)

    
class WeylSC2D_xy(WeylSC):

    def __init__( self,params=None ):
	self.type = '2D Weyl superconductor in xy-direction'
	self.dimension= 2
        self.lat_e = kwant.lattice.general( ( (1,0),(0,1) ), name='e' )
        self.lat_h = kwant.lattice.general( ( (1,0),(0,1) ), name='h' )
        self.params = params
        
    # hoppings
    def hop_e( self,site2,site1,p ):
        pos1,pos2=site1.pos,site2.pos
	direction = [ pos2[d]-pos1[d] for d in range(self.dimension) ]
        distance2 = sum( [ dis**2 for dis in direction ] )
	if abs( distance2-direction[0]**2 )<self._tolerance:
            x1,y1=pos1
            x2,y2=pos2
            tp     =get_var(self.params,p,'tp')
	    t      =get_var(self.params,p,'t')
            lBinv2 =get_var(self.params,p,'lBinv2')
            # Peierl's phase
            # the sign here depends on the definition of the electron charge
            phase = np.exp( -1j * (-lBinv2)*(x2-x1)*(y1+y2)/2. )
            return -0.5j*tp*phase*s3s1 - 0.5*t*phase*s1s0
        elif abs( distance2-direction[1]**2 )<self._tolerance:
            return self._hop_y(p)
	else:
	    raise ValueError( "The hopping in " + str(direction) + " is not part of the model" )
    def hop_h( self,site2,site1,p ):
        pos1,pos2=site1.pos,site2.pos
	direction = [ pos2[d]-pos1[d] for d in range(self.dimension) ]
        distance2 = sum( [ dis**2 for dis in direction ] )
	if abs( distance2-direction[0]**2 )<self._tolerance:
            x1,y1=pos1
            x2,y2=pos2
            tp     =get_var(self.params,p,'tp')
	    t      =get_var(self.params,p,'t')
            lBinv2 =get_var(self.params,p,'lBinv2')
            # Peierl's phase
            phase = np.exp( 1j * (-lBinv2)*(x2-x1)*(y1+y2)/2. )
            return 0.5j*tp*phase*s3s1 + 0.5*t*phase*s1s0
        elif abs( distance2-direction[1]**2 )<self._tolerance:
            return -self._hop_y(p)
	else:
	    raise ValueError( "The hopping in " + str(direction) + " is not part of the model" )

                    
    # onsite energies
    def onsite_e( self, site, p ):
	return self._term_z(p) + self._term_Mk(p) + self._term_chempot(p) + self._term_invbr(p) \
            + self._term_TRbr(p) + self._term_strain(p)
    def onsite_h( self, site, p ):
        return -self._term_z(p) - self._term_Mk(p) - self._term_chempot(p) - self._term_invbr(p) \
            + self._term_TRbr(p) + self._term_strain(p)

    
class WeylSC2D_xz(WeylSC):

    def __init__( self,params=None ):
	self.type = '2D Weyl superconductor in xz-direction'
	self.dimension= 2
	self.lat_e = kwant.lattice.general( ( (1,0),(0,1) ), name='e' )
        self.lat_h = kwant.lattice.general( ( (1,0),(0,1) ), name='h' )
	self.params = params

    # hoppings
    def hop_e( self,site2,site1,p ):
        pos1=site1.pos; pos2=site2.pos
	direction = [ pos2[d]-pos1[d] for d in range(self.dimension) ]
        distance2 = sum( [ dis**2 for dis in direction ] )
	if abs( distance2-direction[0]**2 )<self._tolerance:
            return self._hop_x(p)
        elif abs( distance2-direction[1]**2 )<self._tolerance:
            return self._hop_z(p)
	else:
	    raise ValueError( "The hopping in " + str(direction) + " is not part of the model" )
    def hop_h( self,site2,site1,p ):
        return -self.hop_e(site2,site1,p)
            
    # onsite energies
    def onsite_e( self, site, p ):
        x,z=site.pos
	return self._term_y(p,x) + self._term_Mk(p) + self._term_chempot(p) + self._term_invbr(p) \
            + self._term_TRbr(p) + self._term_strain(p)
    def onsite_h( self, site, p ):
        x,z=site.pos
        return -self._term_y(p,-x+2*p.x_shift) - self._term_Mk(p) - self._term_chempot(p) \
            - self._term_invbr(p) + self._term_TRbr(p) + self._term_strain(p)


class WeylSC2D_yz(WeylSC):

    def __init__( self,params=None ):
	self.type = '2D Weyl superconductor in yz-direction'
	self.dimension= 2
        self.lat_e = kwant.lattice.general( ( (1,0),(0,1) ), name='e' )
        self.lat_h = kwant.lattice.general( ( (1,0),(0,1) ), name='h' )
	self.params = params

    # hoppings
    def hop_e( self,site2,site1,p ):
        lBinv2  =get_var(self.params,p,'lBinv2')
        if abs(lBinv2)>10**(-12): raise ValueError( "weyl_SC.py: Magnetic field not implemented" )
        pos1,pos2=site1.pos,site2.pos
	direction = [ pos2[d]-pos1[d] for d in range(self.dimension) ]
        distance2 = sum( [ dis**2 for dis in direction ] )
	if abs( distance2-direction[0]**2 )<self._tolerance:
            return self._hop_y(p)
        elif abs( distance2-direction[1]**2 )<self._tolerance:
            return self._hop_z(p)
	else:
	    raise ValueError( "The hopping in " + str(direction) + " is not part of the model" )
    def hop_h( self,site2,site1,p ):
        return -self.hop_e(site2,site1,p)
            
    # onsite energies
    def onsite_e( self, site, p ):
	return self._term_x(p) + self._term_Mk(p) + self._term_chempot(p) \
            + self._term_invbr(p) + self._term_TRbr(p) + self._term_strain(p)
    def onsite_h( self, site, p ):
        return -self._term_x(p) - self._term_Mk(p) - self._term_chempot(p) \
            - self._term_invbr(p) + self._term_TRbr(p) + self._term_strain(p)



class WeylSC3D(WeylSC):

    def __init__( self,params=None ):
	self.type = '3D Weyl superconductor'
	self.dimension= 3
        self.lat_e = kwant.lattice.general( ( (1,0,0),(0,1,0),(0,0,1) ), name='e' )
        self.lat_h = kwant.lattice.general( ( (1,0,0),(0,1,0),(0,0,1) ), name='h' )
	self.params = params

    # hoppings
    def hop_e( self,site2,site1,p ):
        lBinv2  =get_var(self.params,p,'lBinv2')
        if abs(lBinv2)>10**(-12): raise ValueError( "weyl_SC.py: Magnetic field not implemented" )
        pos1,pos2=site1.pos,site2.pos
	direction = [ pos2[d]-pos1[d] for d in range(self.dimension) ]
        distance2 = sum( [ dis**2 for dis in direction ] )
	if abs( distance2-direction[0]**2 )<self._tolerance:
            return self._hop_x(p)
        elif abs( distance2-direction[1]**2 )<self._tolerance:
            return self._hop_y(p)
	else:
            return self._hop_z(p)
    def hop_h( self,site2,site1,p ):
        return -self.hop_e(site2,site1,p)
            
    # onsite energies
    def onsite_e( self, site, p ):
	return self._term_Mk(p) + self._term_chempot(p) \
            + self._term_invbr(p) + self._term_TRbr(p) + self._term_strain(p)
    def onsite_h( self, site, p ):
        return - self._term_Mk(p) - self._term_chempot(p) \
            - self._term_invbr(p) + self._term_TRbr(p) + self._term_strain(p)


