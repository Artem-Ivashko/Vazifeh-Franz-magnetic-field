#!/usr/bin/env python
# Filename weyl_SC.py 

# libraries
import numpy as np
from numpy import pi as PI
from numpy import sin,cos,sqrt
import kwant

# my libraries
from paulimatrices import *
from memory import SimpleNamespace
from memory import get_var


"""Twoband is Jakubs two-band model which is - up to O(b_0^3) -
equivalent to the Franz model arXiv:1303.5784. The x-dimension is
discretized on a 1D tight binding chain. In y- and z-direction we
assume periodic boundary conditions. This makes ky,kz good quantum
numbers.

"""
class WeylSC_1D_x(object):

    def __init__( self,params=None ):
	self.type = 'Jakubs two-band model -- on 1D lattice in x direction'
	self.dimension= 1
	self.lat_e = kwant.lattice.general( ( (1,), ), name='e' )
        self.lat_h = kwant.lattice.general( ( (1,), ), name='h' )
	self.params = params

    def hop( self,site2,site1,p ):
        pos1,pos2=site1.pos,site2.pos
	# verify that the hopping is acutally a hopping
	tolerance = 10**(-6)
	direction = [ pos2[d]-pos1[d] for d in range(self.dimension) ]
	distance2 = sum( [ dis**2 for dis in direction ] )
	if abs(distance2)<tolerance:
	    raise ValueError( "The hopping must have a finite distance" )

	x1, = site1.pos
	tp =get_var(self.params,p,'tp')
	tz =get_var(self.params,p,'tz')
	t  =get_var(self.params,p,'t')
	M0 =get_var(self.params,p,'M0')
	ky =get_var(self.params,p,'ky')
	kz =get_var(self.params,p,'kz')
	b0 =get_var(self.params,p,'b0')
	alpha =get_var(self.params,p,'alpha')
	nu  =get_var(self.params,p,'nu')
	
	if abs( distance2-direction[0]**2 )<tolerance:

	    sinkz = np.sin(kz); coskz = np.cos(kz)
	    sinky = np.sin(ky); cosky = np.cos(ky)
            mu0   = M0+t*(1-cosky)+tz*(1-coskz)
	    lam0 = np.sqrt( mu0**2 + (tz*sinkz)**2 )
	    hop0_a = - 0.5j*tp/alpha *sigma1
            hop0_b = - 0.5*nu*t*mu0/lam0/alpha**2 *sigma3
	    hop1 = -0.5*b0/2. *tz*sinkz/lam0 *t*mu0/lam0**2 /alpha**2 *sigma0
            #print "hop"
            #print - 0.5j*tp/alpha,- 2*0.5*nu*t*mu0/lam0/alpha**2
	    return hop0_a,hop0_b,hop1
	else:
	    raise ValueError( "The hopping in " + str(direction) + " is not part of the model" )

    def hop_e( self,site2,site1,p ):
        hop0_a,hop0_b,hop1=self.hop(site2,site1,p)
        return hop0_a+hop0_b+hop1

    def hop_h( self,site2,site1,p ):
        hop0_a,hop0_b,hop1=self.hop(site2,site1,p)
        return -(hop0_a-hop0_b-hop1)

    def onsite( self, site, p ):
	x, = site.pos
	tp   =get_var(self.params,p,'tp')
	tz   =get_var(self.params,p,'tz')
	t    =get_var(self.params,p,'t')
	M0   =get_var(self.params,p,'M0')
	ky   =get_var(self.params,p,'ky')
	kz   =get_var(self.params,p,'kz')
	lBinv2=get_var(self.params,p,'lBinv2')
	b0   =get_var(self.params,p,'b0')
	betaz   =get_var(self.params,p,'betaz')

	alpha =get_var(self.params,p,'alpha')
	nu    =get_var(self.params,p,'nu')

	sinky,cosky = np.sin(ky),np.cos(ky)
	sinkz,coskz = np.sin(kz),np.cos(kz)
	mu0   = M0+t*(1-cosky)+tz*(1-coskz)
	lam0  = np.sqrt( mu0**2 + (tz*sinkz)**2 )
	ky_p  = ky + 2.*PI*lBinv2*float(x)

	onsite0 = tp*sin(ky_p) *sigma2 + (betaz/2. + nu*lam0 + nu*t*mu0/lam0/alpha**2) *sigma3
	onsite1 = -b0/2.*tz*sinkz/lam0 *(1 - t*mu0/lam0**2/alpha**2) *sigma0
	return onsite0,onsite1

    def onsite_e( self,site,p ):
        mu_W =get_var(self.params,p,'mu_W')
        onsite0,onsite1=self.onsite(site,p)
        return onsite0+onsite1+mu_W*sigma_0

    def onsite_h( self,site,p ):
        mu_W =get_var(self.params,p,'mu_W')
        onsite0,onsite1=self.onsite(site,p)
        return -(-onsite0-onsite1+mu_W*sigma_0)

