#!/usr/bin/env python
# Filename ordering_sites.py 

# libraries


def make_site_dicts( sites ):
	"""
	Function for ordering the sites of a system in their physical order. 
	It can take several sublattices (families) and orders them with the 
	following priority: key1: site, key2: sublattice (family); if there
	are negative sites from translation symmetry or leads they will be 
	removed; if there are excess sites from translation symmetry they
	are NOT removed; the default ordering is: family:site

	Parameters
	----------
	sites : Takes sites of a (finalized) system or lead

	Returns
	---------
	s_enums : en enumeration of sites in the physical order. This means 
	it gives an enumertation that contains the original position of the 
	site and then the site properties 
	pos_dict : dictionary that gives the tags of the sites in their 
	physical order
	site_dict: a list of tupels in the physical order, each tupel 
	contains both the tag and the physical position of the site
	"""

	# sites= fsys.sites

	s_enum= enumerate(sites)
	s_enum= sorted( s_enum, key=lambda x: (x[1].tag[0], str(x[1].family)) )

	site_dict=[]
	site_order=[]
	for i in s_enum:
		site_order.append( i[0] )
		site_dict.append( [ i[0],list(i[1].tag), i[1].family.name ] )

	dr=[]; pr=[]
	for d in site_dict:
		for pos in d[1]:
			if pos<0:
				dr.append(d); pr.append(d[0])
				break

	for d in dr: site_dict.remove( d )
	for p in pr: site_order.remove( p )

	return (s_enum, site_order, site_dict)



  
