#!/usr/bin/env python
# Filename ideal_lead_sys.py

# libraries
from __future__ import division
import numpy as np
import kwant

# my libraries
from base_sys import BaseSystem

""" 
TABLE OF CONTENTS

IdealLead
"""


"""IdealLead desribes a bundel of 1 dimensional electron gas
'wires' on a cubic lattice. In other words, a 3D tight binding
hamiltonian where the hoppings are only along a single crystal axis.

Input
-----
model -- a model that contains information about the tight binding 
         Hamiltonian
lattice -- a kwant.lattice lattice
shape -- the shape of the system
params -- additional parameters such as (translation) symmetries

"""

class IdealLead(BaseSystem):

	def __init__( self,model,lattice,shape,params ):

		if hasattr( params, 'direction' ):
			self.direction = params.direction
		else:
			raise ValueError( "an ideal lead neads a direction in the parameters. x-axis is 0, y-axis is 1 and so on.")
		BaseSystem.__init__( self,model,lattice,shape,params )
		self.type = 'an ideal lead, i.e. a bundle of 1D chains'
		

	def _hoppings(self):
		# simple hoppings along the karthesian coordinates
		hoppings = []
		unitmatrix = np.eye(self.dimension)
		for d in range(self.dimension):
			if d==self.direction:
				hoppings.append( self._hopping( tuple(unitmatrix[d]) ) )
		return dict( hoppings )
