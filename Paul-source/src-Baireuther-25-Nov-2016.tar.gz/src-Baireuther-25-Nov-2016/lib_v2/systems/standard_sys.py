#!/usr/bin/env python
# Filename standard_sys.py

# libraries
from __future__ import division
import numpy as np
import kwant

# my libraries
from base_sys import BaseSystem

import paulimatrices as pm

""" 
TABLE OF CONTENTS

ParallelEdgesSystem
"""

"""ParallelEdgesSystem describes a basic system that has parallel
edges and is thus suitable for periodic boundary conditions. It takes
the same parameters as BaseSystem but adds an additions function to
implement periodic boundary conditions. It is assumend that the shape
of the system has parallel edges in the directions where the periodic
boundary conditions are set.

Input
-----
model -- a model that contains information about the tight binding 
         Hamiltonian
shape -- the shape of the system
params -- additional parameters such as boundary conditions and
          (translation) symmetries

"""
class ParallelEdgesSystem(BaseSystem):

	def __init__( self,model,lattice,shape,params,lattice_h=None ):
                print lattice_h
		BaseSystem.__init__( self,model,lattice,shape,params,lattice_h )
		self.type = 'A simple system with parallel edges which can have periodic boundary conditions'
		self._add_pbc()
		
	def _add_pbc( self ):
		dim = self.model.dimension
		for d in range(dim):
			if self.pbc[d]:
				hoppings = self._hoppings()
				for entry in hoppings.keys():
					direction = list( entry[0] )
					if direction[d] != 0:
						if direction[d] > 0:
							direction[d] -= self.LWH[d]
						else:
							direction[d] += self.LWH[d]

                                                if hasattr( self,'lat' ):
                                                        hopping_type,value = self._hopping( tuple(direction) )
                                                        self._add_hopping( hopping_type,value )
                                                if hasattr( self,'lat_e' ):
                                                        hopping_type,value = self._hopping_e( tuple(direction) )
                                                        self._add_hopping( hopping_type,value )
                                                if hasattr( self,'lat_h' ):
                                                        hopping_type,value = self._hopping_h( tuple(direction) )
                                                        self._add_hopping( hopping_type,value )
                                                        



class InfiniteMassBoundary(BaseSystem):
	'''This class describes a system with parallel edges
	and an infinite mass boundary condition. Currently it
	works only for the two band Franz model'''

	def __init__( self,model,lattice,shape,params ):
		BaseSystem.__init__( self,model,lattice,shape,params )
		self.params = params
		self.type = 'A simple system with parallel edges which can have periodic boundary conditions'

	# gets onsite energy from model and sets them
	def _onsite(self, site, p):

		L, = self.LWH
		x, = site.pos
		muadd = self.params.inf_left*np.exp(-x) + self.params.inf_right*np.exp(x+1-L)
#		print x,muadd
		return self.model.onsite( site.pos, p ) + muadd*pm.sigma3
