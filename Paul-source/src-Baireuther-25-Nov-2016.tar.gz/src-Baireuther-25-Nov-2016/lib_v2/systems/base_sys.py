
#!/usr/bin/env python
# Filename base_sys.py

# libraries
from __future__ import division
import numpy as np
import kwant


"""BaseSystem class describes a basic KWANT system. It consist of
a KWANT builder object. When initialized the onsite energies and
hoppings are set. It also contains an optional function to finalize
the builder object.

Input
-----
model -- a model that contains information about the tight binding 
         Hamiltonian
shape -- the shape of the system
params -- additional parameters such as boundary conditions and
          (translation) symmetries

"""
class BaseSystem(object):

	def __init__( self,model,lattice,shape,params,lattice_h=None ):
		self.type = 'A simple system, that has only onsite energy and predefined hoppings'
		# set parameters
		self.model = model
		self.shape = shape
                print lattice_h
                if lattice_h==None:
                        print "normal"
                        self.lat = lattice
                else:
                        print "Nambu"
                        self.lat_e = lattice
                        self.lat_h = lattice_h
                                        
		self.dimension = model.dimension

		if hasattr( params, 'LWH' ): self.LWH = params.LWH
		if hasattr( params, 'pbc' ): self.pbc = params.pbc
		else: self.pbc=[ False for i in range(model.dimension) ]
		if hasattr( params, 'translat_sym' ): self.translat_sym = params.translat_sym
		else: self.translat_sym = None

		# build system
		if self.translat_sym==None: 
			self.sys = kwant.Builder()
		else:
			self.sym = kwant.TranslationalSymmetry( self.translat_sym ) 
			self.sys = kwant.Builder( self.sym )
		self._add_sites()
		self._add_hoppings()
                if hasattr( self,'lat_e' ) and hasattr( self,'lat_h' ):
                        self._add_pairings()

		
	# gets onsite energy from model and sets them
	def _onsite(self, site, p):
		return self.model.onsite( site.pos, p )
        # Nambu
        def _onsite_e(self, site, p):
		return self.model.onsite_e( site.pos, p )
        def _onsite_h(self, site, p):
		return self.model.onsite_h( site.pos, p )
        
	def _onsites(self):

                if hasattr(self, 'lat_e') and hasattr(self, 'lat_h'):
                        print "have"
                        return { self.lat_e : self._onsite_e,  self.lat_h : self._onsite_h }
                else:
                        print "have not"
                        return { self.lat : self._onsite }


	def _add_sites( self ):
		for lat, onsite in self._onsites().iteritems():
			self.sys[ lat.shape(*self.shape) ] = onsite


	def _hoppings(self):
		# simple hoppings along the karthesian coordinates
		hoppings = []
		unitmatrix = np.eye(self.dimension)
                
                if hasattr( self,'lat' ):
		        for d in range(self.dimension):
			        hoppings.append( self._hopping( tuple(unitmatrix[d]) ) )
                if hasattr( self,'lat_e' ):
		        for d in range(self.dimension):
			        hoppings.append( self._hopping_e( tuple(unitmatrix[d]) ) )
                if hasattr( self,'lat_h' ):
		        for d in range(self.dimension):
			        hoppings.append( self._hopping_h( tuple(unitmatrix[d]) ) )
                return dict( hoppings )


        
        def _hopping( self,direction ):
                return ( direction,self.lat ) , lambda s1,s2,p:self._hop( s2,s1,p,'' )
                
	def _hopping_e( self,direction ):
                return ( direction,self.lat_e ) , lambda s1,s2,p:self._hop( s2,s1,p,'e' )
                
	def _hopping_h( self,direction ):
                return ( direction,self.lat_h ) , lambda s1,s2,p:self._hop( s2,s1,p,'h' )
                
                        


	# gets hoppings from model and sets them
	def _hop( self,site1,site2,p,name='' ):
		direction = []
		pos1=np.array(site1.pos)
		pos2=np.array(site2.pos)

		# for periodic boundary conditions
		for d in range(self.dimension):
			if self.pbc[d]==True:
				Wover2 = float(self.LWH[d])/2.
				if (pos2[d]-pos1[d])>Wover2:
					pos2[d]-=self.LWH[d]
				elif (pos2[d]-pos1[d])<-Wover2:
					pos2[d]+=self.LWH[d]
				if abs(pos2[d]-pos1[d])>Wover2:
					raise ValueError( "something went wrong with setting the periodic boundary conditions" )

                if name=='e':
                        return self.model.hop_e( pos1,pos2,p )
                elif name=='h':
                        return self.model.hop_h( pos1,pos2,p )
                else:
                        return self.model.hop( pos1,pos2,p )


	def _add_hoppings( self,shape_f=None ):
		for hopping_type,value in self._hoppings().iteritems():
			self._add_hopping( hopping_type,value,shape_f )  


	def _add_hopping( self,hopping_type,value,shape_f=None ):
		hops = kwant.builder.HoppingKind( *hopping_type )
		if shape_f is not None:
			hops = ( hop for hop in hops if shape_f(hop) )
		self.sys[hops] = value


        def _add_pairings( self,shape_f=None ):
		for hopping_type,value in self._hoppings().iteritems():
			self._add_hopping( hopping_type,value,shape_f )  


	def _add_hopping( self,hopping_type,value,shape_f=None ):
		hops = kwant.builder.HoppingKind( *hopping_type )
		if shape_f is not None:
			hops = ( hop for hop in hops if shape_f(hop) )
		self.sys[hops] = value


	def finalize(self):
		self.fsys = self.sys.finalized()

