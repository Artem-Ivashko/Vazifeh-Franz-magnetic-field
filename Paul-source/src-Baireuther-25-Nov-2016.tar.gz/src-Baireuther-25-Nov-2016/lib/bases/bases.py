#!/usr/bin/env python
# Filename bases.py 

# libraries
import numpy as np
from numpy import pi as PI

# Angular Momentum Eigenbasis
class AngularMomentumEigenbasis(object):
    """
    This class describes the eigenbasis of the 
    angular momentum operator.

    Parameters
    ----------
    L : number of sites
    """
    def __init__( self, L, ky_list=None ):
        self.type = 'Basis'
        # first determine the allowed angular momenta
        # k in the interval [-PI,PI)
        if ky_list==None:
            self.ky_list = []
            for n in range(L):
                k = 2.*PI/L*float(n)
                if k<PI:
                    self.ky_list.append(k)
                else:
                    self.ky_list.append(k-2*PI)
        else:
            self.ky_list = ky_list

        N = np.sqrt(L)
        self.vectors = np.array([  [ np.exp(1j*ky*n)/N for n in range(L) ] for ky in self.ky_list  ])

