#!/usr/bin/env python
# Filename post_cluster.py 

# libraries
import numpy as np
from numpy import pi as PI

def combine_data( data_raw, function_name ):
	'''
	This function combines all the output from a cluster calculation
	for a specific funciton (usually there is only one)
	It assumes that all the results from the cluster differs only 
	within the dictionary with is labled by the function's name. 
	It then combines the list of dictionaries into one single dictionary 
	with all the parameters that are not related to the function and one list
	with all the function related dictionaries.	
	'''
	# collect all the 'non data' information
	infos={}
	for el in data_raw[0]:
		if el!=function_name:
			infos[el] = data_raw[0][el]
	
	infos[function_name] = {}
	for el in data_raw[0][function_name]:
		if el!='_out':
			infos[function_name][el] = data_raw[0][function_name][el]

	data=[]
	for data_list in data_raw:
		for el in data_list[function_name]['_out']:
			data.append( el )
	
	return infos, data


	
