# libraries
from __future__ import division
import numpy as np
from numpy import pi as PI
from scipy.special import erf
from scipy.special import erfinv
import kwant
from time import time
import scipy.linalg
import paulimatrices as pm

''' The goal of this code is to check wether or not a scattering 
matrix has particle hole symmetry. While this task is simple if 
the electrons and holes live on the same lattice, i.e. via a 
Hamiltonian with a two by two structure, it is much harder 
when electrons and holes live on separate lattices. The reason 
is that the bases of the propagating modes, i.e. the side order, 
is random. The same holds for the order of the propagating modes 
in each lead. To deal with this problem we first order the 
propagating modes in the following way: First we separate 
incoming modes with negative velocity v<0 from outgoing modes 
with positive velocity v>0. We then order the modes is each 
subset such that the modulus of the velocity increases. '''


def check_symmetries( S, fsys, n1, n2 ):

	order_basis( S )
	gauge_wave_functions( fsys, S )

	lm = S.lead_info[ n1 ]
	vels = lm.velocities
	no_modes = np.size( vels )
	no_modes_half = int(no_modes/2)

	M = np.matrix(  np.around( S.data,10 )  )
	ty = np.matrix( np.kron( pm.sigma2,np.eye(no_modes_half) ) )

	MPH = np.array( M-ty*np.conj(M)*ty )
	MTR = np.array( M-M.T )

	PH=True; TR=True;
	for row in range(len(MPH)):
		for col in range(len(MPH[0])):
			if abs(MPH[row,col])>10**(-8):
				PH = False
				print row, col, abs(MPH[row,col])
			if abs(MTR[row,col])>10**(-8):
				TR = False
				print row, col, abs(MPH[row,col])
	if PH:
		print "Particle Hole Symmetry holds"
	else:
		print abs(M)

	if TR:
		print "Time Reversal Symmetry holds"
	else:
		print abs(M)

	return


''' This function preforms a basis change for the scatterin 
matrix S. The new basis is as follows: 
lead1 v11, lead1, v12, ..., lead2 v21, lead 2 v22, ... with |vx1| < |vx2| '''
def order_basis( S ):
	
	# do a basis change to the scattering matrix data
	T_in_subblocks = []
	for lead_no in S.in_leads:
		T_in_subblock,_ = order_modes( S,lead_no )
		T_in_subblocks.append( T_in_subblock )
	T_in = np.matrix( scipy.linalg.block_diag( *T_in_subblocks ) )

	T_out_subblocks = []
	for lead_no in S.out_leads:
		_,T_out_subblock = order_modes( S,lead_no )
		T_out_subblocks.append( T_out_subblock )
	T_out = np.matrix( scipy.linalg.block_diag( *T_out_subblocks ) )

	S.data = T_out*S.data*T_in.T

	# adjust the lead informations

	for leads in [ S.in_leads, S.out_leads ]:
		for lead_no in leads:
			lm = S.lead_info[ lead_no ]
			vels_enum = enumerate( lm.velocities )
			vels_enum = sorted( vels_enum, key=lambda v: (np.sign(v[1]),np.abs(v[1])) )
			vels_order=[]
			for entry in vels_enum:
				vels_order.append( entry[0] )

			lm.velocities = lm.velocities[ vels_order ]
			lm.momenta = lm.momenta[ vels_order ]
			lm.wave_functions = lm.wave_functions[ :,vels_order]

	return
				 

''' This function generates two real and hermitian matrices. 
One for incoming modes, one for outgoing modes. They are 
subblocks of a larger basis change matrix which reorders 
the basis of a scattering matrix in such a way that |v1|<|v2|. '''
def order_modes( S, lead_no ):

	# get the propagating modes and their velocities of lead number lead_no
	lm = S.lead_info[ lead_no ]
	vels = lm.velocities
#	print "the velocities of lead no", lead_no, "are", vels

	# separate incoming from outgoing mode velocities
	vels_in=[]; vels_out=[];
	for vel in vels:
		if vel<0:
			vels_in.append( vel )
		elif vel>0:
			vels_out.append( vel )
		else:
			raise ValueError( "warning, v=0 encountered" )
   
	# in order to construct the subblocks for the basis change we first need to know a prescription in which way we need to exchange the components of the basis vectors. To find this we first enumerate the lists with the mode velocities and sort them afterwards by increasing modulus. This ordered list is preceisely the prescription we need. The enumeration denote the components of the old basis.

		
	Ts = []
	for vels in [ vels_in, vels_out ]:
		vels_enum = enumerate(vels)
		vels_enum = sorted( vels_enum, key=lambda x: ( np.abs(x[1]) ) )

		vels_dict=[]
		vels_order=[]
		for i in vels_enum:
			vels_order.append( i[0] )
#			vels_dict.append( [ i[0],i[1] ] )

		# we now use this prescription to generate a basis change matrix
		T = []
		L = np.size( vels_order )
		for i in vels_order:
			el = []
			for j in range(L):
				if i==j: 
					el.append( 1 )
				else: 
					el.append( 0 )
			T.append( el )
		Ts.append( T )

	return Ts


def gauge_wave_functions( fsys, S ):

	U_in_subblocks = []
	for lead_no in S.in_leads:
		U_in_subblock,_ = adjust_phases( fsys, S, lead_no )
		U_in_subblocks.append( U_in_subblock )
	U_in = np.matrix( scipy.linalg.block_diag( *U_in_subblocks ) )

	U_out_subblocks = []
	for lead_no in S.out_leads:
		_,U_out_subblock = adjust_phases( fsys, S,lead_no )
		U_out_subblocks.append( U_out_subblock )
	U_out = np.matrix( scipy.linalg.block_diag( *U_out_subblocks ) )

#	print np.angle(U_in)
#	print np.angle(U_out)
	S.data = U_out*S.data*U_in

'''	all_leads = list(   set(  list(S.in_leads)+list(S.out_leads)  )   )
	for lead_no in all_leads:
		S_lm = S.lead_info[ lead_no ]
		vels = S_lm.velocities
		no_modes = np.size( vels )

		site_order = get_site_order( fsys, S, lead_no )
		S_lm = S.lead_info[ lead_no ]
		S_lm.wave_functions = S_lm.wave_functions[ site_order,: ]
		for m in range(no_modes):
			phase = np.angle(S_lm.wave_functions[0,m])
			S_lm.wave_functions[:,m] = S_lm.wave_functions[:,m]/np.exp( 1j*phase )
'''


def adjust_phases( fsys, S, lead_no ):

	S_lm = S.lead_info[ lead_no ]
	vels = S_lm.velocities
	no_modes = np.size( vels )
	phases = get_phases( fsys, S, lead_no )

	in_phases = []
	out_phases = []
	for i in range(no_modes):
		if vels[i]<0:
			in_phases.append( np.exp(-1j*phases[i]) )
		elif vels[i]>0:
			out_phases.append( np.exp(1j*phases[i]) )
		else:
			raise ValueError( "mode with v=0" )
	return np.diag(in_phases), np.diag(out_phases)
	


def get_phases( fsys, S, lead_no ):
	
	S_lm = S.lead_info[ lead_no ]
	vels = list( sorted( S_lm.velocities, key=lambda v : (np.sign(v),np.abs(v)) ) )
	wfs = S_lm.wave_functions.T
	no_modes = np.size( vels )



#	print "no modes is",no_modes, "no sites is", no_sites, "corresponding velocities are", vels

	# get the basis of the wave functions, order the wave function so that the first element is the one with the smallest x-coordinate and if there are multiple such sites, than additionally with the smallest y-coordinate. Then take the phase of this first element to construct a basis transformation which makes this first element real for all wave functions.
	sites_order = get_site_order( fsys, S, lead_no )
	phases = [ np.angle( wfs[n][sites_order[0]] ) for n in range(no_modes) ]

#	print
#	print "lead no", lead_no#
#	print wfs[:,0:10]
#	print "phases", phases
#	print

	return phases

''' this function returns the tags of the sites in the following order. 
Key1: increasing x-coordinate, Key2: increasing y-coordinate '''
def get_site_order( fsys, S, lead_no ):

	S_lm = S.lead_info[ lead_no ]
	wfs = S_lm.wave_functions.T
	no_sites = np.size( wfs[0] )

	l = fsys.leads[ lead_no ]
	sites = [ l.site(s).pos for s in range(no_sites) ]
	sites_enum = enumerate( sites )
	sites_enum = list( sorted( sites_enum, key=lambda s : (s[1][0],s[1][1]) ) )

	site_order=[]
	for s in sites_enum:
		site_order.append( s[0] )

	return site_order

