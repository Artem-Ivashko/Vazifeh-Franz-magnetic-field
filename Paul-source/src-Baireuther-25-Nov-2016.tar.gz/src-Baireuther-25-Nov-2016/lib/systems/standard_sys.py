#!/usr/bin/env python
# Filename standard_sys.py

# libraries
from __future__ import division
import numpy as np
import kwant

# my libraries
from base_sys import BaseSystem

class ParallelEdgesSystem(BaseSystem):
	'''This class describes a system with parallel edges. 
	It can have onsite energies and next neighbor hoppings 
	as well as periodic boundary conditions'''

	def __init__( self,model,shape,params ):
		BaseSystem.__init__( self,model,shape,params )
		self.type = 'A simple system with parallel edges which can have periodic boundary conditions'
		self._add_pbc()
		
	def _add_pbc( self ):
		dim = self.model.dimension
		for d in range(dim):
			if self.pbc[d]:
				hoppings = self.model.hoppings()
				for entry in hoppings.keys():
					direction = list( entry[0] )
					if direction[d] != 0:
						if direction[d] > 0:
							direction[d] -= self.LWH[d]
						else:
							direction[d] += self.LWH[d]
						hopping_type,value = self.model.hopping( tuple(direction) )
						self._add_hopping( hopping_type,value ) 
				

