#!/usr/bin/env python
# Filename base_sys.py

# libraries
from __future__ import division
import numpy as np
import kwant


class BaseSystem(object):
	'''This class describes a simple system with onsite energies and hoppings'''
	def __init__( self, model, shape, params ):
		self.type = 'A simple system, that has only onsite energy and predefined hoppings'
		# set parameters
		self.model = model
		self.shape = shape
		self.dimension = model.dimension
		if hasattr( params, 'LWH' ): self.LWH = params.LWH
		if hasattr( params, 'pbc' ): self.pbc = params.pbc
		else: self.pbc=[ False for i in range(model.dimension) ]
		if hasattr( params, 'translat_sym' ): self.translat_sym = params.translat_sym
		else: self.translat_sym = None
		if hasattr( model, 'lat' ): self.lat = model.lat
		# build system
		if self.translat_sym==None: 
			self.sys = kwant.Builder()
		else:
			self.sym = kwant.TranslationalSymmetry( self.translat_sym ) 
			self.sys = kwant.Builder( self.sym )
		self._add_sites()
		self._add_hoppings()

	def _add_sites( self ):
		for lat, onsite in self.model.onsites().iteritems():
			self.sys[ lat.shape(*self.shape) ] = onsite

	def _add_hopping( self,hopping_type,value,shape_f=None ):
		hops = kwant.builder.HoppingKind( *hopping_type )
		if shape_f is not None:
			hops = ( hop for hop in hops if shape_f(hop) )
		self.sys[hops] = value

	def _add_hoppings( self,shape_f=None ):
		for hopping_type,value in self.model.hoppings().iteritems():
			self._add_hopping( hopping_type,value,shape_f )  

	def finalize(self):
		self.fsys = self.sys.finalized()



