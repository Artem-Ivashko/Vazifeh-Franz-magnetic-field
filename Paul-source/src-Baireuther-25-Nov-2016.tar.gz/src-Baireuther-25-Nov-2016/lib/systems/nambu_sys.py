#!/usr/bin/env python
# Filename nambu_sys.py

# libraries
from __future__ import division
import numpy as np
import kwant

# my libraries
from base_sys import BaseSystem


class NambuSystem( BaseSystem ):
	'''This class describes a Nambu system with onsite pairing'''
	def __init__( self,model,shape,params ):
		BaseSystem.__init__( self,model,shape,params )
		self.type = 'A simple Nambu system with onsite pairing'
		self._add_pairings()
		if self.pbc[1]: self._generate_pbc_y()

	def _add_pairings( self ):
		for hopping_type,value in self.model.pairings().iteritems():
			self._add_hopping( hopping_type, value )

	def _generate_pbc_y( self ):
		W = int( self.LWH[1] )
		# hoppings
		hoppings = self.model.hoppings()
		for hop in hoppings.keys():
			if hop[0][1]!=0:
				if hop[0][1]>0:
					direction = (hop[0][0],hop[0][1]-W)
				else:
					direction = (hop[0][0],hop[0][1]+W)
				if hop[1].name == 'e':
					hopping_type,value = self.model.hopping_e( direction )
					self._add_hopping( hopping_type,value ) 
				elif hop[1].name == 'h':
					hopping_type,value = self.model.hopping_h( direction )
					self._add_hopping( hopping_type,value ) 
				else:
					raise ValueError( 'Hopping type ' + str(hop[1]) \
											+ ' not recognized' )


class LongrangeNambuSystem( NambuSystem ):
	''' WARNING, currently hardcoded for 2D systems!!!
	This class generates a Nambu System with longrange pairing. 
	If periodic boundary conditions are applied the distance between
	paired sites must not exceed half the system width in the 
	direction of the periodic boundary conditions.'''
	def __init__( self,model,shape,params ):
		if model.dimension != 2:
			raise ValueError( "WARNING, currently hardcoded for 2D systems!!!" )
		self.cutoff_pair = params.cutoff_pair
		self.longrange_pairings = dict()
		NambuSystem.__init__( self,model,shape,params )
		self.type = 'A Nambu system with longrange hopping and pairing'
 		self._generate_longrange_pairings()
		if self.pbc[1]: 
			self._generate_pbc_y()
		self._add_longrange_pairings()

	def _generate_longrange_pairings( self ):
		cutoff_int = int( np.ceil(self.cutoff_pair) )
		cutoff2 = self.cutoff_pair**2
		for m in range( -cutoff_int,cutoff_int+1 ):
			for n in range( -cutoff_int, cutoff_int+1 ):
				if m**2+n**2<=cutoff2:
					kind,value = self.model.pairing( (m,n) )
					self.longrange_pairings[kind] = value

	def _generate_pbc_y( self ):
		W = int( self.LWH[1] )
		# hoppings
		hoppings = self.model.hoppings()
		for hop in hoppings.keys():
			dx = hop[0][0]; dy = hop[0][1]
			if dy>0:
				direction = (dx,dy-W)
			elif dy<0:
				direction = (dx,dy+W)
			if dy!=0:
				if hop[1].name == 'e':
					hopping_type,value = self.model.hopping_e( direction )
					self._add_hopping( hopping_type,value ) 
				elif hop[1].name == 'h':
					hopping_type,value = self.model.hopping_h( direction )
					self._add_hopping( hopping_type,value ) 
				else:
					raise ValueError( 'Hopping type ' + str(hop[1]) \
											+ ' not recognized' )

		hoppings = self.longrange_pairings
		for hop in hoppings.keys():
			dx = hop[0][0]; dy = hop[0][1]
			if dy!=0:
				if dy>0:
					direction = (dx,dy-W)
					direction_r = (-dx,-dy+W)
				else:
					direction = (dx,dy+W)
					direction_r = (-dx,-dy-W)

				kind,value = self.model.pairing( direction )
				self.longrange_pairings[kind] = value
				kind_r,value_r = self.model.pairing( direction_r )
				self.longrange_pairings[kind_r] = value_r
					

		# pairings
#		cutoff_int = int(np.ceil(self.cutoff_pair))
#		cutoff2 = self.cutoff_pair**2
#		for m in range( -cutoff_int,cutoff_int+1 ):
#			for n in range( -W+1,W ):
#				if m**2+(W-n)**2<=cutoff2:
#					kind, value = self.model.pairing( (m,-n) )
#					self.longrange_pairings[kind] = value
#					kind_r, value_r = self.model.pairing( (-m,n) )
#					self.longrange_pairings[kind_r] = value_r

	def _add_longrange_hoppings( self ):
		for hopping_type,value in self.longrange_hoppings.iteritems():
			self._add_hopping( hopping_type,value )

	def _add_longrange_pairings( self ):
		for hopping_type,value in self.longrange_pairings.iteritems():
			self._add_hopping( hopping_type,value ) 
	

		

