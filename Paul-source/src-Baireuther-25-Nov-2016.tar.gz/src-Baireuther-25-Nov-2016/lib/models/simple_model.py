#!/usr/bin/env python
# Filename simple_model.py

# libraries
from __future__ import division
import numpy as np
from numpy import pi as PI
import tinyarray
import kwant
import random

# my libraries
from memory import memoized
from memory import SimpleNamespace

class ElectronGas(object):
	'''
	Base class for a simple electron gas
	'''
	def __init__(self):
		self.type = 'electron gas base class'
        
	def onsite( self, site, p ):
		return -p.mu

	
	def hop( self, site1, site2, p ):
		if self.dim!=2:
			raise ValueError( "simple_model.py: Warning, class ElectronGas currently hacked for 2D models only")

		x1,y1 = site1.pos
		x2,y2 = site2.pos
		dx=abs(x2-x1)
		dy=abs(y2-y1)

		# hack for periodic boundary conditions in y-direction
		W=10**8
		if hasattr( p, 'W' ): 
			W = p.W
		while dy>W/2.:
			dy=abs(dy-W)

		dist = np.sqrt( dx**2+dy**2 )
		if abs(dist-1)<10**(-6):
			return -p.t
		elif abs(dist-np.sqrt(2))<10**(-6):
			return -p.tp
		else:
			raise ValueError( 'simple_model.py: currently hardcoded ' \
									+ 'for nextnearest neighbor hopping only; ' )


class ElectronGas2D(ElectronGas):
	'''
	This class describes a 2D free electron gas
	'''
	def __init__( self,lattice_name='' ):
		self.type = '2D free electron gas'
		ElectronGas.__init__(self)
		self.dim = 2
		self.dimension = 2
		self.lat = kwant.lattice.general( ( (1,0),(0,1) ), name=lattice_name )

	def onsites(self):
		return { self.lat : self.onsite }

	def hopping( self,direction ):
		return ( direction,self.lat ) , lambda s1,s2,p:self.hop( s2,s1,p )
	def hoppings(self):
		return dict( [self.hopping( (1,0) ),self.hopping( (0,1) ), \
						  self.hopping( (1,1) ),self.hopping( (1,-1) ) ])


class ElectronGasLead2D(ElectronGas2D):
	'''
	This class describes a 2D free electron gas.
	It is essentially equivalent to ElectronGas2D
	but the values for onsite energy and hopping
	are set when creating the lead via params, 
	not flexible'''
	
	def __init__( self,params,lattice_name='' ):
		ElectronGas2D.__init__( self,lattice_name )
		if hasattr( params, 'mu' ): self.mu = params.mu
		else: raise ValueError( 'no onsite energy specified' )
		if hasattr( params, 't' ): self.t = params.t
		else: raise ValueError( 'no hopping specified' )
		if hasattr( params, 'tp' ): self.tp = params.tp
		else: self.tp=None

		
	def onsite( self, site, p ):
		return -self.mu

	def hop( self, site1, site2, p ):

		x1,y1 = site1.pos
		x2,y2 = site2.pos
		dx=abs(x2-x1)
		dy=abs(y2-y1)

		# hack for periodic boundary conditions in y-direction
		W=10**8
		if hasattr( p, 'W' ): 
			W = p.W
		while dy>W/2.:
			dy=abs(dy-W)

#		print x1,y1,';',x2,y2
		dist = np.sqrt( dx**2+dy**2 )
		if abs(dist-1)<10**(-6):
#			print "t"  
			return -self.t
		elif abs(dist-np.sqrt(2))<10**(-6):
#			print "tp"
			return -self.tp
		else:
			raise ValueError( 'simple_model.py: currently hardcoded ' \
									+ 'for nextnearest neighbor hopping only; ' )



class DisorderedElectronGas2D(ElectronGasLead2D):
	'''
	This class describes a 2D free electron gas with disorder
	'''

	def __init__( self,params,lattice_name='' ):
		ElectronGasLead2D.__init__( self,params,lattice_name )
		if hasattr( params, 'mu' ): self.mu = params.mu
		else: raise ValueError( 'no onsite energy specified' )

	def onsite( self, site, p ):
		(x,y) = site.pos
		ret = -self.mu - p.U[x,y]
		return  ret

