#!/usr/bin/env python
# Filename franz_model.py 

# libraries
import numpy as np
from numpy import pi as PI
import kwant

# my libraries
from paulimatrices import *
from memory import SimpleNamespace


class Franz(object):
	'''
	This is the 3D parent class for the Franz model
	'''

	def __init__(self):
		self.type = 'Franz model'

	# define hoppings
	def hop_x( self, site1, site2, p ):
		lam=p.lam; t=p.t;
		return 1j*lam*s3s2 - t*s1s0

	def hop_y( self, site1, site2, p ):
		x,y,z = site1.pos
		lam=p.lam; t=p.t;
		phase = np.exp(2j*PI*p.Phi_z*x) * np.exp(-2j*PI*p.Phi_x*z)
		return -1j*lam*phase*s3s1 - t*phase*s1s0

	def hop_z( self, site1, site2, p ):
		lam_z=p.lam_z; t=p.t;
		return -1j*lam_z*s2s0 - t*s1s0

	def hopping( self,direction ):
		for i in range( len(direction) ):
			if direction[i]!=0:
				if i==0:
					print "direction", direction
					return ( direction,self.lat ) , lambda s1,s2,p:self.hop_x( s2,s1,p )
				elif i==1:
					return ( direction,self.lat ) , lambda s1,s2,p:self.hop_y( s2,s1,p )
				elif i==2:
					return ( direction,self.lat ) , lambda s1,s2,p:self.hop_z( s2,s1,p )																							
		raise ValueError('something went wrong.')

	def onsite( self, site, p ):
		(x, y, z) = site.pos
		termb0 = p.b0*s2s3
		termbvec = -p.bx*s1s1 + p.by*s1s2 + p.bz*s0s3
		return p.eps*s1s0 + termb0 + termbvec

	def disorder_box( self, site, p ):
		return (2. * uniform(repr(site), p.salt) - 1.) * p.width



class Franz3D(Franz):
	'''
	This class describes a 3D Franz model
	'''
	def __init__(self):
		self.type = '3D Franz model'
		self.dimension = 3
		self.lat = kwant.lattice.general( ( (1,0,0),(0,1,0),(0,0,1) ) )

	def hoppings( self ):
		nx = { ( (1,0,0),self.lat ) : lambda s1, s2, p : self.hop_x( s2,s1,p ) }
		ny = { ( (0,1,0),self.lat ) : lambda s1, s2, p : self.hop_y( s2,s1,p ) }
		nz = { ( (0,0,1),self.lat ) : lambda s1, s2, p : self.hop_z( s2,s1,p ) }
		return dict( nx.items() + ny.items() + nz.items() )

	def onsites( self ):
		return { self.lat : self.onsite }


class Franz2D(Franz):
	'''
	This class describes a 2D Franz model
	'''
	def __init__(self):
		self.type = '2D Franz model'
		self.dimension = 2
		self.lat = kwant.lattice.general( ( (1,0),(0,1) ) )

	def onsite( self, site, p ):
		(x, z) = site.pos
		ky_p = p.ky + 2.*PI*p.Phi_z*float(x) - 2*PI*p.Phi_x*float(z)
		term_y = 2.*p.lam*np.sin(ky_p)*s3s1 - 2.*p.t*np.cos(ky_p)*s1s0
		term_b0 = p.b0*s2s3
		term_bvec = -p.bx*s1s1 + p.by*s1s2 + p.bz*s0s3
		return p.eps*s1s0 + term_y + term_b0 + term_bvec

	def hoppings( self ):
		nx = { ( (1,0),self.lat ) : lambda s1, s2, p : self.hop_x( s2,s1,p ) }
		nz = { ( (0,1),self.lat ) : lambda s1, s2, p : self.hop_z( s2,s1,p ) }
		return dict( nx.items() + nz.items() )

	def onsites( self ):
		return { self.lat : self.onsite }


class Franz1D(Franz):
	'''
	This class describes an effective 1D Franz model
	in x-direction
	'''
	def __init__(self):
		self.type = '1D Franz model'
		self.dimension= 1
		self.lat = kwant.lattice.general( ( (1,), ) )

	def onsite( self, site, p ):
		(x,) = site.pos
#		print "site pos", x
		lam=p.lam; lam_z=p.lam_z; t=p.t; tz=p.tz; mu=p.mu

#		kyadd = p.Phi_z*float(x)
#		if abs(kyadd)>1:
#			print "a,p.Phi_z,x",  p.Phi_z, x
#			print "Bz*x", kyadd
		ky = p.ky + 2.*PI*p.Phi_z*float(x) - 2.*PI*p.Phi_y*float(x)
		kz = p.kz
		b0=p.b0; bx=p.bx; by=p.by; bz=p.bz;

		try:
		    muinf=p.muinf; x0=p.x0;
		except:
		    muinf=0; x0=0
		
		term_y = +2.*lam*np.sin(ky)*s3s1 \
					-2.*t  *np.cos(ky)*s1s0
		term_z = +2.*lam_z*np.sin(kz)*s2s0 \
					-2.*tz   *np.cos(kz)*s1s0

		term_b0 = b0*s2s3
		term_bvec = -bx*s1s1 + by*s1s2 + bz*s0s3
		return mu*s1s0 + mu_inf*(x-x0)**2*s1s0 + term_y + term_z + term_b0 + term_bvec 

	def hoppings( self ):
		return { ( (1,),self.lat ) : lambda s1, s2, p : self.hop_x( s1,s2,p ) }

	def onsites( self ):
		return { self.lat : self.onsite }


class Franz3DIdealLead(Franz3D):
	'''
	This class describes a lead for the 3D Franz model, 
	it has the same hoppings as the Franz3D model, 
	but only in one direction
	'''

	def __init__(self, direction=2):
		Franz3D.__init__(self)
		self.type = 'a ideal lead for the 3D Franz model'
		self.direction = direction

	def hoppings( self ):
		lat = self.lat

		if self.direction==0:
			return { ( (1,0,0),lat ) : lambda s1, s2, p : self.hop_x( s2,s1,p ) }
		if self.direction==1:
			return { ( (0,1,0),lat ) : lambda s1, s2, p : self.hop_y( s2,s1,p ) }
		if self.direction==2:
			return { ( (0,0,1),lat ) : lambda s1, s2, p : self.hop_z( s2,s1,p ) }

	def onsite( self, site, p ):
		return Franz3D.onsite( self, site, p ) - 2*p.eps/3. *s1s0

	def onsites( self ):
		return { self.lat : self.onsite }



class Franz2DIdealLead(Franz2D):
	'''
	This class describes a lead for the 2D Franz model, 
	it has the same hoppings as the Franz2D model, 
	but only in one direction
	'''

	def __init__(self, direction=1):
		Franz2D.__init__(self)
		self.type = 'a ideal lead for the 2D Franz model'
		self.direction = direction

	def hoppings( self ):
		lat = self.lat

		if self.direction==0:
			return { ( (1,0),lat ) : lambda s1, s2, p : self.hop_x( s2,s1,p ) }
		if self.direction==1:
			return { ( (0,1),lat ) : lambda s1, s2, p : self.hop_z( s2,s1,p ) }


	def onsite( self, site, p ):
		(x, z) = site.pos
		term_b0 = p.b0*s2s3
		term_bvec = -p.bx*s1s1 + p.by*s1s2 + p.bz*s0s3
		return p.eps*1./3.*s1s0 + term_b0 + term_bvec


	def onsites( self ):
		return { self.lat : self.onsite }


class Franz1DIdealLead(Franz1D):
	'''
	This class describes a lead for the 1D Franz model, 
	it has the same hoppings as the Franz1D model, 
	but only in one direction
	'''

	def __init__(self, direction=0):
		Franz1D.__init__(self)
		self.type = 'a ideal lead for the effective 1D Franz model'
		self.direction = direction

	def hoppings( self ):
		lat = self.lat

		if self.direction==0:
			return { ( (1,),lat ) : lambda s1, s2, p : self.hop_z( s2,s1,p ) }

	def onsites( self ):
		return { self.lat : self.onsite }

