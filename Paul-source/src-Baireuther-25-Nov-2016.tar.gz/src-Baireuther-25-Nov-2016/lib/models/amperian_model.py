
#!/usr/bin/env python
# Filename models_2D.py 

# libraries
from __future__ import division
import numpy as np
from numpy import pi as PI
import tinyarray
import kwant
import random

# my libraries
from memory import memoized
from memory import SimpleNamespace
from paulimatrices import *
from nambu_model import Nambu2D

class Pseudogap(Nambu2D):
	'''
	This class essentially adds the next nearest 
	and next next nearest neighbor hoppings which
	are needed to describe the pseudo gap phase.
	'''
	def __init__(self):
		Nambu2D.__init__(self)
		self.type = '2D pseudo gap model with up to next next' \
						+ 'nearest neighbor hoppings. ' \
						+ 'pairings are local.'

	def hop_e( self, site1, site2, p ):
		x1,y1 = site1.pos
		x2,y2 = site2.pos
		dx=abs(x2-x1)
		dy=abs(y2-y1)

		# hack for periodic boundary conditions in y-direction
		W=10**8
		if hasattr( p, 'W' ): 
			W = p.W
		while dy>W/2.:
			dy=abs(dy-W)

		dist = np.sqrt( dx**2+dy**2 )
		if abs(dist-1)<10**(-6):
			return -p.t
		elif abs(dist-np.sqrt(2))<10**(-6):
			return -p.tp
		elif abs(dist-2)<10**(-6):
			return -p.tpp
		elif abs(dist-np.sqrt(5))<10**(-6):
			return -p.tppp
		else:
			raise ValueError( 'amperian_model.py: currently hardcoded ' \
									+ 'for nextnext nearest neighbor hopping only; ' )

	def hop_h( self, site1, site2, p ):

		x1,y1 = site1.pos
		x2,y2 = site2.pos
		dx=abs(x2-x1)
		dy=abs(y2-y1)

		# hack for periodic boundary conditions in y-direction
		W=10**8
		if hasattr( p, 'W' ): 
			W = p.W
		while dy>W/2.:
			dy=abs(dy-W)

		dist = np.sqrt( dx**2+dy**2 )
		if abs(dist-1)<10**(-6):
			return -p.t_h
		elif abs(dist-np.sqrt(2))<10**(-6):
			return -p.tp_h
		elif abs(dist-2)<10**(-6):
			return -p.tpp_h
		elif abs(dist-np.sqrt(5))<10**(-6):
			return -p.tppp_h
		else:
			raise ValueError( 'amperian_model.py: currently hardcoded ' \
									+ 'for nextnext nearest neighbor hopping only; ' )

	def hoppings(self):
		return dict( [self.hopping_e( (1,0) ),self.hopping_e( (0,1) ), \
						  self.hopping_h( (1,0) ),self.hopping_h( (0,1) ), \
						  self.hopping_e( (1,1) ),self.hopping_e( (1,-1) ), \
						  self.hopping_h( (1,1) ),self.hopping_h( (1,-1) ), \
						  self.hopping_e( (2,0) ),self.hopping_e( (0,2) ), \
						  self.hopping_h( (2,0) ),self.hopping_h( (0,2) ),
						  self.hopping_e( (2,1) ),self.hopping_e( (1,2) ), \
						  self.hopping_h( (2,1) ),self.hopping_h( (1,2) ),
						  self.hopping_e( (2,-1) ),self.hopping_e( (1,-2) ), \
						  self.hopping_h( (2,-1) ),self.hopping_h( (1,-2) )] )

class BCS(Pseudogap):
	'''
	This class describes the pseudo gap phase
	with BCS like onsite pairing.
	'''
	def __init__(self):
		Pseudogap.__init__(self)
		self.type = '2D pseudogap model with up to next next' \
						+ 'nearest neighbor hoppings. ' \
						+ 'pairings are local.'
	


class LO2D(Pseudogap):
	'''
	This class describes a 2D LO superconductor
	'''	
	def __init__(self):
		Pseudogap.__init__(self)
		self.type = '2D pseudogap model with up to next next' \
						+ 'nearest neighbor hoppings. ' \
						+ 'pairings are local with a LO' \
						+ 'like spacial modulation.'

	def pair( self, site1, site2, p ):
		x1,y1 = site1.pos
		delta = p.delta
		gap=0
		for Ki in p.K:
			gap += 2.*np.cos( 2*Ki[0]*x1 + 2*Ki[1]*y1 )
		return delta * gap


class Amperian(Pseudogap):
	'''
	This class describes a 2D electron gas with Amperian pairing.
	Amperian pairing is such that two electrons at the same
	or close by points of the Brillouin zone are paired. This is in contrast
	to the BCS pairing where electrons with opposite momenta pair.
	'''
	def __init__(self):
		Pseudogap.__init__(self)
		self.type = '2D Amperian model'

	def pair( self, site1, site2, p ):
		@memoized
		def gaussian( s,d ):
			return np.exp( -d**2 / (2*s**2) )

		@memoized
		def C( s, jlim ):
			C_l=0.;
			for m in range(-jlim,jlim+1):
				for n in range(-jlim,jlim+1):
					C_l+= np.exp( -2. * (PI/s)**2 * (m**2+n**2) )
			return 2.*PI/s**2 * C_l

		def factor( Ki,s,x1,x2,y1,y2,W ):
			dx=abs(x2-x1)
			dy=abs(y2-y1)
			while dy>W/2.:
				dy=abs(dy-W)
			fx1 = np.exp( 1j*Ki[0]*(x2+x1) )
			fy1 = np.exp( 1j*Ki[1]*(y2+y1) )
			fx2 = gaussian( 1./float(s), dx )
			fy2 = gaussian( 1./float(s), dy )
			return fx1*fx2*fy1*fy2
	
		# code
		x1,y1 = site1.pos
		x2,y2 = site2.pos
		W=10**8
		if hasattr( p, 'W' ): 
			W = p.W
		gap=0.
		for Ki in p.K:
			# this is a bit of a hack, to get nodal- and maximum contact junctions
			phase = 1.
			if abs(Ki[0])<3.:
				phase = np.exp( 1j*p.phi )
			if abs(Ki[1])<3.:
				phase = np.exp( 1j*np.pi/8. )
			# end
			mKi = [ -k for k in Ki ]
			gap += factor( Ki, p.s, x1, x2, y1, y2, W ) * phase
			gap += factor( mKi, p.s, x1, x2, y1, y2, W ) * np.conj( phase )
		gap *= p.delta
		gap /= C( p.s, p.jlim )

		if np.abs(gap)>10**(-20):
			return gap
		else:
			return 0

	

		
		
