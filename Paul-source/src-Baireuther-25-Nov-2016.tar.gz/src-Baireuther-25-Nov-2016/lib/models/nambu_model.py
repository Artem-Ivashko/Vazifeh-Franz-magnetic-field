#!/usr/bin/env python
# Filename nambu_model.py

# libraries
from __future__ import division
import numpy as np
from numpy import pi as PI
import tinyarray
import kwant
import random

# my libraries
from memory import memoized
from memory import SimpleNamespace
from paulimatrices import *


class NambuBase(object):
	'''
	This class describes the most basic Nambu model
	'''
	def __init__(self):
		self.type = 'Nambu base class'
        
	def onsite_e( self, site, p ):
		return -p.mu

	def onsite_h( self, site, p ):
		return -p.mu_h

	def hop_e( self, site1, site2, p ):
		return -p.t

	def hop_h( self, site1, site2, p ):
		return -p.t_h

	def pair( self, site1, site2, p ):
		return p.delta


class Nambu2D(NambuBase):
	'''
	This class describes a 2D BCS superconductor
	'''
	def __init__(self):
		self.type = '2D BCS model'
		self.dimension = 2
		self.lat_e = kwant.lattice.general( ( (1,0),(0,1) ), name='e' )
		self.lat_h = kwant.lattice.general( ( (1,0),(0,1) ), name='h' )

	def onsites(self):
		return { self.lat_e : self.onsite_e,  self.lat_h : self.onsite_h }		

	def hopping_e( self,direction ):
		return ( direction,self.lat_e ) , lambda s1,s2,p : self.hop_e( s2,s1,p )
	def hopping_h( self,direction ):
		return ( direction,self.lat_h ) , lambda s1,s2,p : self.hop_h( s2,s1,p )
	def hoppings(self):
		return dict( [self.hopping_e( (1,0) ),self.hopping_e( (0,1) ), \
						  self.hopping_h( (1,0) ),self.hopping_h( (0,1) )] )

	def pairing( self,direction ):
		return ( direction,self.lat_h,self.lat_e ) , lambda s1,s2,p : self.pair( s2,s1,p )

	def pairings(self):
		return dict( [self.pairing( (0,0) )] )
