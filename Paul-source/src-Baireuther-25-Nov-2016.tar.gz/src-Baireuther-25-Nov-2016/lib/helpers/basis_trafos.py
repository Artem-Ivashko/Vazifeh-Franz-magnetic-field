#!/usr/bin/env python
# Filename basis_trafos.py

import numpy as np
from ordering_sites import make_site_dicts

def normalize( vec ):
    nvec = vec/np.sqrt( np.dot(vec,np.conj(vec)) )
    return nvec

def basis_trafo( smatrix, basis_new_in, basis_new_out, fsys ):
    """ 
    this function transforms a scattering matrix into a new basis
    currently HARDCODED for ONE incoming and ONE outgoing lead


    Parameters
    ----------
    smatrix : 'kwant.smatrix'
    basis : new basis
    fsys  : finalized system, needed to extract the ordering of sites

    Returns
    -------
    scatterin matrix in new basis: NOT a 'kwant.smatrix' but just the
    actual scattering matrix as a np.matrix

    Examples
    --------
    to be written
    """

    # get the current bases; note that there are different bases for each lead
    leads_in_tags = smatrix.in_leads
    leads_out_tags = smatrix.out_leads

    lead_in = smatrix.lead_info[ leads_in_tags[0] ]
    lead_out = smatrix.lead_info[ leads_out_tags[0] ]

    # get the order of sites in the system
    lead_in__s_enum, lead_in__site_order, lead_in__site_dict \
        = make_site_dicts(fsys.leads[ leads_in_tags[0] ].sites )
    lead_out__s_enum, lead_out__site_order, lead_out__site_dict \
        = make_site_dicts(fsys.leads[ leads_out_tags[0] ].sites )

    modes_in=[]; basis_in=[];
    modes_out=[]; basis_out=[];
    
    # note that velocities are always along the lead's translation symmetry
    dim_in = 0; dim_out=0
    for i in range( np.size(lead_in.velocities) ):
        if lead_in.velocities[i]<0:
            basis_in.append(  list( lead_in.wave_functions.T[i] )  )
            dim_in+=1
    for i in range( np.size(lead_out.velocities) ):
        if lead_out.velocities[i]>0:
            basis_out.append(  list( lead_out.wave_functions.T[i] )  )
            dim_out+=1
            
    basis_in  = np.asarray( [normalize(wave) for wave in basis_in ] )
    basis_out = np.asarray( [normalize(wave) for wave in basis_out] )

    U_in=[]; U_out=[]; 
    no_sites_in = np.size( basis_new_in[0] )
    no_sites_out = np.size( basis_new_out[0] )

#    print np.angle(basis_in)
#    print "dim incoming: " + str(dim_in)
#    print "number of sites: " + str(no_sites)
#    print "site order: " + str(lead_in__site_dict)

    for bo in range(dim_in):
        U_in.append( [] )
        for bn in range(dim_in):
            dotprod=0.
            for i in range(no_sites_in):
                dotprod += basis_in[bo][lead_in__site_order[i]] * np.conj(basis_new_in[bn][i] )
            U_in[bo].append( dotprod )
    for bo in range(dim_out):
        U_out.append( [] )
        for bn in range(dim_out):
            dotprod=0.
            for i in range(no_sites_out):
                dotprod += basis_out[bo][lead_out__site_order[i]] * np.conj(basis_new_out[bn][i] )
            U_out[bo].append( dotprod )
    U_in  = np.asmatrix( U_in  )
    U_out = np.asmatrix( U_out )

#    print "U: " + str( np.around( np.abs( np.array(U_out*np.conj(U_out.T)) ),2 ) )

    S_data = np.asmatrix( smatrix.data )
    
    return U_out.T*S_data*np.conj(U_in)

