from __future__ import division
import numpy as np

# 1D shape

def chain( LWH, margin=10**(-6) ):
	L, = LWH
	def shape( pos ):
		(x,) = pos
		cond_x = ( x>-margin and x<L+margin )
		return cond_x
	return shape, (0.,)

# 2D shapes
def square( LWH, margin=10**(-6) ):
	L,W = LWH
	def shape(pos):
		(x, y) = pos
		cond_x = ( x>-margin and x<L+margin )
		cond_y = ( y>-margin and y<W+margin )
		return cond_x and cond_y
	return shape, ( 0.,0. )

def angle_in( x,y ):
	if x>=0:
		a = np.arctan( y/x ) + np.pi/2.
	else:
		a = np.arctan( y/x ) - np.pi/2.
	a *=180/np.pi
	return a 

# 2D shapes
def rectangle( LWH, angle=0, offset=(0,0), origin=None, margin=10**(-6) ):
	L,W = LWH
	def shape(pos):
		(xi, yi) = pos
		xi -= offset[0]
		yi -= offset[1]
		x= np.cos(angle)*xi - np.sin(angle)*yi 
		y= np.sin(angle)*xi + np.cos(angle)*yi
		cond_x = ( x>-margin and x<L+margin )
		cond_y = ( y>-margin and y<W+margin )
        
		return cond_x and cond_y
	if origin == None:
		return shape, offset
	else:
		return shape, origin


# 2D shapes
def ribbon( LWH, angle=0, offset=(0,0), origin=None, margin=10**(-6) ):
	L,W = LWH
	def shape(pos):
		(xi, yi) = pos
		xi -= offset[0]
		yi -= offset[1]
		y = xi*np.tan( angle )
		Wp = float(W)/np.cos( angle )
		cond = ( yi < y+Wp+margin and yi > y-margin )
		return cond
	if origin==None:
		return shape, offset
	else:
		return shape, origin


# 2D shapes
def triangle( P1,P2,P3, margin=10**(-6) ):
	P1 = np.asarray( P1 )
	P2 = np.asarray( P2 )
	P3 = np.asarray( P3 )
	M = (P1+P2+P3)/3.
    
	# angles
	x1,y1,z1 = P2-P1
	x2,y2,z2 = P3-P2
	x3,y3,z3 = P1-P3    
	
#	print "angles", angle_in( x1,y1 ), angle_in( x2,y2 ), angle_in( x3,y3 )
    
	# The triangle is defined by its corners P1,P2,P3 and a point within the triangle P0
	def shape(pos):
		(x, y) = pos
		P = np.array( [x,y,0] )
        
		v0 = P3-P1
		v1 = P2-P1
		v2 = P-P1

		# Compute dot products
		dot00 = np.dot( v0,v0 )
		dot01 = np.dot( v0,v1 )
		dot02 = np.dot( v0,v2 )
		dot11 = np.dot( v1,v1 )
		dot12 = np.dot( v1,v2 )

		# Compute barycentric coordinates
		invDenom = 1 / (dot00 * dot11 - dot01 * dot01)
		u = (dot11 * dot02 - dot01 * dot12) * invDenom
		v = (dot00 * dot12 - dot01 * dot02) * invDenom

		# Check if point is in triangle
		return (u > -margin) and (v > -margin) and (u + v < 1+margin)
#	print len( (M[0],M[1]) )
	return shape, (M[0],M[1])

# 3D shapes
def cube( LWH, margin=10**(-6) ):
	L,W,H = LWH
	def shape(pos):
		(x, y, z) = pos
		cond_x = ( x>-margin and x<L+margin )
		cond_y = ( y>-margin and y<W+margin )
		cond_z = ( z>-margin and z<H+margin )
		return cond_x and cond_y and cond_z
	return shape, ( 0.,0.,0. )

def cylinder( Rmin,Rmax,H,margin=10**(-6) ):
	def shape(pos):
		( x,y,z ) = pos
		r = np.sqrt( x**2+y**2 )
		return ( r>Rmin-margin and r<Rmax+margin and z>-margin and z<H+margin )
	return shape, ( (Rmin+Rmax)/2.,0.,1. )
