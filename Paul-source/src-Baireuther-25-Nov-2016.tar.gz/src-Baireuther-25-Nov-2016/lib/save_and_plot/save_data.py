#load libraries to save and load data
import gzip
import cPickle

def save_data( data, path, fname ):
    f1 = gzip.open(path+fname+'.dat.gz','wb')
    cPickle.dump(data, f1)
    f1.close()
    return 0

def load_data( path, fname ):
    f1 = gzip.open( path+fname+'.dat.gz','rb')
    data = cPickle.load(f1)
    f1.close()
    return data


