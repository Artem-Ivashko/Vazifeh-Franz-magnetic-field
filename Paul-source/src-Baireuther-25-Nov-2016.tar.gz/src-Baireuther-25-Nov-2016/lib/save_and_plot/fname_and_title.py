#!/usr/bin/env python
# Filename fname_and_title.py 

# libraries
import numpy as np
from memory import SimpleNamespace

def make_fname_and_title( entries=[], omit=[], order=[], prefix='', sufix='', linewidth=50 ):
	fname = make_fname( entries, omit, order, prefix, sufix )
	title = make_title( entries, omit, order, prefix, sufix, linewidth )
	return fname,title

def make_fname( entries=[], omit=[], order=[], prefix='', sufix='' ):
	
	def include( key ):
		if key in omit:
			return False
		else:
			return True

	def entry_to_str( key, value, precision=5 ):
		if type(value) == float or type(value) == np.float64:
			entry_str = str(key) + "_" + str( np.around(value,precision) ) + '__'
		else:
			entry_str = str(key) + "_" + str( value ) + '__'	
		return shorten(  remove_special_chars( entry_str )  )

	def remove_special_chars( text ):
		text = str(text).replace(': ', '__')
		text = str(text).replace('.', 'p')
		text = str(text).replace('-', 'm')
		text = str(text).replace(', ', '_')
		text = str(text).replace(' ', '_')
		text = str(text).replace('(', '')
		text = str(text).replace(')', '')
		text = str(text).replace('False', 'no')
		text = str(text).replace('True', 'yes')
		text = str(text).replace('[]', 'none')
		return text

	def shorten( text ):
		text = str(text).replace('translat_sym', 'trans_inv')
		return text
		
	def ordered_pieces( pcs, order ):
		c=0
		for el in order:
			for pc in pcs:
				if el==pc[0]:
					pc[0]=c
					c+=1
		return list( sorted( pcs ) )
		
	# code
	pieces = []
	for el in entries:
		if type(el) == SimpleNamespace:
			d = el.__dict__
			for key in d.keys():
				if include(key):		
					pieces.append( [ key,entry_to_str( key,d[key] ) ] )
		elif type(el) == dict:
			d = el
			for key in d.keys():
				if include(key):
					pieces.append( [ key,entry_to_str( key,d[key] ) ] )
		elif type(el) == tuple:
			pieces.append( [ el[0],entry_to_str( el[0],el[1] ) ] )
		else:
			raise ValueError( "entry type "+str(type(el))+" not recognized" )
	pieces = ordered_pieces( pieces,order )

	fname = remove_special_chars( prefix )
	if len(prefix)>0:
		fname += '__'
	for pc in pieces:
		fname += str(pc[1])
	if sufix == '':
		fname = fname[:-2]
	else:
		fname+=remove_special_chars( sufix )
		
	return fname


def make_title( entries=[], omit=[], order=[], prefix='', sufix='', linewidth=30 ):
    
	def entry_to_str( key, value, precision=5 ):
		if type(value) == float or type(value) == np.float64:
			entry = str(key) + "=" + str( np.around(value,precision) ) + ', '
		else:
			entry = str(key) + "=" + str( value ) + ', '
		return entry

	def include( key ):
		if key in omit:
			return False
		else:
			return True

	def ordered_pieces( pcs, order ):
		c=0
		for el in order:
			for pc in pcs:
				if el==pc[0]:
					pc[0]=c
					c+=1
		return list( sorted( pcs ) )

	# code
	pieces=[]
	for el in entries:
		if type(el) == SimpleNamespace:
			d = el.__dict__
			for key in d.keys():
				if include(key):
					pieces.append( [ key,entry_to_str( key,d[key] ) ] )
		elif type(el) == dict:
			d = el
			for key in d.keys():
				if include(key):
					pieces.append( [ key,entry_to_str( key,d[key] ) ] )
		elif type(el) == tuple:
			pieces.append( [ el[0],entry_to_str( el[0],el[1] ) ] )
		else:
			raise ValueError( "entry type "+str(type(el))+" not recognized" )
	pieces = ordered_pieces( pieces, order )

	title = prefix
	l_prefix = len(prefix)
	if l_prefix>0:
		title += '\n'
	l=1
	for pc in pieces:
		title += str(pc[1])
		if len(title)-l_prefix-l*linewidth > 0:
			title += '\n ' 
			l+=1			
	if sufix == '':
		title = title[:-2]
	else:
		title+=sufix
    
	return title
