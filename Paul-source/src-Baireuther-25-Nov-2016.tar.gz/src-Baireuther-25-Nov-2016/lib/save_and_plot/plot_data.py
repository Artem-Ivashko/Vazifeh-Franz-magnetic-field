from __future__ import division

import numpy as np
from numpy import pi as PI
import matplotlib as plt

import memory
from memory import SimpleNamespace

#special plotting stuff
import matplotlib.cm as cm
import matplotlib.pyplot as plt
#from mpld3 import show_d3

#from mpld3 import plugins
#import mpld3
#mpld3.enable_notebook("//cdnjs.cloudflare.com/ajax/libs/d3/3.4.1/d3.min.js")


def forceAspect(ax,aspect=1):
    im = ax.get_images()
    extent =  im[0].get_extent()
    ax.set_aspect(abs((extent[1]-extent[0])/(extent[3]-extent[2]))/aspect)


def plot1D( x, y, params=SimpleNamespace() ):
	
	p = params
	figsize = (6,4)
	if hasattr( p, 'figsize' ):
		figsize = p.figsize

	fig, ax = plt.subplots( figsize=figsize )

	if hasattr( p, 'xlim' ):
		if p.xlim != None:
			ax.set_xlim( -p.xlim,p.xlim )
	if hasattr( p, 'ylim' ):
		if p.ylim != None:
			ax.set_ylim( -p.ylim,p.ylim )
	if hasattr( p, 'xmin' ) and hasattr( p, 'xmax' ):
		ax.set_xlim( p.xmin,p.xmax )
	if hasattr( p, 'ymin' ) and hasattr( p, 'ymax' ):
		ax.set_ylim( p.ymin,p.ymax )

	if hasattr( p, 'title' ):
		ax.set_title( p.title, size=14 )
	if hasattr( p, 'xlabel' ):
		ax.set_xlabel( p.xlabel, size=16 )
	if hasattr( p, 'ylabel' ):
		ax.set_ylabel( p.ylabel , size=16)

	marker = 'b.'
	if hasattr( p, 'marker' ):
		marker = p.marker

	# plot
	try:
		y[0][0]
		for el in y:
			ax.plot( x, el, marker )
	except:
			ax.plot( x, y, marker )

	if hasattr( p, 'hlines' ):
		for l in p.hlines:
			ax.hlines( l[0],l[1],l[2] )
	if hasattr( p, 'vlines' ):
		for l in p.vlines:
			ax.vlines( l[0],l[1],l[2] )

	if hasattr( p, 'fname' ):
		if p.fname!='':
			fig.savefig( p.fname, bbox_inches='tight' )

	return




def plot_unfolded_dispersion__both_bands__modulus( data, dotsize=10, band_range=[-4,4], eng_range=[-4,4], \
																		fname=None, title=None ):
	# sort
	kxs = sorted( list( set([ x[1] for x in data ]) ) )
	kys = sorted( list( set([ x[2] for x in data ]) ) )
	no_kxs = np.size( kxs )
	no_kys = np.size( kys )
	data_sorted = sorted( data, key=lambda x: (x[0],x[1],x[2],1.-x[4]) )

	bands = []
	kx = 10**6; ky = 10**6; bi=10**6; i=0; n=0
	for d in data_sorted:
		if bi!=d[0] or kx!=d[1] or ky!=d[2]:
			bands.append( (d[1],d[2],d[3],d[4]) )
			bi=d[0]
			kx=d[1]
			ky=d[2]

	# check uniqueness:
	bands_sorted = list(  sorted( bands, key=lambda x: (x[0],x[1]) )  )
	kx=10**6; ky=10**6; en=10**6;
	for tup in bands_sorted:
		if tup[0]==kx and tup[1]==ky and abs( abs(tup[2])-abs(en) ) > 10**6:
			print "Warning, there is a non unique value:", (kx,ky,en), tup, '\n'
		else:
			kx=tup[0]
			ky=tup[1]
			en=tup[2]


	# plot
	kxs=[]; kys=[]; engs=[]; weights=[];
	for x in bands:
		if x[2]>= band_range[0] and x[2]<=eng_range[1]:
			kxs.append( x[0] )
			kys.append( x[1] )
			engs.append( abs(x[2]) )
			weights.append( x[3] )

	xmin = min(kxs)
	xmax = max(kxs)
	ymin = min(kys)
	ymax = max(kys)

	# Make plot with vertical (default) colorbar
	fig, (ax1,ax2) = plt.subplots(1,2, sharey=True ,figsize=(13,6) )
	cax1 = ax1.scatter( kxs, kys, c=engs, s=dotsize, marker='s', cmap=plt.cm.get_cmap('OrRd'), \
								  linewidths=0, vmin=eng_range[0], vmax=eng_range[1] )
	ax1.set_xlim( xmin,xmax )
	ax1.set_ylim( ymin,ymax )
	position1=fig.add_axes([0.483,0.125,0.01,0.775])  ## the parameters are the specified position you set 
	cbar1 = fig.colorbar(cax1, cax = position1 )


	cax2 = ax2.scatter( kxs, kys, c=weights, s=dotsize, marker='s', cmap=plt.cm.get_cmap('OrRd'), \
								  linewidths=0, vmin=0, vmax=1 )
	ax2.set_xlim( xmin,xmax )
	ax2.set_ylim( ymin,ymax )

	position2=fig.add_axes([0.906,0.125,0.01,0.775])  ## the parameters are the specified position you set 
	cbar2 = fig.colorbar(cax2, cax = position2)
		            
#	forceAspect( ax1, aspect=1 )
#	forceAspect( ax2, aspect=1 )

	ax1.set_title( title )
	ax1.set_xlabel('kx')
	ax1.set_ylabel('ky')
	
	ax2.set_title( 'Unfolding quality' )
	ax2.set_xlabel('kx')
	ax2.set_ylabel('ky')


	fig.size=80
    
	if fname != None: 
		fig.savefig( fname+'.eps' )

	return


def plot_unfolded_dispersion( data, fname=None, title=None,eps=0., delta_eps=4., whichbands=[0,1], ):
	# sort
	kxs = sorted( list( set([ x[1] for x in data ]) ) )
	kys = sorted( list( set([ x[2] for x in data ]) ) )
	no_kxs = np.size( kxs )
	no_kys = np.size( kys )
	data_sorted = sorted( data, key=lambda x: (x[0],x[1],x[2],1.-x[4]) )
	
	bands = []
	kx = data_sorted[0][1]
	ky = data_sorted[0][2]
	w_max = 0.; i=0; n=0
	bi=0
	bands.append([])
	for d in data_sorted:
		if kx!=d[1] or ky!=d[2]:
			bands[bi].append( (data_sorted[n][1],data_sorted[n][2],data_sorted[n][3],data_sorted[n][4]) )
			kx=d[1]
			ky=d[2]
			w_max = 0
		if d[0]!=bi:
			bands.append([])
			bi+=1
		if d[4] > w_max:
			w_max = d[4]
			n=i
		i+=1
	bands[bi].append( (data_sorted[n][1],data_sorted[n][2],data_sorted[n][3],data_sorted[n][4]) )


	for bi in whichbands:
		engs = np.asarray( [ x[2] for x in bands[bi] ] )
		quality = np.asarray( [ x[3] for x in bands[bi] ] )

#		print np.size( engs )
		nrows, ncols =  no_kxs,no_kys
		en_grid = engs.reshape( (nrows, ncols) )
		en_grid = en_grid.T
		en_grid = np.flipud( en_grid )
		q_grid = quality.reshape( (nrows, ncols) )
		q_grid = q_grid.T
		q_grid = np.flipud( q_grid )
    
		xmin = min(kxs)
		xmax = max(kxs)
		ymin = min(kys)
		ymax = max(kys)

		# Make plot with vertical (default) colorbar
		fig, (ax1,ax2) = plt.subplots(1,2, sharey=True ,figsize=(13,6) )
		if delta_eps!=0:
			cax1 = ax1.imshow(en_grid, interpolation='None', extent=[xmin,xmax,ymin,ymax], vmin=eps-delta_eps, vmax=eps+delta_eps, cmap=cm.RdBu_r)
			position1=fig.add_axes([0.483,0.125,0.01,0.775])  ## the parameters are the specified position you set 
			cbar1 = fig.colorbar(cax1, cax = position1 )
			cax2 = ax2.imshow(q_grid, interpolation='None', extent=[xmin,xmax,ymin,ymax], vmin=0, vmax=1, cmap=cm.RdBu_r)
			position2=fig.add_axes([0.906,0.125,0.01,0.775])  ## the parameters are the specified position you set 
			cbar2 = fig.colorbar(cax2, cax = position2)
		else:
			cax = ax.imshow(grid, interpolation='None', extent=[xmin,xmax,ymin,ymax], cmap=cm.RdBu_r)
            


			fig1.colorbar(sc,cax=position) ## 


		forceAspect( ax1, aspect=1 )
		forceAspect( ax2, aspect=1 )

		ax1.set_title( title )
		ax1.set_xlabel('kx')
		ax1.set_ylabel('ky')

		ax2.set_title( 'Unfolding quality' )
		ax2.set_xlabel('kx')
		ax2.set_ylabel('ky')


		fig.size=80
    
		if fname != None: 
			if bi==0: 
				fig.savefig( fname+'_band_1.pdf' )
			if bi==1: 
				fig.savefig( fname+'_band_2.pdf' )

	return



def plot_unfolded_dispersion__biased( data, fname=None, title=None,eps=0., delta_eps=4., \
													  whichbands=[0,1], vicinity=0.1 ):
	# sort
	kxs = sorted( list( set([ x[1] for x in data ]) ) )
	kys = sorted( list( set([ x[2] for x in data ]) ) )
	no_kxs = np.size( kxs )
	no_kys = np.size( kys )
	data_sorted = sorted( data, key=lambda x: (x[0],x[1],x[2],1.-x[4]) )
	
	bands = []
	kx = data_sorted[0][1]
	ky = data_sorted[0][2]
	w_max = 0.; i=0; n=0
	bi=0
	bands.append([])
	for d in data_sorted:
		if kx!=d[1] or ky!=d[2]:
			kx=d[1]
			ky=d[2]
			# HACK: check if there is another ew pair with approximately the same weight 
			# but lower energy
			addn = 1
			nmin = 0
			emin = 10**6
			print d
			print data_sorted[n]
			print
			print
			while data_sorted[n+addn][1]==kx and data_sorted[n+addn][2]==ky:
				print "ok"
				if abs( data_sorted[n][4]-data_sorted[n+addn][4] ) < vicinity:
					print data_sorted[n][4]-data_sorted[n+addn][4]
					if data_sorted[n+addn][3]<emin:
						emin = data_sorted[n+addn][3]
						nmin = n+addn
						print emin
				addn += 1

			bands[bi].append( (data_sorted[nmin][1],data_sorted[nmin][2], \
										 data_sorted[nmin][3],data_sorted[nmin][4]) )
			w_max = 0
		if d[0]!=bi:
			bands.append([])
			bi+=1
		if d[4] > w_max:
			w_max = d[4]
			n=i
		i+=1

	emin = 10**6
	nmin = 0
	addn = 1
	while data_sorted[n+addn][1]==kx and data_sorted[n+addn][2]==ky:
		if abs( data_sorted[n][4]-data_sorted[n+addn][4] ) < vicinity:
			if data_sorted[n+addn][3]<emin:
				emin = data_sorted[n+addn][3]
				nmin = n+addn
		addn += 1
		try:
			data_sorted[n+addn]
		except:
			break

	bands[bi].append( (data_sorted[nmin][1],data_sorted[nmin][2], \
								 data_sorted[nmin][3],data_sorted[nmin][4]) )


	for bi in whichbands:
		engs = np.asarray( [ x[2] for x in bands[bi] ] )
		quality = np.asarray( [ x[3] for x in bands[bi] ] )

#		print np.size( engs )
		nrows, ncols =  no_kxs,no_kys
		en_grid = engs.reshape( (nrows, ncols) )
		en_grid = en_grid.T
		en_grid = np.flipud( en_grid )
		q_grid = quality.reshape( (nrows, ncols) )
		q_grid = q_grid.T
		q_grid = np.flipud( q_grid )
    
		xmin = min(kxs)
		xmax = max(kxs)
		ymin = min(kys)
		ymax = max(kys)

		# Make plot with vertical (default) colorbar
		fig, (ax1,ax2) = plt.subplots(1,2, sharey=True ,figsize=(13,6) )
		if delta_eps!=0:
			cax1 = ax1.imshow(en_grid, interpolation='None', extent=[xmin,xmax,ymin,ymax], vmin=eps-delta_eps, vmax=eps+delta_eps, cmap=cm.RdBu_r)
			position1=fig.add_axes([0.483,0.125,0.01,0.775])  ## the parameters are the specified position you set 
			cbar1 = fig.colorbar(cax1, cax = position1 )
			cax2 = ax2.imshow(q_grid, interpolation='None', extent=[xmin,xmax,ymin,ymax], vmin=0, vmax=1, cmap=cm.RdBu_r)
			position2=fig.add_axes([0.906,0.125,0.01,0.775])  ## the parameters are the specified position you set 
			cbar2 = fig.colorbar(cax2, cax = position2)
		else:
			cax = ax.imshow(grid, interpolation='None', extent=[xmin,xmax,ymin,ymax], cmap=cm.RdBu_r)
            


			fig1.colorbar(sc,cax=position) ## 


		forceAspect( ax1, aspect=1 )
		forceAspect( ax2, aspect=1 )

		ax1.set_title( title )
		ax1.set_xlabel('kx')
		ax1.set_ylabel('ky')

		ax2.set_title( 'Unfolding quality' )
		ax2.set_xlabel('kx')
		ax2.set_ylabel('ky')


		fig.size=80
    
		if fname != None: 
			if bi==0: 
				fig.savefig( fname+'_band_1.pdf' )
			if bi==1: 
				fig.savefig( fname+'_band_2.pdf' )

	return


def quasiparticle_map( data, fname=None, title=None,eps=0., delta_eps=4., whichbands=[0,1], ):
  
	# sort
	kxs = sorted( list( set([ x[1] for x in data ]) ) )
	kys = sorted( list( set([ x[2] for x in data ]) ) )
	no_kxs = np.size( kxs )
	no_kys = np.size( kys )
	data_sorted = sorted( data, key=lambda x: (x[0],x[1],x[2],1.-x[4]) )
	
	qps = []
	kx = data_sorted[0][1]
	ky = data_sorted[0][2]
	w_max = [0.,0.]; i=0; n=0
	bi=0
	qps.append([])
	for d in data_sorted:
		if kx!=d[1] or ky!=d[2]:
			qps[bi].append( 2*min(w_max) )
			kx=d[1]
			ky=d[2]
			w_max = [0,0]
		if d[0]!=bi:
			qps.append([])
			bi+=1
		if d[4] > w_max[0] or d[4] > w_max[1]:
			w_max = [ max(w_max), d[4] ]
			n=i
		i+=1
	qps[bi].append( 2*min(w_max) )


	for bi in whichbands:
		nrows, ncols =  no_kys,no_kxs
		qp_grid = np.array(qps[bi]).reshape( (nrows, ncols) )
		qp_grid = qp_grid.T
		qp_grid = np.flipud( qp_grid )
    
		xmin = min(kxs)
		xmax = max(kxs)
		ymin = min(kys)
		ymax = max(kys)

		print "xmin", xmin, "xmax", xmax, "ymin", ymin, "ymax", ymax

		# Make plot with vertical (default) colorbar
		fig, ax = plt.subplots(figsize=(13,8) )
		if delta_eps!=0:
			cax = ax.imshow(qp_grid, interpolation='None', extent=[xmin,xmax,ymin,ymax], vmin=0, vmax=1, cmap=cm.RdBu_r)
		else:
			cax = ax.imshow(grid, interpolation='None', extent=[xmin,xmax,ymin,ymax], cmap=cm.RdBu_r)
            
		cbar = fig.colorbar(cax)
		ax.set_title( title )
		ax.set_xlabel('kx')
		ax.set_ylabel('ky')

		fig.size=80
    
		if fname != None: 
			if bi==0: 
				fig.savefig( fname+'_band_1.pdf' )
			if bi==1: 
				fig.savefig( fname+'_band_2.pdf' )

	return



def local_DOS( data, fname=None, title=None, eps=0., delta_eps=4., whichbands=[0,1], ):
    
	# sort
	kxs = sorted( list( set([ x[1] for x in data ]) ) )
	kys = sorted( list( set([ x[2] for x in data ]) ) )
	no_kxs = np.size( kxs )
	no_kys = np.size( kys )
	data_sorted = sorted( data, key=lambda x: (x[0],x[1],x[2],1.-x[4]) )
	
	bands = []
	kx = data_sorted[0][1]
	ky = data_sorted[0][2]
	bi=0
	w_tot=0.
	bands.append([])
	for d in data_sorted:
		if kx!=d[1] or ky!=d[2]:
			bands[bi].append( w_tot )
			kx=d[1]
			ky=d[2]
			w_tot = 0
		if d[0]!=bi:
			bands.append([])
			bi+=1
		if d[3] >= eps-delta_eps and d[3] <= eps+delta_eps:
			w_tot += d[4]
	bands[bi].append(w_tot)


	for bi in whichbands:
		rho = np.asarray( bands[bi] )
		nrows, ncols =  no_kys,no_kxs
		rho_grid = rho.reshape( (nrows, ncols) )
		rho_grid = rho_grid.T
    
		xmin = min(kxs)
		xmax = max(kxs)
		ymin = min(kys)
		ymax = max(kys)

		# Make plot with vertical (default) colorbar
		fig, ax = plt.subplots(figsize=(13,8) )
		if delta_eps!=0:
			cax = ax.imshow(rho_grid, interpolation='None', extent=[xmin,xmax,ymin,ymax], vmin=0, vmax=1., cmap=cm.RdBu_r)
		else:
			cax = ax.imshow(grid, interpolation='None', extent=[xmin,xmax,ymin,ymax], cmap=cm.RdBu_r)
            
		cbar = fig.colorbar(cax)
		ax.set_title( title )
		ax.set_xlabel('kx')
		ax.set_ylabel('ky')

		fig.size=80
    
		if fname != None: 
			if bi==0: 
				fig.savefig( fname+'_band_1.pdf' )
			if bi==1: 
				fig.savefig( fname+'_band_2.pdf' )

	return 


def local_DOS_v2( data, fname=None, title=None, emin=0, emax=5, steps=200, \
						delta_eps=4., whichbands=[0,1], no_bands=2, aspect=1, mycmap='RdBu_r', vmax=1. ):
    
	engs=np.linspace(emin,emax,steps)
	# sort
	kxs = sorted( list( set([ x[1] for x in data ]) ) )
	kys = sorted( list( set([ x[2] for x in data ]) ) )
	no_kxs = np.size( kxs )
	no_kys = np.size( kys )
	print no_kxs
	print no_kys
	ediff = emax-emin
	data_sorted = sorted( data, key=lambda x: (x[0],x[2]) )
#	steps = np.size( engs )
	step = (max(engs)-min(engs) ) / float(steps)
	print "step",step

	ky = data_sorted[0][2]
	bi=0; ki=0; 
	rho_list = np.zeros( (no_bands,steps,no_kys) )

	for d in data_sorted:
		if ky!=d[2]:
			ky=d[2]
			ki += 1
		if d[0]!=bi:
			bi += 1
			ki = 0
		ei = int((d[3]-emin)/ediff*steps)
		if ei<steps and ei>=0:
			rho_list[bi][ei][ki] += d[4]


	for bi in whichbands:
		rho = rho_list[bi]

		# normalize
		norm = 1/2.*2*PI*step*no_kxs
		for i in range(steps):
			for ki in range(no_kys):
				rho[i][ki] /= norm

		nrows, ncols =  steps,no_kys
		rho_grid = rho.reshape( (nrows, ncols) )
		rho_grid = np.flipud( rho_grid )
    
		xmin = min(kys)
		xmax = max(kys)
		ymin = min(engs)
		ymax = max(engs)




		# Make plot with vertical (default) colorbar
		fig, ax = plt.subplots(figsize=(8,12) )
		if delta_eps!=0:
			cax = ax.imshow(rho_grid, interpolation='None', extent=[xmin,xmax,ymin,ymax], vmin=0,vmax=vmax, cmap=mycmap )
		else:
			cax = ax.imshow(grid, interpolation='None', extent=[xmin,xmax,ymin,ymax], cmap=mycmap )
            
		cbar = fig.colorbar(cax)
		ax.set_title( title )
		ax.set_xlabel('ky')
		ax.set_ylabel('e_in')

		forceAspect( ax, aspect=aspect )
    
		if fname != None: 
			if bi==0: 
				fig.savefig( fname+'_band_1.eps' )
			if bi==1: 
				fig.savefig( fname+'_band_2.eps' )

	return rho_grid


def local_DOS_v3( data, fname=None, title=None, emin=0, emax=5, steps=200, \
						kx_min=-PI, kx_max=PI, whichbands=[0,1], no_bands=2, aspect=1, \
							mycmap='RdBu_r', vmax=1., output=True ):
    
	engs=np.linspace(emin,emax,steps)
	# sort
	kxs = sorted( list( set([ x[1] for x in data ]) ) )
	kys = sorted( list( set([ x[2] for x in data ]) ) )
	no_kxs = np.size( kxs )
	no_kys = np.size( kys )
	ediff = emax-emin
	data_sorted = sorted( data, key=lambda x: (x[0],x[2]) )
	steps = np.size( engs )
	step = (max(engs)-min(engs) )/20.
	
	ky = data_sorted[0][2]
	bi=0; ki=0; 
	rho_list = np.zeros( (no_bands,steps,no_kys) )

	for d in data_sorted:
		if ky!=d[2]:
			ky=d[2]
			ki += 1
		if d[0]!=bi:
			bi += 1
			ki = 0
		ei = int((d[3]-emin)/ediff*steps)
		if ei<steps and ei>=0:
			kx = d[1]
			if kx>=kx_min and kx<=kx_max:
				rho_list[bi][ei][ki] += d[4]


	for bi in whichbands:
		rho = rho_list[bi]
		nrows, ncols =  steps,no_kys
		rho_grid = rho.reshape( (nrows, ncols) )
		rho_grid = np.flipud( rho_grid )
    
		xmin = min(kys)
		xmax = max(kys)
		ymin = min(engs)
		ymax = max(engs)

		if output:
			# Make plot with vertical (default) colorbar
			fig, ax = plt.subplots(figsize=(8,12) )
			cax = ax.imshow(rho_grid, interpolation='None', extent=[xmin,xmax,ymin,ymax], vmin=0,vmax=vmax, cmap=mycmap )

			cbar = fig.colorbar(cax)
			ax.set_title( title )
			ax.set_xlabel('ky')
			ax.set_ylabel('e_in')
			
			forceAspect( ax, aspect=aspect )
			
			if fname != None: 
				if bi==0: 
					fig.savefig( fname+'_band_1.pdf' )
				elif bi==1: 
					fig.savefig( fname+'_band_2.pdf' )

	return rho_grid



def local_DOS_v4( data, fname=None, title=None, emin=0, emax=5, steps=200, \
						delta_eps=4., whichbands=[0,1], no_bands=2, aspect=1, mycmap='RdBu_r', vmax=1. ):
    
	engs=np.linspace(emin,emax,steps)
	# sort
	kxs = sorted( list( set([ x[1] for x in data ]) ) )
	kys = sorted( list( set([ x[2] for x in data ]) ) )
	no_kxs = np.size( kxs )
	no_kys = np.size( kys )
	print no_kxs
	print no_kys
	ediff = emax-emin
	data_sorted = sorted( data, key=lambda x: (x[0],x[1]) )
#	steps = np.size( engs )
	step = (max(engs)-min(engs) ) / float(steps)
	print "step",step

	kx = data_sorted[0][1]
	ky = data_sorted[0][2]
	bi=0; ki=0; 
	rho_list = np.zeros( (no_bands,steps,no_kxs) )

	for d in data_sorted:
		if kx!=d[1]:
			kx=d[1]
			ki += 1
		if d[0]!=bi:
			bi += 1
			ki = 0
		ei = int((d[3]-emin)/ediff*steps)
		if ei<steps and ei>=0:
			rho_list[bi][ei][ki] += d[4]


	for bi in whichbands:
		rho = rho_list[bi]

		# normalize
		norm = 1/2.*2*PI*step*no_kys
		for i in range(steps):
			for ki in range(no_kxs):
				rho[i][ki] /= norm

		nrows, ncols =  steps,no_kxs
		rho_grid = rho.reshape( (nrows, ncols) )
		rho_grid = np.flipud( rho_grid )
    
		xmin = min(kxs)
		xmax = max(kxs)
		ymin = min(engs)
		ymax = max(engs)




		# Make plot with vertical (default) colorbar
		fig, ax = plt.subplots(figsize=(8,12) )
		if delta_eps!=0:
			cax = ax.imshow(rho_grid, interpolation='None', extent=[xmin,xmax,ymin,ymax], vmin=0,vmax=vmax, cmap=mycmap )
		else:
			cax = ax.imshow(grid, interpolation='None', extent=[xmin,xmax,ymin,ymax], cmap=mycmap )
            
#		cbar = fig.colorbar(cax)
		ax.set_title( title )
		ax.set_xlabel('kx')
		ax.set_ylabel('e_in')

		forceAspect( ax, aspect=aspect )
    
		if fname != None: 
			if bi==0: 
				fig.savefig( fname+'_band_1.eps' )
			if bi==1: 
				fig.savefig( fname+'_band_2.eps' )

	return rho_grid


def local_DOS_2D( data, fname=None, title=None, emin=0, emax=5, \
							whichbands=[0,1], no_bands=2, aspect=1, \
							mycmap='OrRd', vmax=1., hlines=[], vlines=[] ):
	"""
	Sum over the local density of states for an energy interval. 
	Then plot this as a color plot.
	"""
    
	# sort
	kxs = sorted( list( set([ x[1] for x in data ]) ) )
	kys = sorted( list( set([ x[2] for x in data ]) ) )
	no_kxs = np.size( kxs )
	no_kys = np.size( kys )

	data_sorted = sorted( data, key=lambda x: (x[0],x[1],x[2]) )


	bi=0; ky_i=0; kx_i=0;
	kx = data_sorted[0][1]; ky = data_sorted[0][2];
	rho_list = np.zeros( (no_bands,no_kys,no_kxs) )

	for d in data_sorted:
		if d[0]!=bi:
			bi += 1
		if kx!=d[1]:
			kx=d[1]
			kx_i+=1
			kx_i = np.mod( kx_i,no_kxs )
		if ky!=d[2]:
			ky=d[2]
			ky_i+=1
			ky_i = np.mod( ky_i,no_kys )
		if d[3]>=emin and d[3]<=emax:
			rho_list[bi][ky_i][kx_i] += d[4]

	kxmin = min(kxs)
	kxmax = max(kxs)
	kymin = min(kys)
	kymax = max(kys)

	print kxmin,kxmax,kymin,kymax

	for bi in whichbands:
		norm = 1/2. * (2*PI)**2
		print norm
		rho = rho_list[bi]/norm
		nrows, ncols =  no_kys,no_kxs
		rho_grid = rho.reshape( (nrows, ncols) )
		rho_grid = np.flipud( rho_grid )
    
		# Make plot with vertical (default) colorbar
		fig, ax = plt.subplots(figsize=(8,8) )
		cax = ax.imshow(rho_grid, interpolation='None', \
							 extent=[kxmin,kxmax,kymin,kymax], vmin=0,vmax=vmax, \
							 cmap=mycmap )
		for y in hlines:
			ax.hlines(y,kxmin,kxmax,linestyles='dotted')
		for x in vlines:
			ax.vlines(x,kymin,kymax,linestyles='dotted')

		cbar = fig.colorbar(cax)
		ax.set_title( title )
		ax.set_xlabel('kx')
		ax.set_ylabel('ky')

		forceAspect( ax, aspect=aspect )
    
		if fname != None: 
			if bi==0: 
				fig.savefig( fname+'_band_1.eps' )
			if bi==1: 
				fig.savefig( fname+'_band_2.eps' )

	return rho



def doping(data,bins=100,output=True):

	kxs = sorted( list( set([ x[1] for x in data ]) ) )
	kys = sorted( list( set([ x[2] for x in data ]) ) )
	ens=[]
	for d in data:
		if abs(d[0])<10**(-6) and d[4]>10**(-6):
			ens.append(d[3])
	ens = list( set(ens) )
	print "band bottom:",np.min(ens),"; band top:",np.max(ens)

	no_kxs = np.size( kxs )
	no_kys = np.size( kys )
	no_states = no_kxs*no_kys

	emin = np.min(ens)
	emax = np.max(ens)
	delta_e = emax-emin

	ens = np.linspace(emin,emax,bins)
	dos = np.zeros( (bins) )
	for d in data:
		if d[0]==0:
			i = int( (d[3]-emin)/delta_e * bins )
			if i == bins and (d[3]-emax)<10**(-6):
				i = bins-1
			try:
				dos[i] += d[4]/float(no_states)*2.
			except IndexError:
				if d[4]>10**(-6):
					print "warning, there following states was not considered: e=", \
						 d[3],"; emin=",emin,"; emax=",emax,"; i=",i

	doping=0
	dopings=[]
	for d in dos:
		doping+=d
		dopings.append(doping)

	if output:
		fig, (ax1,ax2) = plt.subplots(1,2, sharey=False,figsize=(13,6) )
		ax1.plot( ens,dos )
		ax1.set_xlabel('energy')
		ax1.set_ylabel('DOS')
		ax2.plot( ens,dopings )
		ax2.set_xlabel('chemical potential')
		ax2.set_ylabel('filling')

	return ens,dos,dopings
	
	
