from __future__ import division
import numpy as np
from warnings import warn as warn
from numpy import pi as PI


def DOS( dim,N,en,t=1.,delta=10**(-3),large_N_limit=False ):

	""" 
	Calculate density of states on a finite cubic lattice in dim dimensions 
	
	input
	------------
	dim - dimension
	N - number of lattice points in each direction
	en - energy
	t - hopping energy
	delta - evaluates the delta function as a lorentian with width delta
	large_N_limit - using a large N approximation shortens the calculation
	                by a factor of 2^dimension

	output
	-----------
	dos - density of states 
	"""

	if dim!=2:
		raise ValueError( "function currently only works for two dimensions" )
	if large_N_limit and N<100:
		warn( "The large N limit should not be used for sizes smaller than N=100" )
	if large_N_limit and np.mod(N,2)==1:
		warn( "The large N limit requires N to be even, automatically ajusted N to N+1" )
		N += 1

	def loc_dos( kx,ky ):
		return delta/PI * \
			 (  ( en/(2*t) + np.cos(kx) + np.cos(ky) )**2 + delta**2  ) ** (-1)
		

	dos = 0; norm = 1;
	if large_N_limit:
		for kx in np.linspace(0,PI-2*PI/float(N),N/2):
			for ky in np.linspace(0,PI-2*PI/float(N),N/2):
				dos += loc_dos( kx,ky )
		norm = 1. / (N/2.)**2 / (2*t)
	else:
		for kx in np.linspace(-PI,PI-2*PI/float(N),N):
			for ky in np.linspace(-PI,PI-2*PI/float(N),N):
				dos += loc_dos( kx,ky )
		norm = 1. / (N)**2 / (2*t)

	return norm * dos
