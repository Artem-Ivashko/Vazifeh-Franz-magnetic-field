#!/usr/bin/env python
# Filename dispersion_2D.py 

# libraries
import numpy as np
from numpy import pi as PI
import kwant
import math
import matplotlib.pylab as plt
import matplotlib.cm as cm
import operator
#import time

# helper classes and functions
class SimpleNamespace(object):
    """A simple container for parameters."""
    def __init__(self, **kwargs):
        self.__dict__.update(kwargs) 

###################################################### slightly altered ##
# Copyright 2011-2013 Kwant authors.
#
# This file is part of Kwant.  It is subject to the license terms in the
# LICENSE file found in the top-level directory of this distribution and at
# http://kwant-project.org/license.  A list of Kwant authors can be found in
# the AUTHORS file at the top-level directory of this distribution and at
# http://kwant-project.org/authors.


__all__ = ['Bands']

class BandsOld(object):
	"""
	Class of callable objects for the computation of energy bands.
	
	Parameters
	----------
	sys : 'kwant.system.InfiniteSystem'
	The low level infinite system for which the energies are to be
	calculated.
	
	args : tuple, defaults to empty
	Positional arguments to pass to the ``hamiltonian`` method.

	Notes
	-----
	An instance of this class can be called like a function.  Given a momentum
	(currently this must be a scalar as all infinite systems are quasi-1-d), it
	returns a NumPy array containing the eigenenergies of all modes at this
	momentum

	Examples
	--------
	>>> bands = kwant.physics.Bands(some_sys)
	>>> momenta = numpy.linspace(-numpy.pi, numpy.pi, 101)
	>>> energies = [bands(k) for k in momenta]
	>>> pyplot.plot(momenta, energies)
	>>> pyplot.show()
	"""

	def __init__(self, sys_x, sys_y, args=()):
		# t0 = time.time()
		self.ham_x = sys_x.cell_hamiltonian(args)
		if not np.allclose(self.ham_x, self.ham_x.T.conj()):
			raise ValueError('The cell Hamiltonian is not Hermitian.')
		hop_x = sys_x.inter_cell_hopping(args)
		self.hop_x = np.empty(self.ham_x.shape, dtype=complex)
		self.hop_x[:, : hop_x.shape[1]] = hop_x
		self.hop_x[:, hop_x.shape[1]:] = 0

		self.ham_y = sys_y.cell_hamiltonian(args)
		if not np.allclose(self.ham_y, self.ham_y.T.conj()):
			raise ValueError('The cell Hamiltonian is not Hermitian.')
		hop_y = sys_y.inter_cell_hopping(args)
		self.hop_y = np.empty(self.ham_y.shape, dtype=complex)
		self.hop_y[:, : hop_y.shape[1]] = hop_y
		self.hop_y[:, hop_y.shape[1]:] = 0

		# change to basis [(0,0),(0,1),...,(1,0),...]
		s_enum_x, pos_x, dic_x = make_site_dicts( sys_x )
		s_enum_y, pos_y, dic_y = make_site_dicts( sys_y )
		self.no_sites = np.size(pos_x)
		N = self.no_sites
		Sx=np.matrix( np.zeros((N,N)) )
		Sy=np.matrix( np.zeros((N,N)) )
		i=0
		for i in range(N):
			Sx[i,pos_x[i]]=1.
			Sy[i,pos_y[i]]=1.
			i += 1
        
		self.hop_x = Sx*np.matrix( self.hop_x )*Sx.T
		self.ham_x = Sx*np.matrix( self.ham_x )*Sx.T
		self.hop_y = Sy*np.matrix( self.hop_y )*Sy.T
		self.ham_y = Sy*np.matrix( self.ham_y )*Sy.T

		diffham = np.array(self.ham_x-self.ham_y)
		for myline in diffham:
			for myel in myline:
				if myel!=0+0j:
					print "WARNING, cell hamiltonian missmach."

	def __call__0ld(self, kx, ky):
		mat = self.hop_x * complex(math.cos(-kx), math.sin(-kx))
		mat += self.hop_y * complex(math.cos(-ky), math.sin(-ky))
		mat += mat.conjugate().transpose() + self.ham_x

		print np.around(mat,1)

		# s1=time.time()

		ret = np.linalg.eigh(mat)
		# s2=time.time()
		# print "diag time=" + str(s2-s1)

		return ( ret )


class Bands(object):

	def __init__( self,fsys,args=() ):
		s_enum, site_order, site_dict = make_site_dicts( fsys )
		Nx = (max( [ s[1][0] for s in site_dict ] )+1) /3
		Ny = (max( [ s[1][1] for s in site_dict ] )+1) /2
		cell=[]; cell_x=[]; cell_y=[]; cell_xy_r=[]; cell_xy_l=[];
		for s in site_dict:
			i=s[0]; x=s[1][0]; y=s[1][1]
			if x>=Nx and x<2*Nx and y<Ny:
				cell.append(i)
			elif x>=2*Nx and y<Ny:
				cell_x.append(i)
			elif x>=Nx and x<2*Nx and y>=Ny:
				cell_y.append(i)
			elif x>=2*Nx and y>=Ny:
				cell_xy_r.append(i)
			elif x<Nx and y>=Ny:
				cell_xy_l.append(i)
			elif x<Nx and y<Ny:
				# do nothing
				i=i
			else:
				raise ValueError("site belongs to no cell")


		self.ham = fsys.hamiltonian_submatrix( args=args, to_sites=cell, from_sites=cell )
		self.hop_x = fsys.hamiltonian_submatrix( args=args, to_sites=cell_x, from_sites=cell )
		self.hop_y = fsys.hamiltonian_submatrix( args=args, to_sites=cell_y, from_sites=cell )
		self.hop_xy_r = fsys.hamiltonian_submatrix( args=args, to_sites=cell_xy_r, from_sites=cell )
		self.hop_xy_l = fsys.hamiltonian_submatrix( args=args, to_sites=cell_xy_l, from_sites=cell )

		if not np.allclose(self.ham, self.ham.T.conj()):
			raise ValueError('The cell Hamiltonian is not Hermitian.')


	def __call__(self, kx, ky):

		mat = self.hop_x * complex(math.cos(-kx), math.sin(-kx))
		mat += self.hop_y * complex(math.cos(-ky), math.sin(-ky))
		mat += self.hop_xy_r * complex(math.cos(-kx), math.sin(-kx)) * complex(math.cos(-ky), math.sin(-ky))
		mat += self.hop_xy_l * complex(math.cos(kx), math.sin(kx)) * complex(math.cos(-ky), math.sin(-ky))
		mat += mat.conjugate().transpose() + self.ham
		ret = np.linalg.eigh(mat)

		return ( ret )

##################################################### end of kwant function


def make_site_dicts( fsys ):
	"""
	Function for ordering the sites of a system in their physical order. 
	It can take several sublattices (families) and orders them with the 
	following priority: key1: site, key2: sublattice (family)

	Parameters
	----------
	fsys : Takes finalized system
	
	Returns
	---------
	s_enums : en enumeration of sites in the physical order. This means 
	it gives an enumertation that contains the original position of the 
	site and then the site properties 
	pos_dict : dictionary that gives the tags of the sites in their 
	physical order
	site_dict: a list of tupels in the physical order, each tupel 
	contains both the tag and the physical position of the site
	"""

	sites= fsys.sites

	s_enum= enumerate(sites)
	s_enum= sorted( s_enum, key=lambda x: (x[1].tag[0], x[1].tag[1], str(x[1].family)) )
    
	# s_enum= sorted( s_enum, key=lambda x: x[1].family, reverse=True )
	# s_enum= sorted( s_enum, key=lambda x: x[1].tag[1] )    
	# s_enum= sorted( s_enum, key=lambda x: x[1].tag[0] )    

	site_dict=[]
	site_order=[]
	for i in s_enum:
		site_order.append( i[0] )
		site_dict.append( [ i[0],[i[1].tag[0],i[1].tag[1]] ] )

	dr=[]; pr=[]
	for d in site_dict:
		if d[1][0]<0 or d[1][1]<0:
			dr.append(d); pr.append(d[0])
	for d in dr: site_dict.remove( d )
	for p in pr: site_order.remove( p )

	return (s_enum, site_order, site_dict)
#################################################################################



def unfolded_bandstructure( fsys, p, no_bands, options, min_weight=0 ):

	"""
	Parameters
	----------
	fsys : finalized translational invariant system
	bands : The number of physical bands as an integer

	Returns
	---------
	bfi : number of physical bands
	energys : allowed energies as function of wave vectors
	overlap_list : best overlap of wave-functions with plane waves at given 
	wave vector
	"""
	# extract system properties
	bfi=no_bands
	bff=float( no_bands )
	bands = Bands( fsys, args=[p] );
	# u1=time.time()

	enum, pos, dic = make_site_dicts( fsys )

	no_of_sites = np.size( pos )/6
	dfi = no_of_sites/no_bands
	dff = float( dfi )
	NF  = 1./np.sqrt( dff )

	Nx=0; Ny=0; 
	for d in dic:
		if d[1][0]+1>Nx: Nx=d[1][0]+1
		if d[1][1]+1>Ny: Ny=d[1][1]+1
	Nx /= 3
	Ny /= 2
	no_sites=Nx*Ny*bfi

	# options
	if hasattr( options, 'kxvecs' ): 
		kxvecs = options.kxvecs
	else: 
		raise ValueError( "no kx-values defined" )

	if hasattr( options, 'kyvecs' ): 
		kyvecs = options.kyvecs
	else: 
		raise ValueError( "no ky-values defined" )
    
	no_kxvecs = np.size( kxvecs )
	no_kyvecs = np.size( kyvecs )

	if hasattr( options, 'plotme' ): 
		plotme = options.plotme
	else: plotme = False

	if hasattr( options, 'vmax' ): 
		vmax = options.vmax
	else: vmax = 0
	
	if hasattr( options, 'vmin' ): 
		vmin  = options.vmin
	else: vmin = 0

	if hasattr( options, 'fname' ): 
		fname = options.fname
	else: fname = None

	if hasattr( options, 'warnings' ): 
		warnings  = options.warnings
	else: Warnings = False

	if hasattr( options, 'BQPcut' ): 
		BQPcut = options.BQPcut
	else: BQPcut = False


    
	# initiate system variables
	res=[]

	# calculate bandstructure
	count=0
	for kx in kxvecs:
		for ky in kyvecs:
			eigenvals, eigenvecs = bands( kx,ky )
			waves = np.asarray(eigenvecs.T)
			eigensys=[]
			for i in range( np.size(eigenvals) ):
				eigensys.append( [eigenvals[i], waves[i]] )

			for b in range(bfi):
				# calulate plane wave at wave vector k
				pw = [] 
				for x in range(Nx):
					for y in range(Ny):
						if bfi==1:
							pw.append(  np.exp( 1j*kx/Nx * float(x) )*np.exp( 1j*ky/Ny * float(y) )  )
						elif bfi==2:
							if b==0:
								pw.append(  np.exp( 1j*kx/Nx * float(x) )*np.exp( 1j*ky/Ny * float(y) )  )
								pw.append(  0.  )
							elif b==1:
								pw.append(  0.  )
								pw.append(  np.exp( 1j*kx/Nx * float(x) )*np.exp( 1j*ky/Ny * float(y) )  )
						else:
							raise ValueError( "Currently only works for 1 or 2 bands")
				# #########################################
				pw /= np.sqrt(np.dot(pw,np.conj(pw)))    
				# find the wave functions that have the right momentum
				for ewpair in eigensys:
					w=[]
					for i in range(no_sites):
						w.append( ewpair[1][i] )
					w /= np.sqrt(np.dot(w,np.conj(w)))
					# #########################################

					# check overlap with plane wave
					weight = np.abs(  np.dot( w,np.conj(pw) )  )**2

					if weight>10**(3):
						print kx,ky,weight
						print w
						print pw
						print 
					if weight >= min_weight:
						res.append( (b, kx/float(Nx), ky/float(Ny), ewpair[0], weight)  )

	
	return np.array(res)




