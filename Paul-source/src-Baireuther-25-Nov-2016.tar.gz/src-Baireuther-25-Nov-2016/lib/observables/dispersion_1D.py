import numpy as np
import math
import kwant

def dispersion( fsys, args, p_BZ ):

	# calculate dispersion
	ks = []
	energy_list = []
	
	for p in args:
		bands = kwant.physics.Bands( fsys, args=[p] )
		ks = ks + list( p_BZ.momenta )
		energy_list = energy_list + [bands(k) for k in p_BZ.momenta]

	return { 'kvecs':ks, 'energies':energy_list}



###################################################### slightly altered
# Copyright 2011-2013 Kwant authors.
#
# This file is part of Kwant.  It is subject to the license terms in the
# LICENSE file found in the top-level directory of this distribution and at
# http://kwant-project.org/license.  A list of Kwant authors can be found in
# the AUTHORS file at the top-level directory of this distribution and at
# http://kwant-project.org/authors.

__all__ = ['Bands']

class Bands(object):
	"""
	Class of callable objects for the computation of energy bands.

	Parameters
	----------
	sys : `kwant.system.InfiniteSystem`
	The low level infinite system for which the energies are to be
	calculated.
	args : tuple, defaults to empty
	Positional arguments to pass to the ``hamiltonian`` method.
	
	Notes
	-----
	An instance of this class can be called like a function.  Given a momentum
	(currently this must be a scalar as all infinite systems are quasi-1-d), it
	returns a NumPy array containing the eigenenergies of all modes at this
	momentum

	Examples
	--------
	>>> bands = kwant.physics.Bands(some_sys)
	>>> momenta = numpy.linspace(-numpy.pi, numpy.pi, 101)
	>>> energies = [bands(k) for k in momenta]
	>>> pyplot.plot(momenta, energies)
	>>> pyplot.show()
	"""

	def __init__(self, sys, args=()):
		self.ham = sys.cell_hamiltonian(args)
		if not np.allclose(self.ham, self.ham.T.conj()):
			raise ValueError('The cell Hamiltonian is not Hermitian.')
		hop = sys.inter_cell_hopping(args)
		self.hop = np.empty(self.ham.shape, dtype=complex)
		self.hop[:, : hop.shape[1]] = hop
		self.hop[:, hop.shape[1]:] = 0

	def __call__(self, k):
		mat = self.hop * complex(math.cos(-k), math.sin(-k))
		mat += mat.conjugate().transpose() + self.ham
		return np.linalg.eigh(mat)

##################################################### end of kwant function


def make_site_dicts( fsys ):
	"""
	Function for ordering the sites of a system in their physical order. 
	It can take several sublattices (families) and orders them with the 
	following priority: key1: site, key2: sublattice (family)

	Parameters
	----------
	fsys : Takes finalized system

	Returns
	---------
	s_enums : en enumeration of sites in the physical order. This means 
	it gives an enumertation that contains the original position of the 
	site and then the site properties 
	pos_dict : dictionary that gives the tags of the sites in their 
	physical order
	site_dict: a list of tupels in the physical order, each tupel 
	contains both the tag and the physical position of the site
	"""

	sites= fsys.sites

	s_enum= enumerate(sites)
	s_enum= sorted( s_enum, key=lambda x: x[1].family, reverse=True )
	s_enum= sorted( s_enum, key=lambda x: x[1].tag[0] )    
    
	site_dict=[]
	pos_dict=[]
	for i in s_enum:
		pos_dict.append( i[0] )
		site_dict.append( [i[0],i[1].tag[0]] )
        
	return (s_enum, pos_dict, site_dict)
#################################################################################


def unfolded_bandstructure( fsys, p_sys, no_bands=1, no_sites=1, eps=0.00001371, \
									 k_min=0, k_max=0, no_kvecs=100, plot=True, ylim=0, \
									 warnings=True):
	"""
    
    
	Parameters
	----------
	fsys : finalized translational invariant system
	bands : The number of physical bands as an integer
	eps : shifts k-momenta slightly away from high symmetry points

	Returns
	---------
	bfi : number of physical bands
	energys : allowed energies as function of wave vectors
	overlap_list : best overlap of wave-functions with plane waves at given 
	wave vector
	"""

	bfi=no_bands
	bff=float( no_bands )
	bands = Bands( fsys, args=[p_sys] );

	enum, pos, dic = make_site_dicts( fsys )
	# remove sites that belong to the next (or previous) cell of the system
	dr=[]; pr=[]
	for d in dic:
		if d[1]<0:
			dr.append(d); pr.append(d[0])
	for d in dr: dic.remove( d )
	for p in pr: pos.remove( p )
	no_of_sites = np.size( pos )/bfi
	dfi = no_of_sites
	dff = float( no_of_sites )
	# #########################################
	
	# set variables, initiate lists
	energys=[]; overlap_list=[];
	for b in range(bfi):
		overlap_list.append([]);
		energys.append([]);
		for i in range(dfi*bfi):
			overlap_list[b].append([]);
	if k_min==0 and k_max==0:
		k_max = dfi*np.pi
		k_min = -k_max
	momenta=np.linspace( k_min+eps, k_max+eps, no_kvecs )
	##########################################

	# calculate bandstructure
	for k in momenta:
		eigenvals, eigenvecs = bands( k )
		waves = np.asarray(eigenvecs.T)
		eigensys=[]
		for i in range( np.size(eigenvals) ):
			eigensys.append( [eigenvals[i], waves[i]] )

		for b in range(bfi):
			overlap=0; j=0; # overlap with plane wave; site index

			# calulate plane wave at wave vector k
			pw = [] 
			for i in range(no_of_sites):
				N=float(no_of_sites)
				if b==0:
					pw.append( np.exp( 1j*k/N * float(i) ) )
					pw.append( 0. )
				if b==1:
					pw.append( 0. )
					pw.append( np.exp( 1j*k/N * float(i) ) )
				# #########################################

			# find the wave functions that have the right momentum
			for ewpair in eigensys:

				w=[]
				for p in pos:
					w.append( ewpair[1][p] )
				w /= np.sqrt(np.dot(w,np.conj(w)))
				# #########################################
                
				# check overlap with plane wave
				over_l = np.abs(  np.dot( w,np.conj(pw) )  )
				overlap_list[b][j].append(over_l)
				if over_l>overlap:
					overlap=over_l
					en_l = ewpair[0]
				# #########################################
				j += 1 # next "virtual band"
            
			energys[b].append( en_l ) 

	if plot:
		if ylim!=0: plt.ylim([-ylim,ylim])
		for b in range(bfi):
			plt.plot( momenta, energys[b], '.')

	return (bfi, energys, overlap_list)
