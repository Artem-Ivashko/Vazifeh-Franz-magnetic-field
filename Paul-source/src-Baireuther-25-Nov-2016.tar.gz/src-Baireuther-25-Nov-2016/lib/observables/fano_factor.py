#!/usr/bin/env python
# Filename fano_factor.py

from scipy.linalg import eigvalsh
import numpy as np

def fano_factor( S ):
	T_list = eigvalsh(S.dot(S.conj().transpose()))
	fano = np.sum([T*(1-T) for T in T_list])/np.sum(T_list)
	return fano

