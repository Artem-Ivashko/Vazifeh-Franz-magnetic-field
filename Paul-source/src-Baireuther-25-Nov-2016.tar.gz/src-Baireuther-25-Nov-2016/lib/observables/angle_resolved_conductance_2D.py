# General libraries
import matplotlib.colors as colors
import matplotlib.pyplot as plt
import matplotlib.cm as cm
import numpy as np
from numpy import pi as PI
import kwant

# My sourcecode
import basis_trafos
import bases
import ordering_sites
from memory import SimpleNamespace


def calc_ky_list( e_in, kx_list, t, tp, mu ):
	"""
	This function calculated the korrepsonding ky-vectors to the kx-vectors.
	Note that this functions is not entirely generic because it 'knows' that
	to each degenerated kx-value belongs a +-ky pair. Note that this function
	requires a ordered list of kx-values
	"""

	infos={}
	infos['warnings']=[]
    
	ky_list=[]
	sign = -1; kx_old=0.
	for kx in kx_list:
		# this asigns +- ky pairs to degenerated kx
		if abs(kx-kx_old)<10**(-6):
			sign = 1
		else:
			sign = -1
		kx_old=kx
		
		# old leads
		# arg = (e_in+mu)/(-2.*t) - np.cos(kx)
		# new leads
		arg = ( e_in+mu+2*t*np.cos(kx) ) / ( -2.*t -4.*tp*np.cos(kx) )

		if abs( arg ) <= 1:
			ky_list.append( sign*np.arccos( arg )  )
		elif abs( arg )>1.01:
			raise ValueError("WARNING: problem during calculation of ky. " \
								  + " arccos got an illegal argument. kx=" + str(kx) \
								  + ",  val=" + str( (e_in+mu)/(-2.*t) - np.cos(kx) ) )
		elif arg>1.:
			infos['warnings'].append( "WARNING: arccos got an illegal argument. kx=" + str(kx) \
											  + ",  val=" + str( (e_in+mu)/(-2.*t) - np.cos(kx) ) + " " \
											  + "HOWEVER, since it is almost 1 we proceed with " \
											  + "arccos( arg )=0" )
			ky_list.append( 0. )
		elif arg<-1.:
			infos['warnings'].append( "WARNING: arccos got an illegal argument. kx=" + str(kx) \
											  + ",  val=" + str( (e_in+mu)/(-2.*t) - np.cos(kx) ) + " " \
											  + "HOWEVER, since it is almost -1 we proceed with " \
											  + "arccos( arg )=-PI" )
			ky_list.append( -PI )

	return np.asarray( ky_list ), infos


def calc_cond( fsys, p_sys, p_in, p_out, leads_in, leads_out, e_in, vmin=10**(-3), vmax=1. ):

	# useful informations
	infos={}
	infos['warnings']=[]
	infos['warnings'].append( "WARNING: this code is currently hard coded for 2D electron gas leads" \
									  + " with E=-mu-2t*( cos(kx)+cos(ky) ) dispersion" )

	# choose a pair of incoming and outgoing leads
	l_in = leads_in[0]
	l_out = leads_out[0]

	# calc scattering matrix and total conductance for (l_in,l_out)
	S = kwant.smatrix( fsys, args=[p_sys], energy=e_in, out_leads=leads_out, in_leads=leads_in )
	cond = S.transmission( l_out, l_in )

	# get all the kx-vectors
	lead_in = S.lead_info[ l_in ]; lead_out = S.lead_info[ l_out ]
	vels_in = lead_in.velocities; vels_out = lead_out.velocities 
	kx_in_all = lead_in.momenta; kx_out_all = lead_out.momenta; 
	no_modes_lead_in = np.size( vels_in ); no_modes_lead_out = np.size( vels_out )
	# we are only interested in incoming modes of the incoming lead (v<0)
	# and the outgoing modes of the outgoing lead (v>0)
	kx_in_list=[]
	for i in range(no_modes_lead_in):
		if vels_in[i]<0:
			kx_in_list.append( kx_in_all[i] )
	kx_in_list = np.asarray( sorted( kx_in_list ) )
	kx_out_list=[]
	for i in range(no_modes_lead_out):
		if vels_out[i]<0:
			kx_out_list.append( kx_out_all[i] )
	kx_out_list = np.asarray( sorted( kx_out_list ) )
	no_modes_in = np.size( kx_in_list )
	no_modes_out = np.size( kx_out_list )
	infos['no incoming modes'] = no_modes_in
	infos['no outgoing modes'] = no_modes_out
 
	# calculate all the ky-vectors using the dispersion relation
	ky_in_list, infos['calc_ky_list in'] = calc_ky_list( e_in, kx_in_list, p_in.t, p_in.tp, p_in.mu  )
	ky_out_list, infos['calc_ky_list out'] = calc_ky_list( e_in, kx_out_list, p_out.t, p_out.tp, p_out.mu )

    
	# generate angular momentum eigenbasis from ky_unique
	pos = np.swapaxes( fsys.sites, 0, 1 )[1]
	pos = np.array( list(pos) ); 
	ypos = np.swapaxes( pos, 0, 1 )
	W = max(ypos[1])+1
	basis_in = bases.AngularMomentumEigenbasis( W, ky_in_list )
	basis_out = bases.AngularMomentumEigenbasis( W, ky_out_list )

	# transform the scattering matrix into the new basis
	S_new = basis_trafos.basis_trafo( S, basis_in.vectors, basis_out.vectors, fsys )
	# sanity check
	if leads_out[0]==1:
		absS2old = S.transmission(1,0)
	else:
		absS2old = S.transmission(0,0)
	absS2 = [ [abs(i)**2 for i in line] for line in np.array(S_new) ]
	Gtot = 0
	for l in absS2:
		for el in l:
			Gtot += el
	if (absS2old-Gtot)>10**(-6):
		infos['warnings'].append( "The basis transformation failed value T_old: " + str(absS2old) + " value T_new: " + str(absS2) )
    
	# calculate the angles in k-space "alpha" and
	# calculate real space incident angles "beta" from 
	# real space velocities 
	# since the function is hardcoded anyways we get the 
	# velocities by vx = 2t sin(kx), vy = 2t sin(ky)
	vx_in_list=[]; vy_in_list=[]; vx_out_list=[]; vy_out_list=[]
	beta_in_list=[]; beta_out_list=[]; alpha_in_list=[]; alpha_out_list=[]
	for i in range( no_modes_in ):
		kx = kx_in_list[i]
		ky = ky_in_list[i]
		vx = 2*p_in.t*np.sin(kx)
		vy = 2*p_in.t*np.sin(ky)
		alpha_in_list.append(  np.arctan( ky/kx )  )
		beta_in_list.append(  np.arctan( vy/vx )  )
	for i in range( no_modes_out ):
		kx = kx_out_list[i]
		ky = ky_out_list[i]
		vx = 2*p_out.t*np.sin(kx)
		vy = 2*p_out.t*np.sin(ky)
		alpha_out_list.append(  np.arctan( ky/kx )  )
		beta_out_list.append(  np.arctan( vy/vx )  )
	alpha_in_list = np.asarray( alpha_in_list )
	alpha_out_list = np.asarray( alpha_out_list )
	beta_in_list = np.asarray( beta_in_list )
	beta_out_list = np.asarray( beta_out_list )

	# PLOTS
	# create data tupels
	basegrid=[]; x=[]; y=[];
#	absS2 = [ [abs(i)**2 for i in line] for line in np.array(S_new) ]
	for i in range( no_modes_out ):
		for j in range( no_modes_in ):
			ky_in = ky_in_list[j]
			alpha_in = alpha_in_list[j]
			beta_in = beta_in_list[j]
			ky_out = ky_out_list[i]
			alpha_out = alpha_out_list[i]
			beta_out = beta_out_list[i]
			mytupel = ( ky_in,alpha_in,beta_in,ky_out,alpha_out,beta_out, absS2[i][j] )
			basegrid.append( mytupel )

	basegrid = np.asarray( sorted( basegrid, key=lambda el: (el[0],el[3])  ) )
	print ky_in_list


	return basegrid, infos



def plot_2D( basegrid, mycmap = 'rainbow', dot_size=30, axis='ky', log=False, K=0, vmin=10**(-4), vmax=1., title='', fname='' ):
        
	# sort tupels and extract plot data
	grid = sorted( basegrid, key=lambda el: el[6] )
	grid = np.swapaxes( grid, 0, 1 )

    
	ky_x = np.asarray( grid[0] )
	k_angle_x = 360/(2*PI)*np.asarray( grid[1] )
	r_angle_x = 360/(2*PI)*np.asarray( grid[2] )
	ky_y = np.asarray( grid[3] )
	k_angle_y = 360/(2*PI)*np.asarray( grid[4] )    
	r_angle_y = 360/(2*PI)*np.asarray( grid[5] )
	z = np.asarray( grid[6] )
        
	cm = plt.cm.get_cmap( mycmap )

	mynorm=None
	if log: 
		mynorm = colors.LogNorm()
        
	fig, ax = plt.subplots( figsize=(6,5) )
	if axis=='ky':
		cax = ax.scatter( ky_x, ky_y, c=z, s=dot_size,\
								vmin=vmin, vmax=vmax, cmap=cm, linewidths=0, norm=mynorm )
		ax.set_xlabel('ky_in', size=20)
		ax.set_ylabel('ky_out', size=20)
		ax.set_ylim(-PI,PI) 
		ax.set_xlim(-PI,PI) 
	elif axis=='k_angle':
		cax = ax.scatter( k_angle_x, k_angle_y, c=z, s=dot_size,\
								vmin=vmin, vmax=vmax, cmap=cm, linewidths=0, norm=mynorm )
		ax.set_xlabel('k_angle_in', size=20)
		ax.set_ylabel('k_angle_out', size=20)
		ax.set_ylim(-90,90) 
		ax.set_xlim(-90,90) 
	elif axis=='r_angle':
#		cax = ax.scatter( r_angle_x, r_angle_y, c=z, s=1+np.log(z/vmin)*dot_size,\
#								vmin=vmin, vmax=vmax,  cmap=cm, linewidths=0, norm=mynorm )
		cax = ax.scatter( r_angle_x, r_angle_y, c=z, s=dot_size,\
								vmin=vmin, vmax=vmax, cmap=cm, linewidths=0, norm=mynorm )
		ax.set_xlabel('r_angle_in', size=20)
		ax.set_ylabel('r_angle_out', size=20)
		ax.set_ylim(-90,90) 
		ax.set_xlim(-90,90) 


	if title=='':
		ax.set_title( 'Angle dependent conductance', size=15 )
	else:
		ax.set_title( title, size=15 )

	if K!=0:
		x=np.linspace(-4,4,2)
		lim = int(4/K)+1
		for i in range( -lim, lim+1 ):
			ax.plot( x, x+i*2.*K, linewidth=0.5, color='k' )

	cbar = fig.colorbar(cax, label="Probabilities" )

	if fname!='':
		extent = ax.get_window_extent().transformed(fig.dpi_scale_trans.inverted())
		fig.savefig( fname + '.eps', bbox_inches='tight' )

	return 0



def plot_1D( basegrid, parameter='ky_in', label='', title='', fname='', plotme=True, ylim=None ):
    
	""" 
	plots transmission (or reflection) as function
	of incoming waves

	returns:
	d_arr - contains the data of the plot
	"""

	i = 0
	xlim = PI
	if parameter=='k_angle_in':
		i = 1
		xlim=90
	elif parameter=='r_angle_in':
		i = 2
		xlim=90

	d={}
	for el in basegrid:
		try:
			d[ el[i] ]+=el[6]
		except KeyError:
			d[ el[i] ]=el[6]

	d_tupl = sorted( d.items(), key=lambda el: el[0]  )
	d_arr = np.swapaxes( np.array( d_tupl ), 0, 1 )

	if plotme:
		fig, ax = plt.subplots( figsize=(6,5) )
		ax.set_xlim( -xlim,xlim )
		if ylim!=None:
			ax.set_ylim( 0, ylim )
		ax.set_xlabel( parameter, size=15 )
		ax.set_ylabel( label + " probabilities", size=15 )

		if title=='':
			ax.set_title( 'Conductance as function of incoming waves \n', size=20 )
		else:
			ax.set_title( title, size=15 )

			ax.plot( d_arr[0], d_arr[1], linestyle='--', marker='o', color='black' )

		if fname!='':
			extent = ax.get_window_extent().transformed(fig.dpi_scale_trans.inverted())
			fig.savefig( fname + '.pdf', bbox_inches=extent.expanded(1.6, 1.6)) 


	return d_arr




def plot_BCS_vs_Andreev_Bragg( data_full, label='', title='', fname='', plotme=True, xlim=None, ylim=None ):
    
	""" 
	plots transmission (or reflection) as function
	of incoming waves

	returns:
	d_arr - contains the data of the plot
	"""

	ens = []
	rAns = []
	rAss = []
	for data in data_full:
		ens.append( data[0] )
		basegrid = data[2]
		
		rAn = 0
		rAs = 0
		no_modes_out={}
		for el in basegrid:
			try:
				no_modes_out[ el[2] ] += 1
			except KeyError:
				no_modes_out[ el[2] ]= 1
			if np.abs(el[2]+el[5])<10**(-1):
				rAn += el[6]
			else:
				rAs += el[6]

		no_modes_in = np.size( no_modes_out.keys() )
		rAns.append( rAn/float(no_modes_in) )
		rAss.append( rAs/float(no_modes_in) )

	if plotme:
		fig, ax = plt.subplots( figsize=(6,5) )
		if xlim!=None:
			ax.set_xlim( -xlim,xlim )
		if ylim!=None:
			ax.set_ylim( 0, ylim )
		ax.set_xlabel( "energies of incoming waves", size=15 )
		ax.set_ylabel( label + " probabilities", size=15 )

		if title=='':
			ax.set_title( 'Normal and specular Andreev reflection probabilities \n', size=20 )
		else:
			ax.set_title( title, size=15 )

		ax.plot( ens, rAns, '.', color=(1.0,0.2,0.2), label='normal Andreev' )
		ax.plot( ens, rAss, '.', color=(.25,0.0,0.8), label='Andreev-Bragg' )
		ax.legend(loc='upper right')

		if fname!='':
			extent = ax.get_window_extent().transformed(fig.dpi_scale_trans.inverted())
			fig.savefig( fname + '.pdf', bbox_inches=extent.expanded(1.6, 1.6)) 


	return ens, rAns, rAss
    
            



	


    
    
