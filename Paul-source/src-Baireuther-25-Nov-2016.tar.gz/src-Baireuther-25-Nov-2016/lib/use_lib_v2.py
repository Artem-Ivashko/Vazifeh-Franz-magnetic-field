import sys
import re

def init():
	newpath=[]
	for line in sys.path:
		newpath.append( re.sub( '/src/lib/','/src/lib_v2/', line, count=0, flags=0) )
	sys.path = newpath

