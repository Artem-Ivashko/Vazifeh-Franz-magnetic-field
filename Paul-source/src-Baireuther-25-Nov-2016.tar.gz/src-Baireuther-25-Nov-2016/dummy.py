import time

def functionA( a,b ):
	return a+b


def test( p1, p2 ):
	return {'p1+p2': p1+p2, 'p1*p2': p1*p2}

def delay( s ):
	time.sleep( s )
	return s

def fail( s=1. ):
	raise RuntimeError( "This is an intentional fail" )


def identifier( s=0 ):
	return "anuniqueidentifiermark"


def sumup( l ):
	return sum(l)

def F1( x ):
	return [2*x,1]

def F2( m,x,t=0 ):
	return m*x

def R( m,x ):
	return m+x
