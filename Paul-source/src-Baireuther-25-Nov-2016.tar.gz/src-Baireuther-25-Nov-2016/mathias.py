from cluster_tools.job import F, R, exec_job_list
import numpy as np
from math import pi

T = 1.4
Elist = np.linspace(-T,T,11)
nlist = np.linspace(1.6e+13, 2.8e+13, 13)*(0.4e-9)**2*1e4
Hxlist = np.linspace(0, 12, 11)

exec_job_list(range(49,52), '/home/diez/src/lao_sto/conductivity.py', [
  F('h_params', mu=0, H=Hxlist, theta=0, g=5, gL=1, tl=340, th=12.5, td=12.5, dE=60, dZ=20, dSO=5, pot=['Gaussian']),
  R('calc_sigma', params=F('h_params'), n=nlist, xi=5, E=Elist, Nphi=200, T=T, n_cut=1e-4,
    kF0=[(0.11*pi, 0.11*pi, 0.05*pi, 0.05*pi, -1, -1)], kFtol=1e-5, kFmaxiter=50, vdk=1e-6, ziman=False)
  ], n_jobs=1, ignore_version=True)
