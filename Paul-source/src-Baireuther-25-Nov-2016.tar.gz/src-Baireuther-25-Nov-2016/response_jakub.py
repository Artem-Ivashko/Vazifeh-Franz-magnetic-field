# coding: utf-8
# this is a module to calculate RESPONSE in 2 band model
import numpy as np
from numpy import sin, cos, sqrt
import matplotlib.pylab as plt

PI = np.pi

import scipy.optimize as opt

class SimpleNamespace(object):
    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)

# Just put here all your parameters
p = SimpleNamespace( bz = 0.6, mu = 6./2-0.3, tp = 2, tz = 1, b0 = 0.02, Lx = 250, ky = 0., kz = 0. )    
#p = SimpleNamespace( bz = 0.9, mu = 6./2+0.3, tp = 2, tz = 1, b0 = 0.01, Lx = 100, ky = 0., kz = 0. )    
    
def mass(p):
    """
    mass in our 1D equation, rescaled with tp
    energy shift from b0   , rescaled with tp
    """
    mkz = p.mu - 1 - cos(p.ky) - cos(p.kz)
    lmb = sqrt( mkz**2 + (p.tz*sin(p.kz))**2 )
    return ( (p.bz-lmb)/p.tp, - p.b0*p.tz*sin(p.kz)/lmb/p.tp )

def prefactor(p):
    """
    output: jz_z only # the simplest relevant form
    """
    mkz = p.mu - 1 - cos(p.ky) - cos(p.kz)
    lmb = sqrt( mkz**2 + (p.tz*sin(p.kz))**2 )
    
    dlmb_dkz = sin(p.kz)/lmb * ( mkz + p.tz**2*cos(p.kz) ) 
    jz_z = dlmb_dkz / p.tp
    #jz_0 = - p.b0*p.tz/lmb * (cos(p.kz)-sin(p.kz)/lmb*dlmb_dkz) / p.tp  # parametrically smaller with b0
    return jz_z

def energy_array(p,cutoff=0.2):
    """
    Solving eigenequation for energies, indexed with l = 1, 2, 3, ....
    """
    ens = []
    m, de = mass(p)
    sy = sin(p.ky) # !!! included

    nn=0; en=0;
    while abs(en) < cutoff:
        l = nn + 1
        if m > 0:
           z = opt.brentq(lambda x: np.tan(x) - (PI*l+x)/m/p.Lx,0,PI/2-1e-8)
        else:
           z = opt.brentq(lambda x: np.tan(x) - (PI*l+x)/m/p.Lx,PI/2+1e-8,PI-1e-8)

	
	en = sqrt( (m/cos(z))**2+sy**2 )
        ens.append( en )
	nn+=1
    #print nn
    
    #en.append( sqrt( (m**2+sy**2 ) ) )
    return np.array(ens)

def integral(lmb1,lmb2,L):
    diff = -lmb1+lmb2
    if abs(diff) > 1e-16:
        return ( np.exp(1j*(-lmb1+lmb2)*L)-1 )/1j/(-lmb1+lmb2)
    else:
        return L
    
def integralx(lmb1,lmb2,L):
    dlmb = -lmb1+lmb2
    if abs(dlmb) > 1e-16:
        return ( np.exp(1j*dlmb*L)-1 )/(dlmb)**2 + L*np.exp(1j*dlmb*L)/(1j*dlmb)
    else:
        return 0.5*L**2

def norm_exact(psi,L):
    """ u0                        v0
        u1  exp( -1j*x*lmb )  +   v1   exp(  1j*x*lmb )
    """
    u, v, lmb  = psi
    
    return  ( np.vdot(u,u)*L + np.vdot(v,v)*L \
              + np.vdot(u,v) * ( np.exp(2j*lmb*L)-1 )/2j/lmb \
              + np.vdot(v,u) * ( np.exp(-2j*lmb*L)-1 )/(-2j)/lmb  ).real     


def wave_bulk_exact(enarr,l,p):
    """ u_0                        v_0
        u_1  exp( -1j*x*lmb )  +   v_1   exp(  1j*x*lmb )
        
        with simple en -> -en mapping
    """

    ispos = np.sign(l)
    l = np.abs(l)
    if (l==0) or not(isinstance(l,int)):
        print "error -- non integer index l", type(l)
    m, de = mass(p)
    sy = sin(p.ky) # !!! included

    en  = enarr[l-1]*ispos
    lmb = sqrt(en**2-m**2-sy**2)
   
    # form below is for general ky
    v0 =  (en+m)*(en+m-sy-1j*lmb)
    u0 = -(en+m)*(en+m-sy+1j*lmb)

    v1 =  (lmb+1j*sy)*(en+m-sy-1j*lmb)
    u1 =  (lmb-1j*sy)*(en+m-sy+1j*lmb)

    psi =  (u0,u1), (v0,v1), lmb   
    nrm = sqrt( norm_exact(psi,p.Lx).real )
    psi =  (u0/nrm, u1/nrm), (v0/nrm,v1/nrm), lmb
    return psi, en+de   

def wave_bulk_quick(en,p):
    """ u_0                        v_0
        u_1  exp( -1j*x*lmb )  +   v_1   exp(  1j*x*lmb )
        
        with simple en -> -en mapping
    """
    m, de = mass(p)
    sy = sin(p.ky) # !!! included
    lmb = sqrt(en**2-m**2-sy**2)
   
    # form below is for general ky, any sign of en
    v0 =  (en+m)*(en+m-sy-1j*lmb)
    u0 = -(en+m)*(en+m-sy+1j*lmb)

    v1 =  (lmb+1j*sy)*(en+m-sy-1j*lmb)
    u1 =  (lmb-1j*sy)*(en+m-sy+1j*lmb)

    psi =  (u0,u1), (v0,v1), lmb   
    nrm = sqrt( norm_exact(psi,p.Lx).real )
    psi =  (u0/nrm, u1/nrm), (v0/nrm,v1/nrm), lmb
    return psi 

def wave_arc_exact(il,p):
    """ u_0                      v_0
        u_1  exp( x*kappa )  +   v_1   exp( -x*kappa )
        
        with simple en -> -en mapping

        Output: wave funcion of arc state
    """

    if not( (il==1) or (il==-1) ):
        print "error -- index il should be in [-1,1]"
    m, de = mass(p)
    sy = sin(p.ky) # !!! included

    meps = 1./p.Lx  # estimate from analytics
    if (  m > meps ):          # surface state
        #print 'm = ', m, 'kz = ', p.kz, 'ky = ', p.ky
        z = opt.brentq(lambda th: np.tanh(th)-th/m/p.Lx, 0.+1e-16, m*p.Lx*2)
        en = sqrt( m**2*( 1 - np.tanh(z)**2 ) + sy**2 )

        lmb = 1j*sqrt(m**2+sy**2-en**2) # lambda = 1j kappa
    else: 
        if (meps>=m) and (m>0): # strange bulk state
            z = opt.brentq(lambda th: np.tan(th)-th/m/p.Lx, 0.+1e-10, PI/2-1e-8)
        else:                  # l=0 bulk state for m<0
            z = opt.brentq(lambda th: np.tan(th)-(th)/m/p.Lx, PI/2+1e-8, PI-1e-8)  
        en  = sqrt( m**2*( 1 + np.tan(z)**2 ) + sy**2 )
        lmb = m*np.tan(z)
        
    en  = en*il  # deside "positive" or "negative" arc
   
    # form below is for general ky
    v0 =  (en+m)*(en+m-sy-1j*lmb)
    u0 = -(en+m)*(en+m-sy+1j*lmb)

    v1 =  (lmb+1j*sy)*(en+m-sy-1j*lmb)
    u1 =  (lmb-1j*sy)*(en+m-sy+1j*lmb)

    psi =  (u0,u1), (v0,v1), lmb   
    nrm = sqrt( overlap_exact(psi,psi,p.Lx).real )
    psi =  (u0/nrm, u1/nrm), (v0/nrm,v1/nrm), lmb
    return psi, en+de   


def overlap_exact(psi1, psi2, L):
    """ Notation with two-component u, v:
    
        u  exp( -1j*x*lmb )  +   v   exp(  1j*x*lmb )

        Output: 
    """
    u1, v1, lmb1   = psi1
    u2, v2, lmb2   = psi2
    
    lmb1 = np.conj(lmb1)  # works for lambda = 1j kappa
    
    return  (    np.vdot(u1,u2) * integral(-lmb1,-lmb2,L) \
              +  np.vdot(v1,u2) * integral( lmb1,-lmb2,L) \
              +  np.vdot(u1,v2) * integral(-lmb1, lmb2,L) \
              +  np.vdot(v1,v2) * integral( lmb1, lmb2,L)     )

def current_exact(psi1, psi2, p):
    """ Notation with two-component u, v:
    
        u  exp( -1j*x*lmb )  +   v   exp(  1j*x*lmb )
    """
    u1, v1, lmb1   = psi1
    u2, v2, lmb2   = psi2
    
    lmb1 = np.conj(lmb1) # works for lmb = 1j kappa
    
    def tauz(u):
        a, b = u
        return (a,-b)
    
    u2, v2 = tauz(u2), tauz(v2)
    jzz = prefactor(p)
    return  (    np.vdot(u1,u2) * integral(-lmb1,-lmb2,p.Lx)  \
              +  np.vdot(v1,u2) * integral( lmb1,-lmb2,p.Lx)  \
              +  np.vdot(u1,v2) * integral(-lmb1, lmb2,p.Lx)  \
              +  np.vdot(v1,v2) * integral( lmb1, lmb2,p.Lx)     ) * jzz

def field_exact(psi1, psi2, p):
    """ Notation with two-component u, v:
    
        u  exp( -1j*x*lmb )  +   v   exp(  1j*x*lmb )
    """
    u1, v1, lmb1   = psi1
    u2, v2, lmb2   = psi2
    
    lmb1 = np.conj(lmb1) # works for lmb = 1j kappa
    
    def tauy(u):
        a, b = u
        return (-1j*b,1j*a)
 
    u2, v2 = tauy(u2), tauy(v2)
    return  (    np.vdot(u1,u2) * integralx(-lmb1,-lmb2,p.Lx)  \
              +  np.vdot(v1,u2) * integralx( lmb1,-lmb2,p.Lx)  \
              +  np.vdot(u1,v2) * integralx(-lmb1, lmb2,p.Lx)  \
              +  np.vdot(v1,v2) * integralx( lmb1, lmb2,p.Lx)          )

def response_exact(psi1,en1,psi2,en2,p):
    s = np.sign(en2)
    if ( en1*en2 < 0 ):
        # can be regularized as: /(en1-en2+1e-5*1j)
        return s*current_exact(psi1,psi2,p)*field_exact(psi2,psi1,p) /(en1-en2+1e-5*1j)
    else:
        return 0.0

def response_quick(enarr,n1,s1,n2,s2,p):
    m, de = mass(p)
    en1  = enarr[n1-1]*s1
    en2  = enarr[n2-1]*s2
    if ( (en1+de)*(en2+de) < 0 ):
        psi1  = wave_bulk_quick(en1,p)
        psi2  = wave_bulk_quick(en2,p)
        # can be regularized as: /(en1-en2+1e-5*1j)
        return s2*current_exact(psi1,psi2,p)*field_exact(psi2,psi1,p) /(en1-en2+1e-5*1j)
    else:
        return 0.0
    
########################################################################
# Construction/testing version
########################################################################

def cluster_response_ver1(LL,bb0):
    zpoint, zmin, zmax = 200, 0.4, 0.85
    momenta = np.linspace(zmin,zmax,zpoint)  # on a fixed grid
    cutoff = .2                                # with nmax cut--off bands

    p.Lx, p.b0 = LL, bb0
    p.ky = 0
    r = 0.
 
    """The calculation of SUMMED RESPONSE: bulk--bulk; construction/testing version"""
    for p.kz in momenta:
        enarr = energy_array(p,cutoff)
	nmax = len(enarr)
        m, de = mass(p)
        for nn in (np.arange(nmax-1)+1):
	    for isn in [-1,1]:
	        for mm in (np.arange(nmax-1)+1):
        	    for ism in [-1,1]:
		        #n, m = nn*isn, mm*ism
		        #psip, ennp  = wave_bulk_exact(enarr,n,p)
		        #psi , enn   = wave_bulk_exact(enarr,m,p)
		        #r +=  response_exact(psip,ennp,psi,enn,p).real
		        #
		        #r +=  response_quick(enarr,nn,isn,mm,ism,p).real
		        #
		        en1, en2  = enarr[nn-1]*isn, enarr[mm-1]*ism
		        if ( (en1+de)*(en2+de) < 0 ):
		           psi1, psi2  = wave_bulk_quick(en1,p), wave_bulk_quick(en2,p)
		           # can be regularized as: /(en1-en2+1e-5*1j)
		           r += (  ism*current_exact(psi1,psi2,p)*field_exact(psi2,psi1,p) /(en1-en2+1e-5*1j)  ).real

    return {'Pi': r*2*(zmax-zmin)/zpoint/p.Lx}

def cluster_response_ver2(LL,bb0):
    zpoint, zmin, zmax = 500, 0.1, 0.85
    momenta = np.linspace(zmin,zmax,zpoint)  # on a fixed grid
    cutoff=.2                                # with nmax cut--off bands

    p.Lx, p.b0 = LL, bb0
    p.ky = 0
    r = 0.
 
    """The calculation of SUMMED RESPONSE: arc--bulk (not optimized); construction/testing version"""
    r = 0.
    for p.kz in momenta:
        m, de = mass(p)
 
        for signky in [-1,1]:
            p.ky = signky*0.00001
            enarr = energy_array(p,cutoff)
	    nmax=len(enarr)
    
            for isn in [-1,1]:
                psip, ep = wave_arc_exact(isn,p)
                for mm in (np.arange(nmax-1)+1):
                #for mm in (np.arange(nmax-1)+2):
                    for ism in [-1,1]:                    
                        psi , e  = wave_bulk_exact(enarr,ism*mm,p)
    
                        r += response_exact(psip, ep, psi, e, p).real
                        r += response_exact(psi, e, psip, ep, p).real



    return {'Pi': r*2*(zmax-zmin)/zpoint/p.Lx/2}  # averaged with +/- ky

########################################################################
# To be used
########################################################################

def cluster_bulk(LL,bb0,kymax):
    zpoint, zmin, zmax = 200, 0.4, 0.85
    momenta = np.linspace(zmin,zmax,zpoint)  # on a fixed grid
    cutoff = .2                                # with nmax cut--off bands

    p.Lx, p.b0 = LL, bb0                     # input parameters

    r = 0.
 
    """The calculation of SUMMED RESPONSE: bulk--bulk: to be used on cluster"""
    for p.kz in momenta:
        for p.ky in [-kymax, kymax]:         # input kymax -- average over +/- ky_max
	    enarr = energy_array(p,cutoff)
	    nmax = len(enarr)
            m, de = mass(p)
            for nn in (np.arange(nmax-1)+1):
	        for isn in [-1,1]:
		    for mm in (np.arange(nmax-1)+1):
		        for ism in [-1,1]:
			    en1, en2  = enarr[nn-1]*isn, enarr[mm-1]*ism
			    if ( (en1+de)*(en2+de) < 0 ):
			       psi1, psi2  = wave_bulk_quick(en1,p), wave_bulk_quick(en2,p)
			       # can be regularized as: /(en1-en2+1e-5*1j)
			       r += (  ism*current_exact(psi1,psi2,p)*field_exact(psi2,psi1,p) /(en1-en2+1e-5*1j)  ).real

    return {'Pi': r*2*(zmax-zmin)/zpoint/p.Lx/2}   # calculated per +/- ky point


def cluster_arc(LL,bb0,kymax):
    zpoint, zmin, zmax = 500, 0.1, 0.85
    momenta = np.linspace(zmin,zmax,zpoint)  # on a fixed grid
    cutoff=.2

    p.Lx, p.b0 = LL, bb0                     # input parameters

    """The calculation of SUMMED RESPONSE: arc--bulk (not optimized): to be used on cluster"""
    r = 0.
    for p.kz in momenta:
        m, de = mass(p)
 
        for p.ky in [-kymax,kymax]:
            enarr = energy_array(p,cutoff)
	    nmax = len(enarr)
    
            for isn in [-1,1]:
                psip, ep = wave_arc_exact(isn,p)
                for mm in (np.arange(nmax-1)+1):
                    for ism in [-1,1]:                    
                        psi , e  = wave_bulk_exact(enarr,ism*mm,p)
    
                        r += response_exact(psip, ep, psi, e, p).real
                        r += response_exact(psi, e, psip, ep, p).real



    return {'Pi': r*2*(zmax-zmin)/zpoint/p.Lx/2}  # averaged with +/- ky

########################################################################

def main():
	momenta = np.linspace(0.5,0.75,200)  # on a fixed grid

	r_tab = []
	kz_tab = []

	cutoff = 0.2
	p.Lx = 260
	p.b0 = 0.05
	p.ky = 0.00

	"""A draft calculation of SUMMED RESPONSE: bulk--bulk"""
	for p.kz in momenta:
	    enarr = energy_array(p,cutoff)
	    nmax = len(enarr)
	    m, de = mass(p)
	    r = 0.
	    for nn in (np.arange(nmax-1)+1):
		for isn in [-1,1]:
		    for mm in (np.arange(nmax-1)+1):
		        for ism in [-1,1]:
		            #n, m = nn*isn, mm*ism
		            #psip, ennp  = wave_bulk_exact(enarr,n,p)
		            #psi , enn   = wave_bulk_exact(enarr,m,p)
		            #r +=  response_exact(psip,ennp,psi,enn,p).real
		            #
		            #r +=  response_quick(enarr,nn,isn,mm,ism,p).real
		            #
		            en1, en2  = enarr[nn-1]*isn, enarr[mm-1]*ism
		            if ( (en1+de)*(en2+de) < 0 ):
		               psi1, psi2  = wave_bulk_quick(en1,p), wave_bulk_quick(en2,p)
		               # can be regularized as: /(en1-en2+1e-5*1j)
		               r += (  ism*current_exact(psi1,psi2,p)*field_exact(psi2,psi1,p) /(en1-en2+1e-5*1j) ).real                       

	    r_tab.append(r)
	    kz_tab.append(p.kz)

	print 'Sum bulk-bulk: ', np.sum(r_tab)*2*(0.75-0.5)/200/p.Lx

	plt.plot(kz_tab,r_tab)    
	plt.grid()
	plt.show()

# Call the main function if the script gets executed (as opposed to imported).
# See <http://docs.python.org/library/__main__.html>.
if __name__ == '__main__':
    main()
