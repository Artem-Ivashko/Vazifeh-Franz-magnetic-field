# libraries
from __future__ import division

import numpy as np
from numpy import pi
from scipy import sparse as sp
from scipy.sparse import linalg as lag
from copy import deepcopy

import kwant

# my libraries (use the NEW library!)
import use_lib_v2; use_lib_v2.init()
import franz_model__positive_electrons
import standard_sys
import shapes
import paulimatrices as pm
from memory import SimpleNamespace

import matplotlib.cm as cm; import matplotlib.pyplot as plt;


"""
TABLE OF CONTENTS

1. make namespace
2. build system
3. calculate zero modes
4. calculate Burkov coefficients
5. plot dispersion
"""


""" 1. make a simple namespace with parameters of system """
def make_p( **kwargs ):
    p = SimpleNamespace()
    p.__dict__.update(kwargs)
    return p
		

""" 2.1a build2D_xy builds the 2D tight binding lattice, which simulates a 3D Franz
model with periodic boundary conditions in z-direction. The kz-momenta
are given as parameters within a namespace when calculating eigenstates etc.

input
----- 
Lx -- number of sites in x-direction 
Ly -- number of sites in y-direction
pbc_x -- periodic boundary in x-direction
pbc_y -- periodic boundary in y-direction
finalized -- if True build will finalize the system before returning it

output 
------
returns a (finalized) kwant builder
"""
def build1D_x( Lx,pbc_x=False,translat_sym=None,finalized=True ):

    pbc=[pbc_x]
    LWH       = ( Lx, ); 
    shape     = shapes.chain( [Lx-1] )
    lattice   = kwant.lattice.general( ((1,),) )
    params_sys = SimpleNamespace( LWH=LWH,pbc=pbc,translat_sym=translat_sym )

    model = franz_model__positive_electrons.Franz1D()

    sys_obj    = standard_sys.ParallelEdgesSystem( model,lattice,shape,params_sys )
    sys        = sys_obj.sys

    if finalized:
	return sys.finalized()
    else:
	return sys


""" 2.1a build2D_xy builds the 2D tight binding lattice, which simulates a 3D Franz
model with periodic boundary conditions in z-direction. The kz-momenta
are given as parameters within a namespace when calculating eigenstates etc.

input
----- 
Lx -- number of sites in x-direction 
Ly -- number of sites in y-direction
pbc_x -- periodic boundary in x-direction
pbc_y -- periodic boundary in y-direction
finalized -- if True build will finalize the system before returning it

output 
------
returns a (finalized) kwant builder
"""
def build2D_xy( Lx,Ly,pbc_x=False,pbc_y=False,translat_sym=None,finalized=True ):

    pbc=[pbc_x,pbc_y]
    LWH       = ( Lx,Ly ); 
    shape     = shapes.square( (Lx-1,Ly-1) )
    lattice   = kwant.lattice.general( ((1,0),(0,1)) )
    params_sys = SimpleNamespace( LWH=LWH,pbc=pbc,translat_sym=translat_sym )

    model = franz_model__positive_electrons.Franz2D_xy()

    sys_obj    = standard_sys.ParallelEdgesSystem( model,lattice,shape,params_sys )
    sys        = sys_obj.sys

    if finalized:
	return sys.finalized()
    else:
	return sys


""" 2.1a build2D_round builds the 2D tight binding lattice, which simulates a 3D Franz
model with periodic boundary conditions in z-direction. The kz-momenta
are given as parameters within a namespace when calculating eigenstates etc.

input
----- 
R  -- radius
finalized -- if True build will finalize the system before returning it

output 
------
returns a (finalized) kwant builder
"""
def build2D_round( R,finalized=True ):

    shape      = shapes.circle( R )
    
    lattice    = kwant.lattice.general( ((1,0),(0,1)) )
    params_sys = SimpleNamespace( translat_sym=None )

    model = franz_model__positive_electrons.Franz2D_xy()

    sys_obj    = standard_sys.ParallelEdgesSystem( model,lattice,shape,params_sys )
    sys        = sys_obj.sys

    if finalized:
	return sys.finalized()
    else:
	return sys
    

""" 2.1a build2D_xz builds the 2D tight binding lattice, which simulates a 3D Franz
model with periodic boundary conditions in z-direction. The kz-momenta
are given as parameters within a namespace when calculating eigenstates etc.

input
----- 
Lx -- number of sites in x-direction 
Ly -- number of sites in y-direction
pbc_x -- periodic boundary in x-direction
pbc_y -- periodic boundary in y-direction
finalized -- if True build will finalize the system before returning it

output 
------
returns a (finalized) kwant builder
"""
def build2D_xz( Lx,Lz,pbc_x=False,pbc_z=False,translat_sym=None,finalized=True ):

    pbc=[pbc_x,pbc_z]
    LWH       = ( Lx,Lz ); 
    shape     = shapes.square( (Lx-1,Lz-1) )
    lattice   = kwant.lattice.general( ((1,0),(0,1)) )
    params_sys = SimpleNamespace( LWH=LWH,pbc=pbc,translat_sym=translat_sym )

    model = franz_model__positive_electrons.Franz2D_xz()

    sys_obj    = standard_sys.ParallelEdgesSystem( model,lattice,shape,params_sys )
    sys        = sys_obj.sys

    if finalized:
	return sys.finalized()
    else:
	return sys

    

""" 2.2 build3D builds the 3D tight binding lattice, which simulates a 3D Franz
model.

input
----- 
Lx -- number of sites in x-direction 
Ly -- number of sites in y-direction
Lz -- number of sites in z-direction
pbc_x -- periodic boundary in x-direction
pbc_y -- periodic boundary in y-direction
pbc_z -- periodic boundary in z-direction
finalized -- if True build will finalize the system before returning it

output 
------
returns a (finalized) kwant builder
"""
def build3D( Lx,Ly,Lz,pbc,finalized=True ):

    LWH       = ( Lx,Ly,Lz ); 
    shape     = shapes.cube( (Lx-1,Ly-1,Lz-1) )
    lattice   = kwant.lattice.general( ((1,0,0),(0,1,0),(0,0,1)) )

    params_sys = SimpleNamespace( LWH=LWH,pbc=pbc,translat_sym=(0,0,1) )

    model = franz_model__positive_electrons.Franz3D()

    sys_obj    = standard_sys.ParallelEdgesSystem( model,lattice,shape,params_sys )
    sys        = sys_obj.sys

    if finalized:
	return sys.finalized()
    else:
	return sys


"""3.1 calc_modes calculates the zero modes of a system using KWANT"""    
def calc_zero_modes( fsys,p,eF ):

    mymodes = fsys.modes( args=([p]),energy=eF )
    prop = mymodes[0] 
    moms = prop.momenta
    vels = prop.velocities
    wfs  = (prop.wave_functions).T

    zero_modes = []
    for n in range(len(moms)):
	kz=moms[n]
	vel=vels[n]
	wf = wfs[n]
	en=eF
	sites = [ site for site in fsys.sites if site.pos[1]==0 ]    
	zero_modes.append( [ kz,vel,en,wf,[s.pos for s in sites],None ] )
    
    return zero_modes


""" 3.2 find_zero_modes calculates the zero modes using a parallelized zero finder
input
-----

fsys     -- finalized system
p        -- parameters of system
interval -- energy window in which we are looking for zeros
k_min    -- minimum number of states to be calculated


return
------
zero_modes, crossing_bands, other_bands, other_bands_2, bands
"""
def find_zero_modes( fsys,p,kzs_int,eF=0,interval=.05,k_min=8,bands_only=False ):

    # 1. calulate low energy spectrum
    kzs=kzs_int
    bands={}; low_en_spec={}
    for kz in kzs:
        p.kz=kz
        ham_sparse_coo = fsys.hamiltonian_submatrix( args=([p]),sparse=True )
	ham_sparse = ham_sparse_coo.tocsc()

        # get at least all evals in interval
        evals = np.array([0]); evecs = np.array([0]); k0=k_min
        evals,evecs = lag.eigsh( ham_sparse,k=k0,return_eigenvectors=True,\
                                 which='LM',sigma=eF, tol=10**(-2) )
        if min(abs(evals-eF))<interval:
            while max(abs(evals-eF))<=interval:
                evals,evecs = lag.eigsh( ham_sparse,k=k0,return_eigenvectors=True,\
                                         which='LM',sigma=eF, tol=10**(-6) )
                k0+=16
             
        # put data in dictionaries
        bands[kz]={}
        bands[kz]['ens']=list(evals)
        bands[kz]['vecs']=list(evecs.T)
        low_en_spec[kz]=evals


    if not bands_only:
        # 2. trace all bands in the energy window
    
        # storage for the traced bands
        zero_modes = []
        #crossing_bands=[]; other_bands=[]; other_bands_2=[]; 

        # make a copy of all bands, because the algorithm manipulates the band storage
        work_bands = bands; work_kzs=kzs_int;

        # follow those evecs in the interval
        for kz0 in work_kzs:
            es_start = deepcopy( work_bands[kz0]['ens'] )
            vs_start = deepcopy( work_bands[kz0]['vecs'] )
            for n0 in range(len(es_start)):
                e0=es_start[n0]
                v0=vs_start[n0]
                sign=np.sign(e0-eF)
                no_ens=len(es_start)
	    
                # check if energy is in interval, if yes, this is the starting point of a traced band
                if abs(e0-eF)<interval:

                    # store the sign, to detect change in sign
                    traced_band={}
                    traced_band[kz0]=e0
                    complete=False

                    # start tracing
                    for kz in work_kzs:
                        # trace only towards larger kz
                        if kz>kz0:

                            # get all wave functions and check their overlap with v0
                            vs_next = deepcopy( work_bands[kz]['vecs'] )
                            es_next = deepcopy( work_bands[kz]['ens'] )
                            overlap = [ np.abs( np.vdot(v0,vs_next[m]) ) \
                                        for m in xrange(len(vs_next)) ]
                            if len(overlap)==0:
                                #other_bands_2.append( traced_band )
                                complete=True
                                break
                            n_best = np.argmax( overlap )

                            e_temp = e0
                            e0 = es_next[n_best]
                            v0 = vs_next[n_best]


                            # remove this data point from work_bands to avoid double tracing
                            del work_bands[kz]['ens'][n_best]
                            del work_bands[kz]['vecs'][n_best]

                            # if the one with the largest overlap is in the interval
                            # and has sufficient overlap
                            if abs(e0-eF)<interval and max(overlap)>.6:

                                if abs(e0-e_temp)>2*10**(-2):
                                    raise ValueError( "the energy step at kz="+str(kz) \
						      +" is too big: "+str(e_temp-e0 ) )

                                
                                traced_band[kz] = e0

                                # if the sign has changed the tracing is complete
                                if np.sign(e0-eF)!=sign:
				
                                    #crossing_bands.append( traced_band )
                                    complete=True
                                                                        
                                    # now that we have found a crossing, we want to extrapolate the actual zero mode
                                    if len(traced_band.keys())<2:
                                        raise ValueError( "found the buggger, kz is "+str(kz)\
							  +" e1 is "+str(e1)+" e0 is "+str(e0) )
                                    kz_l,kz_r = sorted(traced_band.keys())[-2:]
                                    kz_zero = kz_l+abs( (kz_r-kz_l)/(traced_band[kz_r]-traced_band[kz_l])\
							*(traced_band[kz_l]-eF) )
                                    vel_zero = (traced_band[kz_r]-traced_band[kz_l])/(kz_r-kz_l)
                                    if not (kz_l<=kz_zero and kz_r>=kz_zero):
                                        raise ValueError( "kz_zero is not inbetween kz_l and kz_r" )

                                    # calculate zero mode
                                    p.kz=kz_zero
                                    ham_sparse_coo = fsys.hamiltonian_submatrix( args=([p]),sparse=True )
                                    ham_sparse = ham_sparse_coo.tocsc()
                                    es_zero,vs_zero_T = \
                                            lag.eigsh( ham_sparse,k=no_ens+10,return_eigenvectors=True,\
						       which='LM',sigma=eF, tol=10**(-6) )
                                    vs_zero=vs_zero_T.T

                                    # in case there are several zero_modes, find the right one
                                    overl = [ np.abs( np.vdot(v0,vs_zero[m]) ) for m in xrange(len(vs_zero)) ]
                                    if len(overl)==0:
                                        raise ValueError( "That should not happen??"+str(len(v0))\
							  +str(len(vs_zero)) )
                                    n_zero = np.argmax( overl )
                                    
                                    if abs(es_zero[n_zero]-eF)>10**(-3):
                                        raise ValueError( "Zero mode not really at zero but at "\
							  +str(es_zero[n_zero])+" kz="+str(kz) )

                                    # verify that the "right" zero mode has been found
                                    if overl[n_zero]<.5:
                                        raise ValueError( "zero mode not found")
                                    else:
                                        zero_modes.append( [ kz_zero,vel_zero,es_zero[n_zero],\
							     vs_zero[n_zero],[s.pos for s in fsys.sites],\
							     overl[n_zero] ] )
                                    break
                            else:
                            
                                # the band has left the interval, this completes the tracing

                                # give a warning, if there was no decent overlap found,
                                # have to think a bit more careful about what this means
                                if max(overlap)<.6:
                                    #other_bands_2.append( traced_band )
                                    complete=True
                                    #print "added other band type 2"
                                else:
                                    #other_bands.append( traced_band )
                                    complete=True
                                    #print "added other band type 1"

                                break
                    # the largest kz was reached without leaving the interval or crossing zero,
                    # band will be added to other bands
                    if not complete:
                        #other_bands.append( traced_band )
                        complete=True
                        #print "added other band type 1"
                    
        return zero_modes, low_en_spec
    else:
        return low_en_spec




""" 3.2 calculate spectrum using a parallelized sparse matrices
-----

fsys      -- finalized system
p         -- parameters of system
interval  -- energy window in which all energy values should be calculated
tollerace -- accuracy on the energy scale
k_min     -- minimum number of states to be calculated


return
------
low_en_spec -- spectrum in interval
"""
def calc_spectrum( fsys,p,kzs_int,interval=.05,tolerance=.001,k_min=8,eig_states=False ):

    # 1. calulate low energy spectrum
    kzs=kzs_int
    low_en_spec={}; vectors={}
    for kz in kzs:
        p.kz=kz
        ham_sparse_coo = fsys.hamiltonian_submatrix( args=([p]),sparse=True )
	ham_sparse = ham_sparse_coo.tocsc()

        # get at least all evals in interval
        evals = np.array([0]); evecs = np.array([0]); k0=k_min
        evals,evecs = lag.eigsh( ham_sparse,k=k0,return_eigenvectors=True,which='LM',sigma=0, tol=interval/5. )
        if min(abs(evals))<interval:
            while max(abs(evals))<=interval:
                evals,evecs = lag.eigsh( ham_sparse,k=k0,return_eigenvectors=True,which='LM',sigma=0, tol=tolerance )
                k0+=16
             
        # put data in dictionaries
        vectors[kz]=evecs
        low_en_spec[kz]=evals
	
    if eig_states:
	return low_en_spec,evecs
    else:
	return low_en_spec


    

""" 3.3 helper routines for zero_mode_finder """

""" 3.3a get_evals calculates the eigenvalues of a translation invariant 
tight bining system at a given k-value using a kwant routine. 

Input
-----
fsys -- a finalized KWANT system
p    -- system parameters
kz   -- reciprocal momentum

Output
------
bands -- eigenvalues for the given kz
"""
def get_evals( fsys,p,kz ):

    bands = kwant.physics.Bands( fsys,args=([p]) )
    return bands(kz)


""" 3.3b get_abs_of_smallest_energy 
Input
-----
fsys -- a finalized KWANT system
p    -- system parameters
kz   -- reciprocal momentum

Output
------
kz -- reciprocal momentum
en -- a list containing the eigenvalues 
"""
def get_abs_of_smallest_energy( fsys,p,kz,eF=0 ):

    p.kz=kz

    ham_sparse_coo = fsys.hamiltonian_submatrix( args=([p]),sparse=True )
    ham_sparse = ham_sparse_coo.tocsc()
    #print type(ham_sparse)
    evals_sparse = lag.eigsh( ham_sparse,k=8,return_eigenvectors=False,which='LM',sigma=eF,tol=10**(-1) )
    if min(abs(evals_sparse-eF))<2*10**(-1):
        evals_sparse = lag.eigsh( ham_sparse,k=8,return_eigenvectors=False,which='LM',sigma=eF,tol=10**(-2) )
        if min(abs(evals_sparse-eF))<2*10**(-2):
            evals_sparse = lag.eigsh( ham_sparse,k=8,return_eigenvectors=False,which='LM',\
				      sigma=eF, tol=10**(-3) )
            if min(abs(evals_sparse-eF))<2*10**(-3):
                evals_sparse = lag.eigsh( ham_sparse,k=8,return_eigenvectors=False,which='LM',
					  sigma=eF, tol=10**(-4) )
           
    en = min(abs(evals_sparse-eF))+eF

    return kz,en


def get_minabs_and_mindelta( fsys,p,kz ):

    # calculate the smallest spacing between these energies
    def min_spacing( ens ):
        delta_min=10**6
        no_ens = len(ens)
        sens = sorted(ens)
        for n in range(no_ens-1):
            delta = sens[n+1]-sens[n]
            delta_min = min( delta_min,delta )
        return delta_min
            
    
    p.kz=kz

    ham_sparse_coo = fsys.hamiltonian_submatrix( args=([p]),sparse=True )
    ham_sparse = ham_sparse_coo.tocsc()

    evals_sparse = lag.eigsh( ham_sparse,k=4,return_eigenvectors=False,which='LM',sigma=0,tol=10**(-1) )
    minabs=min(abs(evals_sparse)); delta=min_spacing(evals_sparse)
    if min(minabs,delta)<2*10**(-1):
        evals_sparse = lag.eigsh( ham_sparse,k=4,return_eigenvectors=False,which='LM',sigma=0,tol=10**(-2) )
        minabs=min(abs(evals_sparse)); delta=min_spacing(evals_sparse)
        if min(minabs,delta)<2*10**(-2):
            evals_sparse = lag.eigsh( ham_sparse,k=4,return_eigenvectors=False,which='LM',sigma=0,tol=10**(-3) )
            minabs=min(abs(evals_sparse)); delta=min_spacing(evals_sparse)
            if min(minabs,delta)<2*10**(-3):
                evals_sparse = lag.eigsh( ham_sparse,k=4,return_eigenvectors=False,which='LM',sigma=0,tol=10**(-4) )
                minabs=min(abs(evals_sparse)); delta=min_spacing(evals_sparse)
                if min(minabs,delta)<2*10**(-4):
                    evals_sparse = lag.eigsh( ham_sparse,k=4,return_eigenvectors=False,which='LM',sigma=0,tol=10**(-5) )
                    minabs=min(abs(evals_sparse)); delta=min_spacing(evals_sparse)
                    if min(minabs,delta)<2*10**(-5):
                        evals_sparse = lag.eigsh( ham_sparse,k=4,return_eigenvectors=False,which='LM',sigma=0,tol=10**(-6) )
                        minabs=min(abs(evals_sparse)); delta=min_spacing(evals_sparse)
            
    return kz,minabs,delta



""" 3.3c make_fine_kz_grid """
def make_fine_grid( kzs_coarse,ens_coarse,minsteps,maxsteps,factor ):

    no_kzs=len(kzs_coarse)
    
    kzs_int_total = [];
    for n in range(no_kzs):
        kz=kzs_coarse[n]

        # define interval
        if n==0:
            kzmin=kz
            kzmax=(kz+kzs_coarse[1])/2.
        elif n==no_kzs-1:
            kzmin=(kz+kzs_coarse[n-1])/2.
            kzmax=kz
        else:
            kzmin=(kz+kzs_coarse[n-1])/2.
            kzmax=(kz+kzs_coarse[n+1])/2.

        # calc no of steps
        en=ens_coarse[n]
	steps = int(factor/en)
	if steps>maxsteps:
	    no_steps=maxsteps
	elif steps<minsteps:
	    no_steps=minsteps+1
	else:
	    no_steps=steps
            
	kzs_int_total += list( np.linspace(kzmin,kzmax,no_steps)[:-1] )
    return kzs_int_total


""" 3.3d split_kz_grid splits a large kz grind into more of less equal subsets with the 
peculiarity that the points a the boundary are part of both neighboring subsets s"""
def split_kz_grid( kzs,no_packs ):
    # split kz_int_total into equal packages
    # each interval should contain a reasonable number of points
    packs = []
    no_kzs = len(kzs)
    pnts = int( no_kzs/float(no_packs) )+1

    for n in range(no_packs):
	if (n+1)*pnts+1<no_kzs:
	    kzs_int = kzs[n*pnts:(n+1)*pnts+1]
	    packs.append( kzs_int )
	else:
	    kzs_int = kzs[n*pnts:]
	    packs.append( kzs_int )
	    break
	    
    return packs




""" 4.1a calc_alpha_3D calculates the Burkov coefficient for a 3D system with
hard wall boundary conditions

input
-----
modes    -- the zero modes of the system, including information about the 
            basis of the wave functions
p        -- SimpleNamespace containing the system parameters
CME_type -- 1 for oscillating inversion breaking, 2 for oscillating magnetic field

output
------
kzs    -- the kzs of the zero modes
vels   -- the velocities of the zero modes
dEdOPs -- dEdOP as a function of kz
alpha  -- the Burkov coefficient
"""
def calc_alpha_3D( modes,p,CME_type,pbc_y=False ):

    # calculate "chiral potential"
    
    kzs=[]; vels=[]; dEdOPs=[]; alpha=0;
    # 1. calculate the modes
    for mode in modes:
	try:
            kz,vel,en,wf,sites,overl = mode
	except:
	    kz,vel,en,wf,sites = mode
        no_sites=len(sites)
        
        if CME_type==1:
            OP=make_dHdb0_OP(sites,p)
            factor = 2*p.lBinv2 *no_sites
        elif CME_type==2:
            OP=make_dHdB_OP__peierls(sites,p,pbc_y)
            factor = 2*p.b0 *no_sites
        else:
            raise ValueError( "CME_type must be 1 for b0(t) or 2 for B(t)" )

        # calculate response jz = alpha * Bz * (2*b0)
        norm = np.dot( wf,np.conj(wf) )
        dEdOP = np.dot(np.conj(wf),OP.dot(wf))/norm

        kzs.append(kz)
        vels.append(vel)
        dEdOPs.append(dEdOP)

        alpha += - np.sign(vel) * dEdOP / (2*pi) /factor
    
    return kzs,vels,dEdOPs,alpha


""" 4.1b calc_alpha_2D calculates the Burkov coefficient for a 3D system with
hard wall boundary conditions

input
-----
modes    -- the zero modes of the system, including information about the 
            basis of the wave functions
p        -- SimpleNamespace containing the system parameters
CME_type -- 1 for oscillating inversion breaking, 2 for oscillating magnetic field

output
------
kzs    -- the kzs of the zero modes
vels   -- the velocities of the zero modes
dEdOPs -- dEdOP as a function of kz
alpha  -- the Burkov coefficient
"""
def calc_alpha_2D( mode,p,DeltaE,CME_type ):

    # calculate "chiral potential"
    
    # 1. unpack the modes
    try:
        kz,vel,en,wf,sites,overl = mode
    except:
        kz,vel,en,wf,sites = mode
	
    no_sites=len(sites)
            
    if CME_type==1:
        OP=make_dHdb0_OP(sites,p)
        factor = 2*p.lBinv2 *no_sites
    elif CME_type==2:
        OP=make_dHdB_OP__minimal_coupling(sites,p)
        factor = DeltaE *no_sites
    else:
        raise ValueError( "CME_type must be 1 for b0(t) or 2 for B(t)" )

    # calculate response jz = alpha * Bz * (2*b0)
    norm = np.dot( wf,np.conj(wf) )
    #print norm
        
    dEdOP = np.dot(np.conj(wf),OP.dot(wf))/norm

    alpha = - np.sign(vel) * dEdOP / (2*pi) /factor

    return kz,vel,dEdOP,alpha
 


# dHdb0 operator
def make_dHdb0_OP(sites,p):

    no_sites = len(sites)
    OP_space = sp.identity( no_sites, dtype=np.complex_)
    OP = sp.kron( OP_space,pm.s2s3 )
    return OP


# dHdB operator based on minimla coupling,
# assuming ky is good quantum number
def make_dHdB_OP__minimal_coupling(sites,p):

    # because we choose a particular gauge, in a finite system
    # we need to define the origin in the middle of the system
    xmin=10**(6); xmax=-10**(6)
    for s in sites:
	x,y=s
	xmin=min(x,xmin)
	xmax=max(x,xmax)

    try:
        x_shift = p.x_shift
    except:
        raise ValueError( "x_shift not defined" )
        
    # x_shift = (xmax+xmin)/2.
 
    s_list = np.diag([ site[0]-x_shift for site in sites ])
    orbital_core = -p.tp*np.cos(p.ky)*pm.s3s2 - p.t*np.sin(p.ky)*pm.s1s0
    orbital_core_csr = sp.csr_matrix( orbital_core )
    s_list_csr = sp.csr_matrix( np.array(s_list) )
    B_csr = sp.kron( s_list_csr,orbital_core_csr )

    return B_csr
    
    
# dHdB operator based on Peierl's substition
def make_dHdB_OP__peierls(sites,p,pbc_y=False):

    no_sites = len(sites)
    miny,maxy=10**(6),-10**(6)
    for n in range(no_sites):
        x,y=sites[n]
        miny=min(miny,y)
        maxy=max(maxy,y)
    Ly=maxy-miny

    try:
        x_shift = p.x_shift
    except:
        raise ValueError( "x_shift not defined" )

    orb = 0.5j*p.tp*pm.s3s2 + 0.5*p.t*pm.s1s0
    orbherm = np.conj(orb.T)
        
    OP = sp.lil_matrix( (4*no_sites,4*no_sites), dtype=np.complex_)
    for n1 in range(no_sites):
        s1=sites[n1]
        x1,y1 = s1
        for n2 in range(no_sites):
            s2=sites[n2]
            x2,y2 = s2
            if x1==x2:
                if abs(abs(y2-y1)-1)<10**(-6):
                    if y2>y1:
                        for i1 in xrange(4):
                            for i2 in xrange(4):
                                OP[4*n1+i1,4*n2+i2] = +1j*(x1+x2-2*x_shift)/2. * orb[i1,i2]
                    else:
                        for i1 in xrange(4):
                            for i2 in xrange(4):
                                OP[4*n1+i1,4*n2+i2] = -1j*(x1+x2-2*x_shift)/2. * orbherm[i1,i2]
                    
                if pbc_y and abs(y1-y2)==Ly:
                    if y1>y2:
                        for i1 in xrange(4):
                            for i2 in xrange(4):
                                OP[4*n1+i1,4*n2+i2] = +1j*(x1+x2-2*x_shift)/2. * orb[i1,i2]
                    else:
                        for i1 in xrange(4):
                            for i2 in xrange(4):
                                OP[4*n1+i1,4*n2+i2] = -1j*(x1+x2-2*x_shift)/2. * orbherm[i1,i2]
                    
    return OP



""" 4.2 calc_alpha_3D__old """
def calc_alpha_3D__old( fsys,p,Lx,Ly,CME_type ):

    # 1. calculate the modes
    modes = fsys.modes( args=([p]) )
    prop_modes = modes[0]
    kzs  = prop_modes.momenta
    vels = prop_modes.velocities
    wfs  = prop_modes.wave_functions.transpose()
    
    # calculate "chiral potential"
    if CME_type==1:
	# dHdb0 operator
	OP = np.kron( np.eye(Lx*Ly),pm.s2s3 )
	factor = 2*p.lBinv2 *Lx*Ly
	
    elif CME_type==2:
	# dHdB operator
	sites = [ site for site in fsys.sites if site.pos[2]>=0 ];
	no_sites = len(sites)

	OP_space = np.zeros( (no_sites,no_sites)) + 0j
	for n1 in range(no_sites):
	    s1=sites[n1]
	    x1,y1,z1 = s1.pos
	    for n2 in range(no_sites):
		s2=sites[n2]
		x2,y2,z2 = s2.pos
		if x1==x2 and abs(abs(y2-y1)-1)<10**(-6):
		    OP_space[n1][n2] = 1j*p.tp*(y2-y1)*(x1+x2)/2.
        OP = np.kron( OP_space,-0.5j*p.tp*pm.s3s2 - 0.5*p.t*pm.s1s0 )
	factor = 2*p.b0 *Lx*Ly
	print factor,p.b0,Lx,Ly
    else:
	raise ValueError( "CME_type must be 1 for b0(t) or 2 for B(t)" )

    # calculate response jz = alpha * Bz * (2*b0)
    dEdOPs=[]; alpha=0; 
    for n in range(len(kzs)):
	kz  = kzs[n] 
	vel = vels[n]
	wf  = np.conj(wfs[n])
	norm = np.dot( wf,np.conj(wf) )
	dEdOP = np.dot(np.conj(wf),np.dot( OP,wf ) )/norm
	
	#kzs.append(kz)
	dEdOPs.append(dEdOP)
	
	alpha += - np.sign(vel) * dEdOP / (2*pi) /factor
    
    return kzs,vels,dEdOPs,alpha

    

""" 5. plot dispersion """
def plotdisp( kzs,ens,tt ):

    kmin=min(kzs);kmax=max(kzs)
    emin=-1;emax=1

    fi, ax11 = plt.subplots(1,1,sharey=False,figsize=(10,8) )

    _ = plt.text(.5, 1.06, tt, horizontalalignment='center',
                    fontsize=20, transform = ax11.transAxes); 

    _ = ax11.plot( kzs,ens, 'k.' );

    ax11.hlines( 0,kmin,kmax )
    ax11.vlines( -0.6,kmin,kmax,linestyles='dashed' )
    ax11.vlines( 0.6,kmin,kmax,linestyles='dashed' )

    ax11.set_xlim( kmin,kmax )
    ax11.set_ylim( emin,emax )
 
    for ax in [ax11]:
        ax.set_xlabel(r'$k_z$', color='k', fontsize=28)
        for tl in ax.get_xticklabels():
            tl.set_color('k')
            tl.set_size( 16 )
        ax.set_ylabel(r'$E\,[t]$', color='k', fontsize=32)
        for tl in ax.get_yticklabels():
            tl.set_color('k')
            tl.set_size( 16 )


    fig.tight_layout()

