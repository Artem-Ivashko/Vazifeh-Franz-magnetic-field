#!/usr/bin/env python
# Filename amperian.py

""" 
This file contains the main code for the measurements 
on the Amperian superconductor
"""

# libraries
from __future__ import division
import numpy as np
from numpy import pi as PI
from scipy.special import erf
from scipy.special import erfinv
import scipy.linalg as la
import kwant
from copy import deepcopy
import symmetries
import warnings

# my libraries
import memory
from memory import SimpleNamespace
import shapes

import dispersion_2D
import angle_resolved_conductance_2D as ar

import amperian_model
import simple_model
import nambu_model

import standard_sys
from standard_sys import ParallelEdgesSystem as PES
import nambu_sys

import plot_data
import fname_and_title as fnt

import inspect,hashlib

# fix for modes
import new
def make_lead_more_tolerant(flead, tol=1e10):
	def modes(self, energy=0, args=()):
		ham = self.cell_hamiltonian(args)
		shape = ham.shape
		assert len(shape) == 2
		assert shape[0] == shape[1]
		# Subtract energy from the diagonal.
		ham.flat[::ham.shape[0] + 1] -= energy
		return kwant.physics.modes(ham, self.inter_cell_hopping(args), tol=tol)
    
	flead.modes = new.instancemethod(modes, flead, None)


#from random import random

#import angle_resolved_conductance_2D as ar
#import time

def calc_params( Leff = None, n = None, gap_angle = None, t=1 ):
	k=0
	if Leff!=None:
		k=n*np.pi/float(Leff);
		gap_angle = np.tan(k/PI)*360/(2*PI)
	else:
		k = np.pi*np.tan( gap_angle )
	K=[ [k,PI],[PI,k] ]
	mu = 2*t*( 1-np.cos(k) )
	print  "K1x = K2y = " + str( np.around(k,2) ) + ", gap angle = " \
		 + str( np.around(gap_angle,2) ) + ", mu = " + str( np.around(mu,3) )
	return K, mu

def calc_lead_mu( f, t=1., mu=0. ):
	mu_lead = mu-4*(f*t-t)
	# mu_new = -f**2 * mu - 8 * t**3 * f**2 * (f-1)
	return mu_lead

def calc_cutoffs( s, cutcorr, jcorr ):
	jlim = int(np.ceil( 1.+s*erfinv(1-jcorr) ))
	cutoff= np.sqrt( -2.*np.log( cutcorr )/(s**2) )  ;
	print "cutoff = " + str( np.around(cutoff,2) ) + ", jlim = " + str(jlim)
	return cutoff, jlim

def which_leads( fsys ):
	# lead indices
 	l_int=0; e_int=None; h_int=None; amp_int=None;
 	for lead in fsys.leads:
 		has_e=False
 		has_h=False
 		for s in lead.sites:
 			if s.family.name=='e':
 				has_e=True
 			if s.family.name=='h':
 				has_h=True
 		if has_e and has_h:
 			amp_int=l_int
 		elif has_e:
 			e_int=l_int
 		elif has_h:
 			h_int=l_int
 		l_int+=1
	return e_int, h_int, amp_int


def calc_dispersion_2D( L,W, \
								t, tp, tpp, tppp, mu, \
								delta, s, Kx, Ky, phi, cutoff, jlim, \
								kxvecs, kyvecs, points, no_bands, \
								typ='amp', min_weight=0, plot = False):

	# automatically generated values
	t_h, tp_h, tpp_h, tppp_h, mu_h = -t, -tp, -tpp, -tppp, -mu

 	# sanity check of parameters
 	if cutoff>=L/2.: 
		raise ValueError( "warning: cutoff is larger than half the system size." )
	if not any( [typ==val for val in ['amp','bcs','lo','lead']] ):
		raise ValueError( "model type '" + str( typ ) \
								+ "' not recognized. only possible values " \
								+ "are amp,bcs, lo and lead.")

	# unpack parameters
	LWH = L,W
	LWH_for_shape = L*3-1, W*2-1
	shape = shapes.square( LWH_for_shape )
	# SYSTEM
	K=[  [PI,Ky],[Kx,PI]  ]
	params_sys = SimpleNamespace( LWH=LWH, translat_sym=None, \
												cutoff_pair=cutoff )
 	params_lead = SimpleNamespace( t=t, tp=tp, mu=mu)

	p = SimpleNamespace( mu=mu, mu_h=mu_h, t=t, tp=tp, tpp=tpp, tppp=tppp, \
								t_h=t_h, tp_h=tp_h, tpp_h=tpp_h, tppp_h=tppp_h, \
								K=K, phi=phi, s=s, delta=delta, jlim=jlim )

	if typ=='amp':
		model = amperian_model.Amperian()
	elif typ=='bcs':
		model = amperian_model.BCS()
	elif typ=='lo':
		model = amperian_model.LO2D()
	elif typ=='lead':
		model = simple_model.ElectronGasLead2D( params_lead, 'e' )
	
	# make two leads, which will be used to contruct a two dimensional tight binding Hamiltonian
	if typ=='amp':
		sys_obj = nambu_sys.LongrangeNambuSystem( model,shape,params_sys )
	elif typ=='bcs' or typ=='lo':
		sys_obj = nambu_sys.NambuSystem( model,shape,params_sys )
	elif typ=='lead':
		sys_obj = PES( model, shape, params_sys )

	sys_obj.finalize()
	fsys = sys_obj.fsys

	if plot:
		kwant.plotter.plot( sys_obj.sys )

	# PARAMETERS FOR DISPERSION
	options = SimpleNamespace( kxvecs=kxvecs, kyvecs=kyvecs, plot=False )
	
	ret = dispersion_2D.unfolded_bandstructure( fsys, p=p, \
																  no_bands=no_bands, options=options, \
																  min_weight=min_weight )
	
	return ret



def calc_dispersion_2D_old( L,W, \
								t, tp, tpp, mu, \
								delta, s, Kx, Ky, phi, cutoff, jlim, \
								kxvecs, kyvecs, points, no_bands, \
								typ='amp', min_weight=0, plot = False):

	# automatically generated values
	t_h, tp_h, tpp_h, mu_h = -t, -tp, -tpp, -mu

 	# sanity check of parameters
 	if cutoff>=L/2.: 
		raise ValueError( "warning: cutoff is larger than half the system size." )
	if not any( [typ==val for val in ['amp','bcs','lo','lead']] ):
		raise ValueError( "model type '" + str( typ ) \
								+ "' not recognized. only possible values " \
								+ "are amp,bcs, lo and lead.")

	# unpack parameters
	LWH = L,W
	LWH_for_shape = L-1, W-1
	shape = shapes.square( LWH_for_shape )
	# SYSTEM
	K=[  [PI,Ky],[Kx,PI]  ]
	params_sys = SimpleNamespace( LWH=LWH, translat_sym=None, \
												cutoff_pair=cutoff )
 	params_lead = SimpleNamespace( t=t, tp=tp, mu=mu)

	p = SimpleNamespace( mu=mu, mu_h=mu_h, t=t, tp=tp, tpp=tpp, \
								t_h=t_h, tp_h=tp_h, tpp_h=tpp_h, \
								K=K, phi=phi, s=s, delta=delta, jlim=jlim )

	if typ=='amp':
		model = amperian_model.Amperian()
	elif typ=='bcs':
		model = amperian_model.BCS()
	elif typ=='lo':
		model = amperian_model.LO2D()
	elif typ=='lead':
		model = simple_model.ElectronGasLead2D( params_lead, 'e' )
	
	# make two leads, which will be used to contruct a two dimensional tight binding Hamiltonian
	if typ=='amp':
		params_sys.translat_sym = (L,0)
		sys_obj_x = nambu_sys.LongrangeNambuSystem( model,shape,params_sys )
		params_sys.translat_sym=(0,W)		
		sys_obj_y = nambu_sys.LongrangeNambuSystem( model,shape,params_sys )
	elif typ=='bcs' or typ=='lo':
		params_sys.translat_sym = (L,0)
		sys_obj_x = nambu_sys.NambuSystem( model,shape,params_sys )
		params_sys.translat_sym=(0,W)		
		sys_obj_y = nambu_sys.NambuSystem( model,shape,params_sys )
	elif typ=='lead':
		params_sys.translat_sym = (L,0)
		sys_obj_x = PES( model, shape, params_sys )
		params_sys.translat_sym=(0,W)		
		sys_obj_y = PES( model, shape, params_sys )
		

	sys_obj_x.finalize()
	sys_obj_y.finalize()
	fsys_x = sys_obj_x.fsys
	fsys_y = sys_obj_y.fsys

	if plot:
		kwant.plotter.plot( sys_obj_x.sys )
		kwant.plotter.plot( sys_obj_y.sys )
		kwant.plotter.bands( sys_obj_x.fsys, args=([p]) )
		kwant.plotter.bands( sys_obj_y.fsys, args=([p]) )

	# PARAMETERS FOR DISPERSION
	options = SimpleNamespace( kxvecs=kxvecs, kyvecs=kyvecs, plot=False )
	
	ret = dispersion_2D.unfolded_bandstructure( fsys_x=fsys_x, fsys_y=fsys_y, p=p, \
																  no_bands=no_bands, options=options, \
																  min_weight=min_weight )
	
	return ret

def plot_dispersion_2D( infos, data ):

	path = "/clusterdata/baireuther/data/amperian/dispersions/"
	order = ['L', 'W', 'mu', 'delta', 's', 'cutoff', 'pbc', 'eps', 'Ky', 'Kx']
	omit = ['kxvecs','kyvecs','_out']
		
	fname,title =  fnt.make_fname_and_title( [infos], omit, order, \
														  'Dispersion', linewidth=60 )
	plot_data.plot_unfolded_dispersion( data, eps=0., delta_eps=.2, \
													whichbands=[0], title=title, fname=path+fname )

	return


# 	sys_x = nambu_sys.LongrangeNambuSystem( ampModel, square, params )


def angle_resolved_conductance( L, W, pbc, \
										  t, tp, tpp, tppp, mu, \
										  t_lead, tp_lead, mu_lead, \
										  delta, s, Kx, Ky, phi, cutoff, jlim, \
										  sc_type, e_in, output=False ):

	# automatically generated values
	t_h, tp_h, tpp_h, tppp_h, mu_h = -t, -tp, -tpp, -tppp, -mu

 	# sanity check of parameters
 	if cutoff>=L/2.: 
		raise ValueError( "warning: cutoff is larger than half " \
								+ "the system size." )
	if not any( [sc_type==val for val in ['amp','bcs','lo']] ):
		raise ValueError( "superconductor type" + str( sc_type ) \
								+ "not recognized. only possible values " \
								+ "are amp,bcs or lo")

 	# unpack parameters and repack
 	K=[  [Kx,PI],[PI,Ky]  ]
 	LWH=(L,W)

 	# fixed parameters
 	params_sys_sc = SimpleNamespace( LWH=LWH, pbc=pbc, translat_sym=None, cutoff_pair=cutoff )
 	params_leads_l = SimpleNamespace( LWH=LWH, pbc=pbc, translat_sym=(-1,0) )
	params_leads_r = SimpleNamespace( LWH=LWH, pbc=pbc, translat_sym=(L,0), cutoff_pair=cutoff )
 	params_leads_e = SimpleNamespace( t=t_lead, tp=tp_lead, mu=mu_lead )
 	params_leads_h = SimpleNamespace( t=-t_lead, tp=-tp_lead, mu=-mu_lead )

 	# variable system parameters
 	p = SimpleNamespace( t=t, tp=tp, tpp=tpp, tppp=tppp, \
								t_h=t_h, tp_h=tp_h, tpp_h=tpp_h, tppp_h=tppp_h, \
								mu=mu, mu_h=mu_h, \
								delta=delta, s=s, K=K, phi=phi, jlim=jlim, W=W )

	# shape
	LWH_for_shape = L-1, W-1
	shape_sc = shapes.square( LWH_for_shape )
	shape_lead = shapes.square( LWH_for_shape )


	# system
	if sc_type=='amp':
		model_sc = amperian_model.Amperian()
	elif sc_type=='bcs':
		model_sc = amperian_model.BCS()
	elif sc_type=='lo':
		model_sc = amperian_model.LO2D()

	if sc_type=='amp':
		sys_obj_sc = nambu_sys.LongrangeNambuSystem( model_sc,shape_sc,params_sys_sc )
	else:
		sys_obj_sc = nambu_sys.NambuSystem( model_sc,shape_sc,params_sys_sc )
	sys_sc = sys_obj_sc.sys

 	# left leads
 	lead_e_model = simple_model.ElectronGasLead2D( params_leads_e, 'e' )
 	lead_h_model = simple_model.ElectronGasLead2D( params_leads_h, 'h' )
	lead_e_obj = PES( lead_e_model, shape_lead, params_leads_l )
	lead_h_obj = PES( lead_h_model, shape_lead, params_leads_l )
	lead_e = lead_e_obj.sys
	lead_h = lead_h_obj.sys

 	# right lead
	if sc_type=='amp':
		lead_obj_sc = nambu_sys.LongrangeNambuSystem( model_sc,shape_sc,params_leads_r )
	else:
		lead_obj_sc = nambu_sys.NambuSystem( model_sc,shape_sc,params_leads_r )
	lead_sc = lead_obj_sc.sys

 	# attach leads and finalize
 	sys_sc.attach_lead( lead_e )
 	sys_sc.attach_lead( lead_h )
 	sys_sc.attach_lead( lead_sc )

	if output:
		kwant.plotter.plot( sys_sc, fig_size=(24,10), site_size=0.05, \
								  hop_lw=0.02, num_lead_cells=1 );

 	fsys = sys_sc.finalized()
	infos = dict()
 	e_int, h_int, amp_int = which_leads( fsys )

 	infos['electron lead'] = e_int
 	infos['hole lead'] = h_int
 	infos['AMP lead'] = amp_int

 	# calculate angle resolved conductance
 	grid_rA, infos['calc_cond rA'] = ar.calc_cond( fsys, p, params_leads_e, \
																  params_leads_h, [e_int], [h_int], e_in )
 	grid_r, infos['calc_cond r'] = ar.calc_cond( fsys, p, params_leads_e, \
																params_leads_e, [e_int], [e_int], e_in )

 	return grid_r, grid_rA



''' 
This function constructs a Y-junction made of two normal leads 
and one Amperian lead and calculates its scattering matrix
'''

def Y_junction( Leff,W,L_block,P3x,P3y, \
					 t, tp, tpp, tppp, mu, t_lead, tp_lead,  mu_lead, \
					 delta, s, Kx, Ky, phi, cutoff, jlim, \
					 sc_type, e_in, check_syms=False, output=False, \
					 return_fsys=False ):

	# automatically generated values
	t_h, tp_h, tpp_h, tppp_h, mu_h = -t, -tp, -tpp, -tppp, -mu


 	# sanity check of parameters
 	if cutoff >= Leff/2.: 
		raise ValueError( "warning: cutoff is larger than half the system size." )
	if not any( [sc_type==val for val in ['amp','bcs','lo']] ):
		raise ValueError( "superconductor type " + str( sc_type ) \
								+ " not recognized. only possible values are amp,bcs or lo")

	# unpack and repack parameters
 	K = [ [Kx,PI],[PI,Ky] ]
	L = Leff
 	LWH=(L,W)
 	pbc=(False,False)

	p = SimpleNamespace( t=t, tp=tp, tpp=tpp, tppp=tppp, \
								t_h=t_h, tp_h=tp_h, tpp_h=tpp_h, tppp_h=tppp_h, \
								mu=mu, mu_h=mu_h, \
								delta=delta, s=s, K=K, phi=phi, jlim=jlim )

	params_leads_e = SimpleNamespace( t=t_lead, tp=tp_lead, mu=mu_lead )
	params_leads_h = SimpleNamespace( t=-t_lead, tp=-tp_lead, mu=-mu_lead )

	# calculate and or set the size of the system which connects the normal leads
	# with the superconducting lead. this part is not superconducting. The idea is
	# to choose it's width L_block so that a ray which is incoming from the thinner 
	LD = -P3x
	d = P3y
	u = W-d-2
	angle_up = np.arctan( -LD/u )
	angle_down = np.arctan( LD/d )

	# lead would hit the middle of the superconducting lead.
	if L_block==None:
		if abs(P3x)>=abs(P3y):
			L_block=0
		else:
			angle = np.arctan( -P3x/P3y )
			h1 = (u+1)/2.
			L1 = h1/np.tan(angle)
			LB = L1-LD/2.
			L_block = int( abs(np.around(LB)) )
			if output: 
				print "LB exact", LB
				print "size of normal block", L_block
				print "angle in 360 degree notation", angle/np.pi*180 
		
	P1 = np.asarray( [-L_block,0,0] )
	P2 = np.asarray( [-L_block,W-1,0] )
	P3 = np.asarray( [-L_block+ P3x+P3x/float(P3y)/2.,P3y+1/2.,0] )

	if output: print "L", L, "Leff", Leff, "W", W, "LD", LD, \
			 "L_block", L_block, "angle up", angle_up/np.pi*180, \
			 "angle down", angle_down/np.pi*180 

	# parameters for shapes
	LWH_block_shape = ( L_block,W-1 )
	LWH_sc_shape = ( L-1,W-1 )
	LWH_lead_shape_up = ( 1.,np.sqrt( LD**2+u**2 ) )
	LWH_lead_shape_down = ( 1.,np.sqrt( LD**2+d**2 ) )

	# parameters for position of leads
	offset_up = -L_block+P3x,P3y+1
	offset_down = -L_block,0
	if output: 
		print "offset up", offset_up, "offset down", offset_down
		print "angle up", angle_up, "angle down", angle_down
		print "LD,u,d", LD,u,d
		print "P3", P3

	# MODELS
	# system models
	model_e = simple_model.ElectronGas2D( 'e' )
	model_h = simple_model.ElectronGas2D( 'h' )
	if sc_type=='amp':
		model_sc = amperian_model.Amperian()
	elif sc_type=='bcs':
		model_sc = amperian_model.BCS()
	elif sc_type=='lo':
		model_sc = amperian_model.LO2D()

	# lead models
	model_lead_e = simple_model.ElectronGasLead2D( params_leads_e, 'e' )
	model_lead_h = simple_model.ElectronGasLead2D( params_leads_h, 'h' )

	
	# PARAMS II
	params_sys_triangle = SimpleNamespace( LWH=LWH,pbc=pbc,translat_sym=None )
	params_sys_sc = SimpleNamespace( LWH=LWH,pbc=pbc,translat_sym=None, \
												cutoff_pair=cutoff )

	params_lead_up = SimpleNamespace( LWH=LWH, pbc=pbc, translat_sym=(-u,LD) )
	params_lead_down = SimpleNamespace( LWH=LWH, pbc=pbc, translat_sym=(-d,-LD) )
	params_lead_sc = SimpleNamespace( LWH=LWH,pbc=(False,False),\
												 translat_sym=(Leff,0), \
												 cutoff_pair=cutoff )
	
	# SHAPES
	shape_triangle = shapes.triangle( P3,P1,P2 )
	shape_block = shapes.rectangle( LWH_block_shape, offset=(-L_block,0) )
	shape_sc = shapes.rectangle( LWH_sc_shape, offset=( 0,0) )
	shape_lead_up = shapes.ribbon( LWH_lead_shape_up, angle_up, offset=offset_up )
	shape_lead_down = shapes.ribbon( LWH_lead_shape_down, angle_down, offset=offset_down )
	shape_sc_lead = shapes.ribbon( LWH_sc_shape, offset=(Leff,0)  )

	# BUILDERS
	# triangle
	sys_obj_triangle_e = standard_sys.BaseSystem( model_lead_e,shape_triangle,params_sys_triangle )
	sys_obj_triangle_h = standard_sys.BaseSystem( model_lead_h,shape_triangle,params_sys_triangle )
	sys_triangle_e = sys_obj_triangle_e.sys
	sys_triangle_h = sys_obj_triangle_h.sys
	# normal block
	sys_obj_block_e = standard_sys.BaseSystem( model_lead_e,shape_block,params_sys_triangle )
	sys_obj_block_h = standard_sys.BaseSystem( model_lead_h,shape_block,params_sys_triangle )
	sys_block_e = sys_obj_block_e.sys
	sys_block_h = sys_obj_block_h.sys
	# amperian block
	if sc_type=='amp':
		sys_obj_sc = nambu_sys.LongrangeNambuSystem( model_sc,shape_sc,params_sys_sc )
	else:
		sys_obj_sc = nambu_sys.NambuSystem( model_sc,shape_sc,params_sys_sc )
	sys_sc = sys_obj_sc.sys

	# normal leads
	lead_obj_up_e = PES( model_lead_e,shape_lead_up,params_lead_up )
	lead_obj_up_h = PES( model_lead_h,shape_lead_up,params_lead_up )
	lead_obj_down_e = PES( model_lead_e,shape_lead_down,params_lead_down )
	lead_obj_down_h = PES( model_lead_h,shape_lead_down,params_lead_down )
	lead_up_e = lead_obj_up_e.sys
	lead_up_h = lead_obj_up_h.sys
	lead_down_e = lead_obj_down_e.sys
	lead_down_h = lead_obj_down_h.sys
	# amperian lead
	if sc_type=='amp':
		lead_obj_sc = nambu_sys.LongrangeNambuSystem( model_sc,shape_sc_lead,params_lead_sc )
	else:
		lead_obj_sc = nambu_sys.NambuSystem( model_sc,shape_sc_lead,params_lead_sc )
	lead_sc = lead_obj_sc.sys


	# CLUEING SYSTEMS TOGETHER
	sys = sys_triangle_e
	sys += sys_triangle_h
	if L_block>0:
		sys += sys_block_e
		sys += sys_block_h
	sys += sys_sc

	if output:
		kwant.plotter.plot( sys,fig_size=(10,10),site_size=0.2,hop_lw=0.1,num_lead_cells=1 );
		print "building done"


	# ATTACHING THE LEADS
	sys.attach_lead( lead_up_e )
	sys.attach_lead( lead_up_h )
	sys.attach_lead( lead_down_e )
	sys.attach_lead( lead_down_h )
	sys.attach_lead( lead_sc )


 	# SCATTERING MATRIX
	fsys = sys.finalized()

	# PATCH to make leads more tolerand
	for flead in fsys.leads:
		make_lead_more_tolerant(flead)
		
	try:		
		S = kwant.smatrix( fsys,energy=e_in,args=([p]),out_leads=[0,1,2,3,4],in_leads=[0,1,2,3,4] )
	except: #np.linalg.linalg.LinAlgError as err:
		warnings.warn( 'calculation of scattering matrix at e=' \
							+ str(e_in) + ' failed ' + str(p.__dict__) )
		try:		
			e_in += 10**(-6)
			S = kwant.smatrix( fsys,energy=e_in,args=([p]), \
									 out_leads=[0,1,2,3,4],in_leads=[0,1,2,3,4] )
			warnings.warn( 'but succeeded with an energy offset of 10**(-6)' )
		except: # np.linalg.linalg.LinAlgError as err:
			try:		
				e_in += 10**(-4)
				S = kwant.smatrix( fsys,energy=e_in,args=([p]),\
										 out_leads=[0,1,2,3,4],in_leads=[0,1,2,3,4] )
				warnings.warn( 'but succeeded with an energy offset of 10**(-4)' )
			except:
				try:		
					e_in += 10**(-2)
					S = kwant.smatrix( fsys,energy=e_in,args=([p]), \
											 out_leads=[0,1,2,3,4],in_leads=[0,1,2,3,4] )
					warnings.warn( 'but succeeded with an energy offset of 10**(-2)' )
				except:
					return 'Failed', np.zeros( (1,1) )
					
	# CHECH UNITARITY
	Sdat = S.data
	norm = la.norm( Sdat.dot(Sdat.T.conj()) - np.eye( len(Sdat)) )
		
	# CHECK SYMMETRIES
	if check_syms:
		S_test = kwant.smatrix( fsys,energy=e_in,args=([p]),out_leads=[2,3],in_leads=[2,3] )
		symmetries.check_symmetries( S_test,fsys,2,3 )
		S_test = kwant.smatrix( fsys,energy=e_in,args=([p]),out_leads=[0,1],in_leads=[0,1] )
		symmetries.check_symmetries( S_test,fsys,0,1 )

	# calculate conductance matrix
	no_leads = 5
	G = np.zeros( (no_leads,no_leads) )
	for i in range(no_leads):
		for j in range(no_leads):
			G[i,j] = S.transmission(i,j)

	
	if return_fsys:
		return e_in, G, norm, fsys, p
	else:
		return e_in, G, norm













'''This function constructs a Y-junction made of two normal leads and
one Amperian lead and calculates its scattering matrix; The region of
the junction has a electrostatic disorder that averages to zero. In
addition, there is a three side wide tunnel-barrier on the metal side
of the NS-interface.'''
def Y_junction_disordered( Leff,W,P3x,P3y, \
									t, tp, tpp, tppp, mu, t_lead, tp_lead,  mu_lead, mu_barrier, \
									delta, s, Kx, Ky, phi, cutoff, jlim, \
									sc_type, e_in, U0, seed, L_block=None, \
									check_syms=False, output=False, return_fsys=False ):
	
	# automatically generated values
	t_h, tp_h, tpp_h, tppp_h, mu_h = -t, -tp, -tpp, -tppp, -mu


 	# sanity check of parameters
 	if cutoff >= Leff/2.: 
		raise ValueError( "warning: cutoff is larger than half the system size." )
	if not any( [sc_type==val for val in ['amp','bcs','lo']] ):
		raise ValueError( "superconductor type " + str( sc_type ) \
								+ " not recognized. only possible values are amp,bcs or lo")

	# unpack and repack parameters
 	K = [ [Kx,PI],[PI,Ky] ]
	L = Leff
 	LWH=(L,W)
 	pbc=(False,False)

      
	params_leads_e = SimpleNamespace( t=t_lead, tp=tp_lead, mu=mu_lead )
	params_leads_h = SimpleNamespace( t=-t_lead, tp=-tp_lead, mu=-mu_lead )
	params_barrier_e = SimpleNamespace( t=t_lead, tp=tp_lead, mu=mu_barrier )
	params_barrier_h = SimpleNamespace( t=-t_lead, tp=-tp_lead, mu=-mu_barrier )


	# calculate and or set the size of the system which connects the normal leads
	# with the superconducting lead. this part is not superconducting. The idea is
	# to choose it's width L_block so that a ray which is incoming from the thinner 
	LD = -P3x
	d = P3y
	u = W-d-2
	angle_up = np.arctan( -LD/u )
	angle_down = np.arctan( LD/d )

	# lead would hit the middle of the superconducting lead.
	if L_block==None:
		if abs(P3x)>=abs(P3y):
			L_block=0
		else:
			angle = np.arctan( -P3x/P3y )
			h1 = (u+1)/2.
			L1 = h1/np.tan(angle)
			LB = L1-LD/2.
			L_block = int( abs(np.around(LB)) )
			if output: 
				print "LB exact", LB
				print "size of normal block", L_block
				print "angle in 360 degree notation", angle/np.pi*180 
		
	P1 = np.asarray( [-L_block,0,0] )
	P2 = np.asarray( [-L_block,W-1,0] )
	P3 = np.asarray( [-L_block+ P3x+P3x/float(P3y)/2.,P3y+1/2.,0] )

	if output: print "L", L, "Leff", Leff, "W", W, "LD", LD, \
			 "L_block", L_block, "angle up", angle_up/np.pi*180, \
			 "angle down", angle_down/np.pi*180 


	# make a random seed
	frame= inspect.currentframe()
	args, _, _, values = inspect.getargvalues(frame)
	tmpstr=str( [(i, values[i]) for i in args]) #form a string of all the input values
	rnd_seed = int(int(hashlib.md5(tmpstr).hexdigest(),base=16) % (2**32)) #take last 32 bits of this huge integer
	np.random.seed(rnd_seed)

	# overwrite with predefined seed, so results can be reproduced
	np.random.seed(seed)


	Ltot = int(-P3[0])

	if output:
		print "building a disorder grid of dimension", Ltot, "x", W

		
	disorder_arr = U0*np.reshape( np.random.normal(scale=1,size=Ltot*W),(Ltot,W) )
	p = SimpleNamespace( t=t, tp=tp, tpp=tpp, tppp=tppp, \
								t_h=t_h, tp_h=tp_h, tpp_h=tpp_h, tppp_h=tppp_h, \
								mu=mu, mu_h=mu_h, \
								delta=delta, s=s, K=K, phi=phi, jlim=jlim, \
								U=disorder_arr )



	# parameters for shapes
	LWH_block_shape = ( L_block-2,W-1 )
	LWH_barrier_shape = ( 2,W-1 )
	LWH_sc_shape = ( L-1,W-1 )
	LWH_lead_shape_up = ( 1.,np.sqrt( LD**2+u**2 ) )
	LWH_lead_shape_down = ( 1.,np.sqrt( LD**2+d**2 ) )

	# parameters for position of leads
	offset_up = -L_block+P3x,P3y+1
	offset_down = -L_block,0
	if output: 
		print "offset up", offset_up, "offset down", offset_down
		print "angle up", angle_up, "angle down", angle_down
		print "LD,u,d", LD,u,d
		print "P3", P3

	# MODELS
	# system models
	model_e         = simple_model.DisorderedElectronGas2D( params_leads_e,'e' )
	model_h         = simple_model.DisorderedElectronGas2D( params_leads_h,'h' )
	model_barrier_e = simple_model.DisorderedElectronGas2D( params_barrier_e,'e' )
	model_barrier_h = simple_model.DisorderedElectronGas2D( params_barrier_h,'h' )

	if sc_type=='amp':
		model_sc = amperian_model.Amperian()
	elif sc_type=='bcs':
		model_sc = amperian_model.BCS()
	elif sc_type=='lo':
		model_sc = amperian_model.LO2D()

	# lead models
	model_lead_e = simple_model.ElectronGasLead2D( params_leads_e, 'e' )
	model_lead_h = simple_model.ElectronGasLead2D( params_leads_h, 'h' )

	
	# PARAMS II
	params_sys_triangle = SimpleNamespace( LWH=LWH,pbc=pbc,translat_sym=None )
	params_sys_sc = SimpleNamespace( LWH=LWH,pbc=pbc,translat_sym=None, \
												cutoff_pair=cutoff )

	params_lead_up = SimpleNamespace( LWH=LWH, pbc=pbc, translat_sym=(-u,LD) )
	params_lead_down = SimpleNamespace( LWH=LWH, pbc=pbc, translat_sym=(-d,-LD) )
	params_lead_sc = SimpleNamespace( LWH=LWH,pbc=(False,False),\
												 translat_sym=(Leff,0), \
												 cutoff_pair=cutoff )
	
	# SHAPES
	shape_triangle = shapes.triangle( P3,P1,P2 )
	shape_block = shapes.rectangle( LWH_block_shape, offset=(-L_block,0) )
	shape_barrier = shapes.rectangle( LWH_barrier_shape, offset=(-2,0) )
	shape_sc = shapes.rectangle( LWH_sc_shape, offset=( 0,0) )
	shape_lead_up = shapes.ribbon( LWH_lead_shape_up, angle_up, offset=offset_up )
	shape_lead_down = shapes.ribbon( LWH_lead_shape_down, angle_down, offset=offset_down )
	shape_sc_lead = shapes.ribbon( LWH_sc_shape, offset=(Leff,0)  )

	# BUILDERS
	# triangle
	sys_obj_triangle_e = standard_sys.BaseSystem( model_e,shape_triangle,params_sys_triangle )
	sys_obj_triangle_h = standard_sys.BaseSystem( model_h,shape_triangle,params_sys_triangle )
	sys_triangle_e = sys_obj_triangle_e.sys
	sys_triangle_h = sys_obj_triangle_h.sys
	# normal block
	sys_obj_block_e = standard_sys.BaseSystem( model_e,shape_block,params_sys_triangle )
	sys_obj_block_h = standard_sys.BaseSystem( model_h,shape_block,params_sys_triangle )
	sys_block_e = sys_obj_block_e.sys
	sys_block_h = sys_obj_block_h.sys
	# barrier
	sys_obj_barrier_e = standard_sys.BaseSystem( model_barrier_e,shape_barrier,params_sys_triangle )
	sys_obj_barrier_h = standard_sys.BaseSystem( model_barrier_h,shape_barrier,params_sys_triangle )
	sys_barrier_e = sys_obj_barrier_e.sys
	sys_barrier_h = sys_obj_barrier_h.sys
	# amperian block
	if sc_type=='amp':
		sys_obj_sc = nambu_sys.LongrangeNambuSystem( model_sc,shape_sc,params_sys_sc )
	else:
		sys_obj_sc = nambu_sys.NambuSystem( model_sc,shape_sc,params_sys_sc )
	sys_sc = sys_obj_sc.sys

	# normal leads
	lead_obj_up_e = PES( model_lead_e,shape_lead_up,params_lead_up )
	lead_obj_up_h = PES( model_lead_h,shape_lead_up,params_lead_up )
	lead_obj_down_e = PES( model_lead_e,shape_lead_down,params_lead_down )
	lead_obj_down_h = PES( model_lead_h,shape_lead_down,params_lead_down )
	lead_up_e = lead_obj_up_e.sys
	lead_up_h = lead_obj_up_h.sys
	lead_down_e = lead_obj_down_e.sys
	lead_down_h = lead_obj_down_h.sys
	# amperian lead
	if sc_type=='amp':
		lead_obj_sc = nambu_sys.LongrangeNambuSystem( model_sc,shape_sc_lead,params_lead_sc )
	else:
		lead_obj_sc = nambu_sys.NambuSystem( model_sc,shape_sc_lead,params_lead_sc )
	lead_sc = lead_obj_sc.sys


	# CLUEING SYSTEMS TOGETHER
	sys = sys_triangle_e
	sys += sys_triangle_h
	if L_block>0:
		sys += sys_block_e
		sys += sys_block_h
		sys += sys_barrier_e
		sys += sys_barrier_h
	sys += sys_sc

	if output:
		kwant.plotter.plot( sys,fig_size=(10,10),site_size=0.2,hop_lw=0.1,num_lead_cells=1 );
		print "building done"

	# ATTACHING THE LEADS
	sys.attach_lead( lead_up_e )
	sys.attach_lead( lead_up_h )
	sys.attach_lead( lead_down_e )
	sys.attach_lead( lead_down_h )
	sys.attach_lead( lead_sc )



 	# SCATTERING MATRIX
	fsys = sys.finalized()

	# PATCH to make leads more tolerand
	for flead in fsys.leads:
		make_lead_more_tolerant(flead)

	try:		
		S = kwant.smatrix( fsys,energy=e_in,args=([p]),out_leads=[0,1,2,3,4],in_leads=[0,1,2,3,4] )
	except: #np.linalg.linalg.LinAlgError as err:
		warnings.warn( 'calculation of scattering matrix at e=' \
							+ str(e_in) + ' failed ' + str(p.__dict__) )
		try:		
			e_in += 10**(-6)
			S = kwant.smatrix( fsys,energy=e_in,args=([p]), \
									 out_leads=[0,1,2,3,4],in_leads=[0,1,2,3,4] )
			warnings.warn( 'but succeeded with an energy offset of 10**(-6)' )
		except: # np.linalg.linalg.LinAlgError as err:
			try:		
				e_in += 10**(-4)
				S = kwant.smatrix( fsys,energy=e_in,args=([p]),\
										 out_leads=[0,1,2,3,4],in_leads=[0,1,2,3,4] )
				warnings.warn( 'but succeeded with an energy offset of 10**(-4)' )
			except:
				try:		
					e_in += 10**(-2)
					S = kwant.smatrix( fsys,energy=e_in,args=([p]), \
											 out_leads=[0,1,2,3,4],in_leads=[0,1,2,3,4] )
					warnings.warn( 'but succeeded with an energy offset of 10**(-2)' )
				except:
					return 'Failed', np.zeros( (1,1) )
					
	# CHECH UNITARITY
	Sdat = S.data
	norm = la.norm( Sdat.dot(Sdat.T.conj()) - np.eye( len(Sdat)) )
	

	# CHECK SYMMETRIES
	if check_syms:
		S_test = kwant.smatrix( fsys,energy=e_in,args=([p]),out_leads=[2,3],in_leads=[2,3] )
		symmetries.check_symmetries( S_test,fsys,2,3 )
		S_test = kwant.smatrix( fsys,energy=e_in,args=([p]),out_leads=[0,1],in_leads=[0,1] )
		symmetries.check_symmetries( S_test,fsys,0,1 )


	# calculate conductance matrix
	no_leads = 5
	G = np.zeros( (no_leads,no_leads) )
	for i in range(no_leads):
		for j in range(no_leads):
			G[i,j] = S.transmission(i,j)


	if return_fsys:
		return e_in, G, norm, fsys, p
	else:
		return e_in, G, norm



