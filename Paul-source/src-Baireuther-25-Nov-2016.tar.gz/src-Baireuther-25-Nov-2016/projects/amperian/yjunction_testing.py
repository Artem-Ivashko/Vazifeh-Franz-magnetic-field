#!/usr/bin/env python
# Filename amperian.py

""" 
This file contains the main code for the measurements 
on the Amperian superconductor
"""

# libraries
from __future__ import division
import numpy as np
from numpy import pi as PI
from scipy.special import erf
from scipy.special import erfinv
import kwant
from copy import deepcopy
import symmetries

# my libraries
import memory
from memory import SimpleNamespace
import shapes

import dispersion_2D
import angle_resolved_conductance_2D as ar

import amperian_model
import simple_model
import nambu_model

import standard_sys
from standard_sys import ParallelEdgesSystem as PES
import nambu_sys

import plot_data
import fname_and_title as fnt

#import angle_resolved_conductance_2D as ar
#import time

def calc_params( Leff = None, n = None, gap_angle = None, t=1 ):
	k=0
	if Leff!=None:
		k=n*np.pi/float(Leff);
		gap_angle = np.tan(k/PI)*360/(2*PI)
	else:
		k = np.pi*np.tan( gap_angle )
	K=[ [k,PI],[PI,k] ]
	mu = 2*t*( 1-np.cos(k) )
	print  "K1x = K2y = " + str( np.around(k,2) ) + ", gap angle = " \
		 + str( np.around(gap_angle,2) ) + ", mu = " + str( np.around(mu,3) )
	return K, mu

def calc_lead_mu( f, t=1., mu=0. ):
	mu_lead = mu-4*(f*t-t)
	# mu_new = -f**2 * mu - 8 * t**3 * f**2 * (f-1)
	return mu_lead

def calc_cutoffs( s, cutcorr, jcorr ):
	jlim = int(np.ceil( 1.+s*erfinv(1-jcorr) ))
	cutoff= np.sqrt( -2.*np.log( cutcorr )/(s**2) )  ;
	print "cutoff = " + str( np.around(cutoff,2) ) + ", jlim = " + str(jlim)
	return cutoff, jlim

def which_leads( fsys ):
	# lead indices
 	l_int=0; e_int=None; h_int=None; amp_int=None;
 	for lead in fsys.leads:
 		has_e=False
 		has_h=False
 		for s in lead.sites:
 			if s.family.name=='e':
 				has_e=True
 			if s.family.name=='h':
 				has_h=True
 		if has_e and has_h:
 			amp_int=l_int
 		elif has_e:
 			e_int=l_int
 		elif has_h:
 			h_int=l_int
 		l_int+=1
	return e_int, h_int, amp_int




''' 
This function constructs a Y-junction made of two normal leads 
and one Amperian lead and calculates its scattering matrix
'''

def Y_junction( Leff, W, L_block, P3x, P3y, \
						 t, mu, t_lead, mu_lead, \
						 delta, s, Kx, Ky, phi, cutoff, jlim, \
						 e_in, sc_type='amp', check_syms=False, output=False ):

 	# sanity check of parameters
 	if cutoff>=Leff/2.: raise ValueError( "warning: cutoff is larger than half the system size." )
	if not any( [sc_type==val for val in ['amp','bcs','lo']] ):
		raise ValueError( "superconductor type" + str( sc_type ) + "not recognized. only possible values are amp,bcs or lo")

	# unpack and repack parameters
 	K = [ [Kx,PI],[PI,Ky] ]
	L = Leff
 	LWH=(L,W)
 	pbc=(False,False)
	p = SimpleNamespace( mu=mu, mu_h=-mu, t=t, t_h=-t, K=K, phi=phi, \
                              s=s, delta=delta, jlim=jlim, W=W )

	params_leads_e = SimpleNamespace( t=t_lead, mu=mu_lead )
	params_leads_h = SimpleNamespace( t=-t_lead, mu=-mu_lead )

	# calculate and or set the size of the system which connects the normal leads
	# with the superconducting lead. this part is not superconducting. The idea is
	# to choose it's width L_block so that a ray which is incoming from the thinner 
	# lead would hit the middle of the superconducting lead.
	if L_block==None:
		angle = np.arctan( P3x/P3y )
		x1 = -P3x/2.
		h1 = P3y/2.
		LB = ( W-2*h1 )  /  ( 2*np.tan(angle) )  -  x1
		L_block = int( abs(np.around(LB)) )
		if output: 
			print "size of normal block", L_block
			print "angle in 360 degree notation", angle/np.pi*180 
		
	P1 = np.asarray( [-L_block,0,0] )
	P2 = np.asarray( [-L_block,W,0] )
	P3 = np.asarray( [P3x-L_block,P3y,0] )
	LD = -P3x
	d = P3y
	u = W-d
	angle_up = np.arctan( -LD/u )
	angle_down = np.arctan( LD/d )
	if output: print "L", L, "Leff", Leff, "W", W, "LD", LD, \
			 "L_block", L_block, "angle up", angle_up, "angle down", angle_down

	# parameters for shapes
	LWH_block_shape = ( L_block,W )
	LWH_sc_shape = ( L,W )
	LWH_lead_shape_up = ( 1.,np.sqrt( LD**2+u**2 ) )
	LWH_lead_shape_down = ( 1.,np.sqrt( LD**2+d**2 ) )

	# parameters for position of leads
	offset_up = P3[0],P3[1]
	offset_down = -L_block,0
	if output: print "offset up", offset_up, "offset down", offset_down
	

	# MODELS
	# system models
	model_e = simple_model.ElectronGas2D( 'e' )
	model_h = simple_model.ElectronGas2D( 'h' )
	if sc_type=='amp':
		model_sc = amperian_model.Amperian()
	elif sc_type=='bcs':
		model_sc = nambu_model.Nambu2D()
	elif sc_type=='lo':
		model_sc = amperian_model.LO2D()

	# lead models
	model_lead_e = simple_model.ElectronGasLead2D( params_leads_e, 'e' )
	model_lead_h = simple_model.ElectronGasLead2D( params_leads_h, 'h' )

	
	# PARAMS II
	params_sys_triangle = SimpleNamespace( LWH=LWH,pbc=pbc,translat_sym=None )
	params_sys_sc = SimpleNamespace( LWH=LWH,pbc=pbc,translat_sym=None, cutoff=cutoff )
	params_lead_up = SimpleNamespace( LWH=LWH, pbc=pbc, translat_sym=(-u,LD) )
	params_lead_down = SimpleNamespace( LWH=LWH, pbc=pbc, translat_sym=(-d,-LD) )
	params_lead_sc = SimpleNamespace( LWH=LWH, pbc=(False,False), translat_sym=(Leff+1,0), \
													  cutoff=cutoff )
	
	# SHAPES
	shape_triangle = shapes.triangle( P3,P1,P2 )
	shape_block = shapes.rectangle( LWH_block_shape, offset=(-L_block,0) )
	shape_sc = shapes.rectangle( LWH_sc_shape, offset=( 0,0) )
	shape_lead_up = shapes.ribbon( LWH_lead_shape_up, angle_up, offset=offset_up )
	shape_lead_down = shapes.ribbon( LWH_lead_shape_down, angle_down, offset=offset_down )
	shape_sc_lead = shapes.ribbon( LWH_sc_shape, offset=(Leff+1,0)  )

	# BUILDERS
	# triangle
	sys_obj_triangle_e = standard_sys.BaseSystem( model_lead_e,shape_triangle,params_sys_triangle )
	sys_obj_triangle_h = standard_sys.BaseSystem( model_lead_h,shape_triangle,params_sys_triangle )
	sys_triangle_e = sys_obj_triangle_e.sys
	sys_triangle_h = sys_obj_triangle_h.sys
	# normal block
	sys_obj_block_e = standard_sys.BaseSystem( model_lead_e,shape_block,params_sys_triangle )
	sys_obj_block_h = standard_sys.BaseSystem( model_lead_h,shape_block,params_sys_triangle )
	sys_block_e = sys_obj_block_e.sys
	sys_block_h = sys_obj_block_h.sys
	# amperian block
	if sc_type=='amp':
		sys_obj_sc = nambu_sys.LongrangeNambuSystem( model_sc,shape_sc,params_sys_sc )
	else:
		sys_obj_sc = nambu_sys.NambuSystem( model_sc,shape_sc,params_sys_sc )
	sys_sc = sys_obj_sc.sys

	# normal leads
	lead_obj_up_e = PES( model_lead_e,shape_lead_up,params_lead_up )
	lead_obj_up_h = PES( model_lead_h,shape_lead_up,params_lead_up )
	lead_obj_down_e = PES( model_lead_e,shape_lead_down,params_lead_down )
	lead_obj_down_h = PES( model_lead_h,shape_lead_down,params_lead_down )
	lead_up_e = lead_obj_up_e.sys
	lead_up_h = lead_obj_up_h.sys
	lead_down_e = lead_obj_down_e.sys
	lead_down_h = lead_obj_down_h.sys
	# amperian lead
	lead_obj_sc = nambu_sys.NambuSystem( model_sc,shape_sc_lead,params_lead_sc )
	lead_sc = lead_obj_sc.sys


	# CLUEING SYSTEMS TOGETHER
	sys = sys_triangle_e
	sys += sys_triangle_h
	sys += sys_block_e
	sys += sys_block_h
	sys += sys_sc

	# ATTACHING THE LEADS
	sys.attach_lead( lead_up_e )
	sys.attach_lead( lead_up_h )
	sys.attach_lead( lead_down_e )
	sys.attach_lead( lead_down_h )
	sys.attach_lead( lead_sc )

	if output:
		kwant.plotter.plot( sys,fig_size=(20,7),site_size=0.2,hop_lw=0.1,num_lead_cells=2 );
		print "building done"

 	# SCATTERING MATRIX
	fsys = sys.finalized()
	S = kwant.smatrix( fsys,energy=e_in,args=([p]),out_leads=[0,1,2,3],in_leads=[0,1,2,3] )

	# CHECK SYMMETRIES
	if check_syms:
		S_test = kwant.smatrix( fsys,energy=e_in,args=([p]),out_leads=[2,3],in_leads=[2,3] )
		symmetries.check_symmetries( S_test,fsys,2,3 )
		S_test = kwant.smatrix( fsys,energy=e_in,args=([p]),out_leads=[0,1],in_leads=[0,1] )
		symmetries.check_symmetries( S_test,fsys,0,1 )

	# calculate conductance matrix
	no_leads = 4
	G = np.zeros( (no_leads,no_leads) )
	for i in range(no_leads):
		for j in range(no_leads):
			G[i,j] = S.transmission(i,j)
	
	return G
