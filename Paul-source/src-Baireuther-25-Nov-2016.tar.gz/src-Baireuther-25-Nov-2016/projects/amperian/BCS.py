#!/usr/bin/env python
# Filename amperian.py

""" 
This file contains the main code for the measurements 
on the BCS superconductor
"""

# libraries
from __future__ import division
import numpy as np
from numpy import pi as PI
import kwant

# my libraries
import memory
from memory import SimpleNamespace
import shapes

import dispersion_2D
import angle_resolved_conductance_2D as ar

import amperian_model
import simple_model
import nambu_model

from standard_sys import ParallelEdgesSystem as PES
import nambu_sys

import plot_data
import fname_and_title as fnt

#import angle_resolved_conductance_2D as ar
#import time

def calc_params( Leff = None, n = None, gap_angle = None, t=1 ):
	k=0
	if Leff!=None:
		k=n*np.pi/float(Leff);
		gap_angle = np.tan(k/PI)*360/(2*PI)
	else:
		k = np.pi*np.tan( gap_angle )
	K=[ [k,PI],[PI,k] ]
	mu = 2*t*( 1-np.cos(k) )
	print  "K1x = K2y = " + str( np.around(k,2) ) + ", gap angle = " \
		 + str( np.around(gap_angle,2) ) + ", mu = " + str( np.around(mu,3) )
	return K, mu

def calc_dispersion_2D( L,W, mu, mu_h, t, t_h, delta, \
							  kxvecs, kyvecs, points, no_bands,	plot = False):
	LWH = L,W
	LWH_for_shape = L-1, W-1
	square = shapes.square( LWH_for_shape )
	# SYSTEM
	K=[  [PI,Ky],[Kx,PI]  ]
	params = SimpleNamespace( LWH=LWH, translat_sym=None )
	p = SimpleNamespace( mu=mu, mu_h=mu_h, t=t, t_h=t_h, delta=delta )
	BCS_model = nambu_model.Nambu2D()

	# LEADS
	params.translat_sym = (L,0)
	sys_x = nambu_sys.NambuSystem( BCS_model, square, params )
	sys_x.finalize()
	fsys_x = sys_x.fsys
	params.translat_sym=(0,W)
	sys_y = nambu_sys.NambuSystem( BCS_model, square, params )
	sys_y.finalize()
	fsys_y = sys_y.fsys

	kwant.plotter.plot( sys_x.sys )
	kwant.plotter.plot( sys_y.sys )

	# PARAMETERS FOR DISPERSION
	options = SimpleNamespace( kxvecs=kxvecs, kyvecs=kyvecs, plot=False )

	ret = dispersion_2D.unfolded_bandstructure( fsys_x=fsys_x, fsys_y=fsys_y, p=p, \
                                                    no_bands=no_bands, options=options )

	return ret

def plot_dispersion_2D( infos, data ):

	path = "/clusterdata/baireuther/data/amperian/dispersions/"
	order = ['L', 'W', 'mu', 'delta', 's', 'pbc', 'eps', 'Ky', 'Kx']
	omit = ['kxvecs','kyvecs','_out']
		
	fname,title =  fnt.make_fname_and_title( [infos], omit, order, 'Dispersion', linewidth=60 )
	plot_data.plot_unfolded_dispersion( data, eps=0., delta_eps=.2, whichbands=[0], title=title, fname=path+fname )

	return


def angle_resolved_conductance( L, W, t, mu, delta, \
										  pbc_x, pbc_y, e_in ):

 	# unpack parameters and repack
 	LWH=(L,W)
 	pbc=(pbc_x,pbc_y)

 	# fixed parameters
 	params_sys = SimpleNamespace( LWH=LWH, pbc=pbc, translat_sym=None )
 	params_leads_l = SimpleNamespace( LWH=LWH, pbc=pbc, translat_sym=(-1,0) )
	params_leads_r = SimpleNamespace( LWH=LWH, pbc=pbc, translat_sym=(L,0) )
 	params_leads_e = SimpleNamespace( t=t, mu=mu )
 	params_leads_h = SimpleNamespace( t=-t, mu=-mu )

 	# variable system parameters
 	p = SimpleNamespace( mu=mu, mu_h=-mu, t=t, t_h=-t, \
                              delta=delta, W=W )

	# shape
	LWH_for_shape = L-1, W-1
	square = shapes.square( LWH_for_shape )

	# system
	BCS_model = nambu_model.Nambu2D()
	sys_obj = nambu_sys.NambuSystem( BCS_model,square,params_sys )
	sys = sys_obj.sys

 	# left leads
 	lead_e_model = simple_model.ElectronGasLead2D( params_leads_e, 'e' )
 	lead_h_model = simple_model.ElectronGasLead2D( params_leads_h, 'h' )
	lead_e_obj = PES( lead_e_model, square, params_leads_l )
	lead_h_obj = PES( lead_h_model, square, params_leads_l )
	lead_e = lead_e_obj.sys
	lead_h = lead_h_obj.sys

 	# right lead
 	lead_BCS_model = nambu_model.Nambu2D()
	lead_BCS_obj = nambu_sys.NambuSystem( lead_BCS_model,square,params_leads_r )	
	lead_BCS = lead_BCS_obj.sys

 	# attach leads and finalize
 	sys.attach_lead( lead_e )
 	sys.attach_lead( lead_h )
 	sys.attach_lead( lead_BCS )

	kwant.plotter.plot( sys, fig_size=(24,10), site_size=0.05, hop_lw=0.02, num_lead_cells=1 );

 	fsys = sys.finalized()
	

	infos = dict()
 	# lead indices
 	lind=0; e_ind=None; h_ind=None; BCS_ind=None;
 	for lead in fsys.leads:
 		has_e=False
 		has_h=False
 		for s in lead.sites:
 			if s.family.name=='e':
 				has_e=True
 			if s.family.name=='h':
 				has_h=True
 		if has_e and has_h:
 			BCS_ind=lind
 		elif has_e:
 			e_ind=lind
 		elif has_h:
 			h_ind=lind
 		lind+=1
 	infos['electron lead'] = e_ind
 	infos['hole lead'] = h_ind
 	infos['BCS lead'] = BCS_ind


 	# calculate angle resolved conductance
 	grid_rA, infos['calc_cond rA'] = ar.calc_cond( fsys, p, params_leads_e, params_leads_h, [e_ind], [h_ind], e_in )
 	grid_r, infos['calc_cond r'] = ar.calc_cond( fsys, p, params_leads_e, params_leads_e, [e_ind], [e_ind], e_in )

 	return grid_r, grid_rA, infos



def angle_resolved_conductance__el_doped_leads( L, W, t, mu, f, delta, \
										  pbc_x, pbc_y, e_in ):

 	# unpack parameters and repack
 	LWH=(L,W)
 	pbc=(pbc_x,pbc_y)

 	# fixed parameters
 	params_sys = SimpleNamespace( LWH=LWH, pbc=pbc, translat_sym=None )
 	params_leads_l = SimpleNamespace( LWH=LWH, pbc=pbc, translat_sym=(-1,0) )
	params_leads_r = SimpleNamespace( LWH=LWH, pbc=pbc, translat_sym=(L,0) )
	t_new = f*t
	mu_new = mu-4*(t_new-t)
 	params_leads_e = SimpleNamespace( t=t_new, mu=mu_new )
 	params_leads_h = SimpleNamespace( t=-t_new, mu=-mu_new )

 	# variable system parameters
 	p = SimpleNamespace( mu=mu, mu_h=-mu, t=t, t_h=-t, \
                              delta=delta, W=W )

	# shape
	LWH_for_shape = L-1, W-1
	square = shapes.square( LWH_for_shape )

	# system
	BCS_model = nambu_model.Nambu2D()
	sys_obj = nambu_sys.NambuSystem( BCS_model,square,params_sys )
	sys = sys_obj.sys

 	# left leads
 	lead_e_model = simple_model.ElectronGasLead2D( params_leads_e, 'e' )
 	lead_h_model = simple_model.ElectronGasLead2D( params_leads_h, 'h' )
	lead_e_obj = PES( lead_e_model, square, params_leads_l )
	lead_h_obj = PES( lead_h_model, square, params_leads_l )
	lead_e = lead_e_obj.sys
	lead_h = lead_h_obj.sys

 	# right lead
 	lead_BCS_model = nambu_model.Nambu2D()
	lead_BCS_obj = nambu_sys.NambuSystem( lead_BCS_model,square,params_leads_r )	
	lead_BCS = lead_BCS_obj.sys

 	# attach leads and finalize
 	sys.attach_lead( lead_e )
 	sys.attach_lead( lead_h )
 	sys.attach_lead( lead_BCS )

	kwant.plotter.plot( sys, fig_size=(24,10), site_size=0.05, hop_lw=0.02, num_lead_cells=1 );

 	fsys = sys.finalized()
	

	infos = dict()
 	# lead indices
 	lind=0; e_ind=None; h_ind=None; BCS_ind=None;
 	for lead in fsys.leads:
 		has_e=False
 		has_h=False
 		for s in lead.sites:
 			if s.family.name=='e':
 				has_e=True
 			if s.family.name=='h':
 				has_h=True
 		if has_e and has_h:
 			BCS_ind=lind
 		elif has_e:
 			e_ind=lind
 		elif has_h:
 			h_ind=lind
 		lind+=1
 	infos['electron lead'] = e_ind
 	infos['hole lead'] = h_ind
 	infos['BCS lead'] = BC_ind


 	# calculate angle resolved conductance
 	grid_rA, infos['calc_cond rA'] = ar.calc_cond( fsys, p, params_leads_e, params_leads_h, [e_ind], [h_ind], e_in )
 	grid_r, infos['calc_cond r'] = ar.calc_cond( fsys, p, params_leads_e, params_leads_e, [e_ind], [e_ind], e_in )

 	return grid_r, grid_rA, infos
