# from future
from __future__ import division

# libraries
import numpy as np
from scipy.sparse import linalg as lag
import matplotlib.pyplot as plt;
import kwant

# my libraries (use the NEW library!)
import use_lib_v2; use_lib_v2.init()

import weyl_sc_pdotsigma as weyl_pdotsigma_4band
import sc_4band
from memory import SimpleNamespace


"""
TABLE OF CONTENTS

1.   BUILDERS
1.1 make_finite_1D_sns_junction__TB
1.2 make_finite_2D_sns_junction__xz__domainwalls
1.3 make_coated_square_wire_xy

2.  SPECTRA AND WAVE FUNCTIONS
2.1 calc_ens
2.2 calc_ens_with_charge
2.3 get_e_h_weights
2.4 trace_bands

3.  DATA CONTAINERS
3.1 make_p
3.2 make_p_HACK

4.  VISUALIZATION
4.1 plot_system

"""


""" 1. Builders: The Builders we will need are on a lattice in x-, xy- and xz-direction """

""" 1.1 make_finite_1D_sns_junction__TB """
def make_1D_sns_junction__with_tb( wx_sc_left, wx_wsm, wx_sc_right, wx_tb_l, wx_tb_r, \
                                     model, plot_sys=False, p=None ):

    if model=='pdotsigma_4band':
        model_wsm    = weyl_pdotsigma_4band.WeylSC1D_x()
        model_wsm_tb = weyl_pdotsigma_4band.WeylSC1D_x( params=SimpleNamespace( mu_W=p.mu_TB ) )
        model_msc_L  = sc_4band.MetallicSC1D_x( params=SimpleNamespace() )
        model_msc_R  = sc_4band.MetallicSC1D_x( params=SimpleNamespace() )
    else:
        raise ValueError( model + ", is not implemented. Possible models are 'pdotsigma_4band'" )

    # lattices
    lat_e = model_wsm.lat_e
    lat_h = model_wsm.lat_h

    # builder
    sys = kwant.Builder()

    x1=wx_sc_left
    x2=x1+wx_tb_l
    x3=x2+wx_wsm
    x4=x3+wx_tb_r
    x5=x4+wx_sc_right
    
    # first, define all sites and their onsite energies
    # a) SC (left)
    for nx in range(x1):
        sys[lat_e(nx,)]=model_msc_L.onsite_e
        sys[lat_h(nx,)]=model_msc_L.onsite_h
        sys[lat_h(nx,),lat_e(nx,)]=model_msc_L.pairing

    # b) WSM-TB (left)
    for nx in range(x1,x2):
        sys[lat_e(nx,)]=model_wsm_tb.onsite_e
        sys[lat_h(nx,)]=model_wsm_tb.onsite_h        
        
    # c) WSM (middle)
    for nx in range(x2,x3):
        sys[lat_e(nx,)]=model_wsm.onsite_e
        sys[lat_h(nx,)]=model_wsm.onsite_h

    # b) WSM-TB (right)
    for nx in range(x3,x4):
        sys[lat_e(nx,)]=model_wsm_tb.onsite_e
        sys[lat_h(nx,)]=model_wsm_tb.onsite_h 
        
    # e) SC (right)
    for nx in range(x4,x5):
        sys[lat_e(nx,)]=model_msc_R.onsite_e
        sys[lat_h(nx,)]=model_msc_R.onsite_h
        sys[lat_h(nx,),lat_e(nx,)]=model_msc_R.pairing
        
    # second, set the hoppings, the hopping between metallic SC and WSM is a metallic hopping
    # a) SC (left)
    for nx in range(x1):
        if nx<x4-1:
            sys[lat_e(nx+1,),lat_e(nx,)]=model_msc_L.hop_e
            sys[lat_h(nx+1,),lat_h(nx,)]=model_msc_L.hop_h

    # c) WSM (middle)
    for nx in range(x1,x4-1):
        if nx<x5-1:
            sys[lat_e(nx+1,),lat_e(nx,)]=model_wsm.hop_e
            sys[lat_h(nx+1,),lat_h(nx,)]=model_wsm.hop_h

    # e) SC (right)
    for nx in range(x4-1,x5-1):
        sys[lat_e(nx+1,),lat_e(nx,)]=model_msc_R.hop_e
        sys[lat_h(nx+1,),lat_h(nx,)]=model_msc_R.hop_h

    # finalize the system
    fsys = sys.finalized()

    # plot lattice and hoppings if desired
    if plot_sys:
        plot_system(sys,fsys,p,12,1)        
    
    return fsys



""" 1.2 make_finite_2D_sns_junction__xz__domainwalls """
def make_2D_sns_junction__xz__domainwalls( wx_sc_left, wx_wsm, wx_sc_right,\
                                                  wx_tb_l, wx_tb_r,\
                                                  wz_B, wz_DW, wz_T, pbc_z=True, \
                                                  plot_sys=False,p=None ):

    # get models
    model_wsm   = weyl_pdotsigma_4band.WeylSC2D_xz()
    model_msc_L = sc_4band.MetallicSC2D_xz()
    model_msc_R = sc_4band.MetallicSC2D_xz()

    # tunnel barrier with domain walls
    # the lower part of the TB has the minimal value of mu_W and the upper part the maximal value
    model_tb_low  = weyl_pdotsigma_4band.WeylSC2D_xz( params=SimpleNamespace( mu_W=p.mu_TB_min ) )
    model_tb_high = weyl_pdotsigma_4band.WeylSC2D_xz( params=SimpleNamespace( mu_W=p.mu_TB_max ) )
    model_tb_dw_l = []
    # make a list of models with increasing mu_W (mu_TB_min<mu_W<mu_TB_max)
    mu_dw_l = np.linspace( p.mu_TB_min,p.mu_TB_max,wz_DW+2 )
    for n in range(1,wz_DW+1):
        model_tb_dw_l.append( weyl_pdotsigma_4band.WeylSC2D_xz( params=SimpleNamespace( mu_W=mu_dw_l[n] ) ) )

    # lattices
    lat_e = model_wsm.lat_e
    lat_h = model_wsm.lat_h

    # builder
    sys = kwant.Builder()

    # first, define all sites and their onsite energies
    x1=wx_sc_left
    x2=x1+wx_tb_l
    x3=x2+wx_wsm
    x4=x3+wx_tb_r
    x5=x4+wx_sc_right
    z1=wz_B
    z2=z1+wz_DW
    z3=z2+wz_T
    z4=z3+wz_DW

    # a) SC (left)
    for nx in range(x1):
        for nz in range(z4):
            sys[lat_e(nx,nz)]=model_msc_L.onsite_e
            sys[lat_h(nx,nz)]=model_msc_L.onsite_h
            sys[lat_h(nx,nz),lat_e(nx,nz)]=model_msc_L.pairing

    # b) TB (left)
    for nx in range(x1,x2):
        for nz in range(z1):
            model=model_tb_low
            sys[lat_e(nx,nz)]=model.onsite_e
            sys[lat_h(nx,nz)]=model.onsite_h
        for nz in range(z1,z2):
            n=nz-z1
            model=model_tb_dw_l[n]
            sys[lat_e(nx,nz)]=model.onsite_e
            sys[lat_h(nx,nz)]=model.onsite_h
        for nz in range(z2,z3):
            model=model_tb_high
            sys[lat_e(nx,nz)]=model.onsite_e
            sys[lat_h(nx,nz)]=model.onsite_h
        for nz in range(z3,z4):
            n=nz-z3
            model=model_tb_dw_l[-n-1]
            sys[lat_e(nx,nz)]=model.onsite_e
            sys[lat_h(nx,nz)]=model.onsite_h

    # c) WSM (middle)
    for nx in range(x2,x3):
        for nz in range(z4):
            sys[lat_e(nx,nz)]=model_wsm.onsite_e
            sys[lat_h(nx,nz)]=model_wsm.onsite_h

    # d) TB (right)
    for nx in range(x3,x4):
        for nz in range(z1):
            model=model_tb_low
            sys[lat_e(nx,nz)]=model.onsite_e
            sys[lat_h(nx,nz)]=model.onsite_h
        for nz in range(z1,z2):
            n=nz-z1
            model=model_tb_dw_l[n]
            sys[lat_e(nx,nz)]=model.onsite_e
            sys[lat_h(nx,nz)]=model.onsite_h
        for nz in range(z2,z3):
            model=model_tb_high
            sys[lat_e(nx,nz)]=model.onsite_e
            sys[lat_h(nx,nz)]=model.onsite_h
        for nz in range(z3,z4):
            n=nz-z3
            model=model_tb_dw_l[-n-1]
            sys[lat_e(nx,nz)]=model.onsite_e
            sys[lat_h(nx,nz)]=model.onsite_h
            
    # e) SC (right)
    for nx in range(x4,x5):
        for nz in range(z4):
            sys[lat_e(nx,nz)]=model_msc_R.onsite_e
            sys[lat_h(nx,nz)]=model_msc_R.onsite_h
            sys[lat_h(nx,nz),lat_e(nx,nz)]=model_msc_R.pairing
            
    
    # second, set the hoppings in x-direction
    # a) sc left
    for nx in range(x1):
        for nz in range(z4):
            if nx<x4-1:
                sys[lat_e(nx+1,nz),lat_e(nx,nz)]=model_msc_L.hop_e
                sys[lat_h(nx+1,nz),lat_h(nx,nz)]=model_msc_L.hop_h
        
    # b) WSM and TB
    for nx in range(x1,x4-1):
        for nz in range(z4):
            sys[lat_e(nx+1,nz),lat_e(nx,nz)]=model_wsm.hop_e
            sys[lat_h(nx+1,nz),lat_h(nx,nz)]=model_wsm.hop_h
    
    # c) sc hoppings
    for nx in range(x4-1,x5-1):
        for nz in range(z4):
            sys[lat_e(nx+1,nz),lat_e(nx,nz)]=model_msc_R.hop_e
            sys[lat_h(nx+1,nz),lat_h(nx,nz)]=model_msc_R.hop_h

            
    # third, set the hoppings in z-direction
    # a) sc left
    for nx in range(x1):
        for nz in range(z4-1):
            sys[lat_e(nx,nz+1),lat_e(nx,nz)]=model_msc_L.hop_e
            sys[lat_h(nx,nz+1),lat_h(nx,nz)]=model_msc_L.hop_h
        if pbc_z:
            sys[lat_e(nx,0),lat_e(nx,z4-1)]=model_msc_L.hop_e
            sys[lat_h(nx,0),lat_h(nx,z4-1)]=model_msc_L.hop_h
        
    # b) WSM
    for nx in range(x1,x4):
        for nz in range(z4-1):
            sys[lat_e(nx,nz+1),lat_e(nx,nz)]=model_wsm.hop_e
            sys[lat_h(nx,nz+1),lat_h(nx,nz)]=model_wsm.hop_h
        if pbc_z:
            sys[lat_e(nx,0),lat_e(nx,z4-1)]=model_wsm.hop_e
            sys[lat_h(nx,0),lat_h(nx,z4-1)]=model_wsm.hop_h
                
    # c) barrier and sc hoppings
    for nx in range(x4,x5):
        for nz in range(z4-1):
            sys[lat_e(nx,nz+1),lat_e(nx,nz)]=model_msc_R.hop_e
            sys[lat_h(nx,nz+1),lat_h(nx,nz)]=model_msc_R.hop_h
        if pbc_z:
            sys[lat_e(nx,0),lat_e(nx,z4-1)]=model_msc_R.hop_e
            sys[lat_h(nx,0),lat_h(nx,z4-1)]=model_msc_R.hop_h

    # finalize the system
    fsys = sys.finalized()

    # plot lattice and hoppings if desired
    if plot_sys:
        plot_system(sys,fsys,p,12,10)        
    
    return fsys



""" 1.3 make_coated_square_wire_xy """
def make_coated_square_wire_xy(R1,R2,Rtb,plot_sys=False,p=None):

    model_wsm    = weyl_pdotsigma_4band.WeylSC2D_xy()
    model_wsm_tb = weyl_pdotsigma_4band.WeylSC2D_xy( params=SimpleNamespace( mu_W=p.mu_TB ) )
    model_sc     = sc_4band.MetallicSC2D_xy()
             
    # shape
    margin=10**(-3)
    def square( x,y,R ):
        if x**2<R**2-margin and y**2<R**2-margin:
            return True
        else:
            return False
        
    # lattices
    lat_e = model_wsm.lat_e
    lat_h = model_wsm.lat_h

    # builder
    sys = kwant.Builder()

    # onsite energies
    for nx in range(-R2,R2+1):
        for ny in range(-R2,R2+1):
            if square(nx,ny,R1-Rtb):
                sys[lat_e(nx,ny)]=model_wsm.onsite_e
                sys[lat_h(nx,ny)]=model_wsm.onsite_h
            elif square(nx,ny,R1):
                sys[lat_e(nx,ny)]=model_wsm_tb.onsite_e
                sys[lat_h(nx,ny)]=model_wsm_tb.onsite_h
            elif square(nx,ny,R2):
                sys[lat_e(nx,ny)]=model_sc.onsite_e
                sys[lat_h(nx,ny)]=model_sc.onsite_h
                sys[lat_h(nx,ny),lat_e(nx,ny)]=model_sc.pairing

    # hoppings
    for nx in range(-R2,R2+1):
        for ny in range(-R2,R2+1):
            if square(nx,ny,R1):
                if square(nx+1,ny,R1):
                    sys[lat_e(nx+1,ny),lat_e(nx,ny)]=model_wsm.hop_e
                    sys[lat_h(nx+1,ny),lat_h(nx,ny)]=model_wsm.hop_h
                if square(nx,ny+1,R1):
                    sys[lat_e(nx,ny+1),lat_e(nx,ny)]=model_wsm.hop_e
                    sys[lat_h(nx,ny+1),lat_h(nx,ny)]=model_wsm.hop_h
                if square(nx+1,ny,R2) and not square(nx+1,ny,R1):
                    sys[lat_e(nx+1,ny),lat_e(nx,ny)]=model_sc.hop_e
                    sys[lat_h(nx+1,ny),lat_h(nx,ny)]=model_sc.hop_h
                if square(nx,ny+1,R2) and not square(nx,ny+1,R1):
                    sys[lat_e(nx,ny+1),lat_e(nx,ny)]=model_sc.hop_e
                    sys[lat_h(nx,ny+1),lat_h(nx,ny)]=model_sc.hop_h
            
            elif square(nx,ny,R2):
                if square(nx+1,ny,R2):
                    sys[lat_e(nx+1,ny),lat_e(nx,ny)]=model_sc.hop_e
                    sys[lat_h(nx+1,ny),lat_h(nx,ny)]=model_sc.hop_h
                if square(nx,ny+1,R2):
                    sys[lat_e(nx,ny+1),lat_e(nx,ny)]=model_sc.hop_e
                    sys[lat_h(nx,ny+1),lat_h(nx,ny)]=model_sc.hop_h

    fsys = sys.finalized()
                    
    if plot_sys:
        plot_system(sys,fsys,p,8,8)

    return fsys



""" 2. SPECTRA AND WAVE FUNCTIONS """

"""2.1 calc_ens calculates the no_states lowest eigenvalues of a tight
binding Hamiltonian

"""
def calc_ens(fsys,p,return_vecs=False,no_states=10,e0=0,precision=10**(-6)):

    ham_sparse_coo = fsys.hamiltonian_submatrix( args=([p]),sparse=True )
    ham_sparse = ham_sparse_coo.tocsc()

    if return_vecs:
        evals,evecsT = lag.eigsh( ham_sparse,k=no_states,return_eigenvectors=True, \
                                  which='LM',sigma=e0,tol=precision )
        return evals, evecsT.T
    else:
        evals = lag.eigsh( ham_sparse,k=no_states,return_eigenvectors=False, \
                           which='LM',sigma=e0,tol=precision )
        return evals


"""2.2 calc_ens_with_charge calculated the eigenvalues of a
tight-binding hamiltonian together with the charge of the
corresponding quasiparticles. We use the convention where the
electrons have positive charge.

"""
def calc_ens_with_charge(fsys,p,no_states=10,e0=0,precision=10**(-6),return_vecs=False):
    ham_sparse_coo = fsys.hamiltonian_submatrix( args=([p]),sparse=True )
    ham_sparse = ham_sparse_coo.tocsc()
    evals,evecsT = lag.eigsh( ham_sparse,k=no_states,return_eigenvectors=True, \
                              which='LM',sigma=e0,tol=precision )
    evecs=evecsT.T

    sites=[ s.pos[0] for s in fsys.sites ]
    families=[ s.family.name for s in fsys.sites ]
    
    no_sites=len(sites)
    no_orbs =int(len(evecs[0])/no_sites)
        
    ens,charges,vecs=[],[],[]
    for n in range(no_states):

        wf=np.reshape(evecs[n],(no_sites,no_orbs))
        en=evals[n]
        e_w,h_w=get_e_h_weights(wf,families)

        ens.append(en)
        charges.append(e_w-h_w)
        vecs.append( wf )

    if return_vecs:
        return ens,charges,vecs,sites,families
    else:
        return ens,charges


"""2.3 get_e_h_weights is a function that takes a wave function and
reports back how much weight is on the electron part and how much is
on the hole part. This requires that there are separate lattices for
electrons and holes which are named 'e' and 'h'.

"""
def get_e_h_weights(wf,families):
    no_sites = len(wf)
       
    norm = np.vdot(wf,wf)
    weights = [ np.vdot(v,v)/norm for v in wf ]

    e_weight=0; h_weight=0;
    for n in range(no_sites):
        if families[n]=='e':
            e_weight+=weights[n]
        elif families[n]=='h':
            h_weight+=weights[n]
    if abs(e_weight+h_weight-1)>10**(-3):
        raise ValueError( "The sum of electron and hole weights is not 1" )

    return e_weight,h_weight


""" 2.4 trace_bands calculates the zero modes using a parallelized zero finder
input
-----

fsys     -- finalized system
p        -- parameters of system
interval -- energy window in which we are looking for zeros
no_modes -- minimum number of states to be calculated


return
------
zero_modes, crossing_bands, other_bands, other_bands_2, bands
"""
def trace_bands( bands ):

    skzs=sorted( bands.keys() )
    no_modes=len(bands[skzs[0]]['ens'])
        
    # storage for the traced bands
    traced_modes=[]
    kz0=skzs[0]
    
    
    # follow those evecs in the interval
    for n in range(no_modes):
        traced_mode={}

        m0=sorted( enumerate(bands[kz0]['ens']), key=lambda x: abs(x[1]) )[0][0]
        e0=bands[kz0]['ens'][m0]
        v0=bands[kz0]['vecs'][m0]
        for kz in skzs:
            es = bands[kz]['ens']
            vs = bands[kz]['vecs']
            chrgs = bands[kz]['charges']

            # get all wave functions and check their overlap with v0
            overlap = [ np.abs( np.vdot(v0,vs[m]) ) for m in xrange(len(vs)) ]
            n_best = np.argmax( overlap )
            traced_mode[kz]={}
            traced_mode[kz]['en']=es[n_best]
            traced_mode[kz]['charge']=chrgs[n_best]
            v0=vs[n_best]

            # remove this data point from work_bands to avoid double tracing
            del bands[kz]['ens'][n_best]
            del bands[kz]['vecs'][n_best]
            del bands[kz]['charges'][n_best]
        traced_modes.append(traced_mode)
    return traced_modes



""" 3. DATA STORAGE """

""" 3.1 make a simple namespace with parameters of system """
def make_p( **kwargs ):
    p = SimpleNamespace()
    p.__dict__.update(kwargs)
    return p

""" 3.2 make a simple namespace with parameters of system """
def make_p_HACK( **kwargs ):
    p = SimpleNamespace()
    p.__dict__.update(kwargs)
    if hasattr( p,"filling" ) and hasattr( p,"t_M" ) and hasattr( p,"ai" ):
        p.met_mu=2*p.ai*p.t_M*p.filling
        p.met_tx=p.ai*p.t_M
        p.met_ty=p.ai*p.t_M
        p.met_tz=p.t_M
    return p



""" 4. VISUALIZATION """

""" 4.1 function that plots the lattice with onsite-energies and hoppings """
def plot_system(sys,fsys,p,L=6,H=4):
    mysites = fsys.sites
        
    def onsite(s1):
        i=0; ni=0
        for s in mysites:
            if s==s1:
                i=ni
            ni+=1

        a= fsys.hamiltonian_submatrix( args=([p]),to_sites=[i],from_sites=[i] )
        el = np.real(a[0][1]+a[1][1])
        return 6*np.log(el)

    def hop(s1,s2):
        i=0; j=0; ni=0
        for s in mysites:
            if s==s1:
                i=ni
            if s==s2:
                j=ni
            ni+=1

        pdiff = s2.pos-s1.pos
        if np.all( [diff>=0 for diff in pdiff] ):
            a= fsys.hamiltonian_submatrix( args=([p]),to_sites=[i],from_sites=[j] )
        else:
            a= fsys.hamiltonian_submatrix( args=([p]),to_sites=[j],from_sites=[i] )

        if len(a)==2:
            v = (1,0)
        elif len(a)==4:
            v = (1,0,1,1)
        v2 = np.dot(a,v)
        q  = np.vdot(v,v2)
    
        return abs(q)#np.cos(np.angle(q))

    def hop_lw(s1,s2):
        if s1.family.name=='e' and s2.family.name=='e':
            i=0; j=0; ni=0
            for s in mysites:
                if s==s1:
                    i=ni
                if s==s2:
                    j=ni
                ni+=1

            pdiff = s2.pos-s1.pos
            if np.all( [diff>=0 for diff in pdiff] ):
                a= fsys.hamiltonian_submatrix( args=([p]),to_sites=[i],from_sites=[j] )
            else:
                a= fsys.hamiltonian_submatrix( args=([p]),to_sites=[j],from_sites=[i] )

            if len(a)==2:
                v = (1,0)
            elif len(a)==4:
                v = (1,0,1,1)
            v2 = np.dot(a,v)
            q  = np.vdot(v,v2)

            return .2*np.cos(np.angle(q))
        else:
            return 0

    fig, (ax11) = plt.subplots(1,1,figsize=(L,H) )
    kwant.plotter.plot( sys,site_size=onsite,hop_color=hop,hop_lw=hop_lw, ax=ax11)


