# libraries
from __future__ import division

from tinyarray import array as ta

import numpy as np
from numpy import pi
from scipy import sparse as sp
from scipy.sparse import linalg as lag

import matplotlib.cm as cm; import matplotlib.pyplot as plt;

import kwant

# my libraries (use the NEW library!)
import use_lib_v2; use_lib_v2.init()

import weyl_sc_pdotsigma as weyl_pdotsigma_4band
import weyl_sc_maxim as weyl_maxim_4band
import weyl_sc_jakub_2band as weyl_jakub_2band
import weyl_sc_maxim_2band as weyl_maxim_2band
import sc_4band
import sc_2band

from memory import SimpleNamespace
from memory import get_var
#from paulimatrices import *


"""
TABLE OF CONTENTS

1.   BUILDERS
1.1  effective 1D
1.1a finite N-S
1.1b infinite N-S
1.1c finite S-N-S
1.1d WSM lead
1.2  effective 2D
1.2a infinite N-S
1.2b coated cylindical wire

2.  SPECTRA AND WAVE FUNCTIONS
2.1 low energy spectrum as function of kz
2.2 low energy spectrum for finite effective 1D N-s junction. surface,bulk separation, electron-hole polarization
2.3 surface states only
2.4 check if state is localized at certain sites
2.5 get the electron-hole polarization of a wave function

3.  TRANSPORT
3.1 get_s_matrix
3.2 get_resolved_probs
3.3 get_reflection_probs
3.4 split_lead
3.5 supercurrent

4.  DATA STORAGE
4.1 make a simple namespace with parameters of system

5.  VISUALIZATION
5.1 function that plots the lattice with onsite-energies and hoppings

6. DISCARDED FUNCTIONS
"""


"""COMMENTS """
"""Will choose the following conventions: Transport will always be in
x-direction; in y-direction we have hardwall or periodic boundary
conditions and potentially a magnetic field; the Weyl cones are always
separated in z-direction.

"""



""" 1. Builders: The Builders we will need are on a lattice in x- or xy- direction """


""" 1.1a finite 1D SC-WSM-SC junction with smooth interface

if len_int=0 the hopping connecting the two systems is a superconducting hopping 

"""

def make_finite_1D_sns_junction( wx_sc_left,wx_wsm,wx_sc_right, \
                                 model, \
                                 len_int=0,\
                                 plot_sys=False,p=None ):

    
    # ky_shift
    # we need to determine Ay at the ends of the Weyl semimetal
    Ay_left  = - float(wx_sc_left-p.x_shift)*float(p.lBinv2)
    Ay_right = - float(wx_sc_left+wx_wsm-1-p.x_shift)*float(p.lBinv2)

    #print wx_sc_left-p.x_shift,wx_sc_left+wx_wsm-1-p.x_shift
    #print np.mod(Ay_left,2*pi), np.mod(Ay_right,2*pi)
    
    if model=='pdotsigma_4band':
        model_wsm = weyl_pdotsigma_4band.WeylSC1D_x()
        model_msc_L = sc_4band.MetallicSC1D_x( params=SimpleNamespace( ky_shift=Ay_left ) )
        model_msc_R = sc_4band.MetallicSC1D_x( params=SimpleNamespace( ky_shift=Ay_right ) )
    elif model=='maxim_4band':
        model_wsm = weyl_maxim_4band.WeylSC1D_x()
        model_msc_L = sc_4band.MetallicSC1D_x( params=SimpleNamespace( ky_shift=Ay_left ) )
        model_msc_R = sc_4band.MetallicSC1D_x( params=SimpleNamespace( ky_shift=Ay_right ) )
    elif model=='maxim_2band':
        model_wsm = weyl_maxim_2band.Twoband_1D()
        model_msc_L = sc_2band.MetallicSC1D_x()
        model_msc_R = sc_2band.MetallicSC1D_x()
    elif model=='jakub_2band':
        model_wsm = weyl_jakub_2band.Twoband_1D()
        model_msc_L = sc_2band.MetallicSC1D_x()
        model_msc_R = sc_2band.MetallicSC1D_x()
    else:
        raise ValueError( model + ", is not implemented. Possible models are pdotsigma_4band")

    # slider for onsite
    def slider_onsite(site,p):
        len_sc_left =p.alpha*(wx_sc_left-.5)
        len_wsm     =p.alpha*(wx_wsm)
        len_sc_right=p.alpha*(wx_sc_right-.5)
        len_int_half=len_int/2.

        nx,=site.pos
        x=nx*p.alpha

        left_site=True
        if x<=len_sc_left-len_int_half:
            beta=0.
        elif x<len_sc_left+len_int_half:
            beta = (x-len_sc_left+len_int_half)/len_int
        elif x<len_sc_left+len_wsm-len_int_half:
            beta = 1.
        elif x<len_sc_left+len_wsm+len_int_half:
            left_site=False
            beta = 1.- (x-len_sc_left-len_wsm+len_int_half)/len_int
        else:
            left_site=False
            beta=0

        return left_site,beta

    # slider for hoppings
    def slider_hop(site1,site2,p):
        len_sc_left =p.alpha*(wx_sc_left-.5)
        len_wsm     =p.alpha*(wx_wsm)
        len_sc_right=p.alpha*(wx_sc_right-.5)
        len_int_half=len_int/2.

        nx1,=site1.pos
        nx2,=site2.pos
        x=(nx1+nx2)*p.alpha/2.

        left_site=True
        if x<=len_sc_left-len_int_half:
            beta=0.
        elif x<len_sc_left+len_int_half:
            if len_int>10**(-6):
                beta = (x-len_sc_left+len_int_half)/len_int
            else:
                beta=0
        elif x<len_sc_left+len_wsm-len_int_half:
            beta = 1.
        elif x<len_sc_left+len_wsm+len_int_half:
            left_site=False
            if len_int>10**(-6):
                beta = 1.- (x-len_sc_left-len_wsm+len_int_half)/len_int
            else:
                beta = 0
        else:
            left_site=False
            beta=0
                                    
        return left_site,beta
        
    def onsite_e(site,p):
        left,beta=slider_onsite(site,p)
        if left:
            return (1-beta)*model_msc_L.onsite_e(site,p) + beta*model_wsm.onsite_e(site,p)
        else:
            return (1-beta)*model_msc_R.onsite_e(site,p) + beta*model_wsm.onsite_e(site,p)
    def onsite_h(site,p):
        left,beta=slider_onsite(site,p)
        if left:
            return (1-beta)*model_msc_L.onsite_h(site,p) + beta*model_wsm.onsite_h(site,p)
        else:
            return (1-beta)*model_msc_R.onsite_h(site,p) + beta*model_wsm.onsite_h(site,p)

    def hop_e(site1,site2,p):
        left,beta=slider_hop(site1,site2,p)
        if left:
            return (1-beta)*model_msc_L.hop_e(site1,site2,p) + beta*model_wsm.hop_e(site1,site2,p)
        else:
            return (1-beta)*model_msc_R.hop_e(site1,site2,p) + beta*model_wsm.hop_e(site1,site2,p)
    def hop_h(site1,site2,p):
        left,beta=slider_hop(site1,site2,p)
        if left:
            return (1-beta)*model_msc_L.hop_h(site1,site2,p) + beta*model_wsm.hop_h(site1,site2,p)
        else:
            return (1-beta)*model_msc_R.hop_h(site1,site2,p) + beta*model_wsm.hop_h(site1,site2,p)

    def pairing(site1,site2,p):
        left,beta=slider_hop(site1,site2,p)
        if left:
            return (1-beta)*model_msc_L.pairing(site1,site2,p)
        else:
            return (1-beta)*model_msc_R.pairing(site1,site2,p)
        
    # lattices
    lat_e = model_wsm.lat_e
    lat_h = model_wsm.lat_h

    # builder
    sys = kwant.Builder()

    # first, define all sites and their onsite energies
    x1=wx_sc_left; x2=x1+wx_wsm; x3=x2+wx_sc_right

    for nx in range(x3):
        sys[lat_e(nx,)]=onsite_e
        sys[lat_h(nx,)]=onsite_h
        sys[lat_h(nx,),lat_e(nx,)]=pairing

    # second, set the hoppings
    # a) sc left
    for nx in range(x3-1):
        sys[lat_e(nx+1,),lat_e(nx,)]=hop_e
        sys[lat_h(nx+1,),lat_h(nx,)]=hop_h


    # finalize the system
    fsys = sys.finalized()

    # plot lattice and hoppings if desired
    if plot_sys:
        plot_system(sys,fsys,p,12,1)        
    
    return fsys


def make_finite_1D_sns_junction__TB( wx_sc_left,wx_wsm,wx_sc_right, wx_tb_l, wx_tb_r, \
                                     model, \
                                     plot_sys=False,p=None ):

    if model=='pdotsigma_4band':
        model_wsm = weyl_pdotsigma_4band.WeylSC1D_x()
        model_wsm_tb = weyl_pdotsigma_4band.WeylSC1D_x( params=SimpleNamespace( mu_W=p.mu_TB ) )
        model_msc_L = sc_4band.MetallicSC1D_x( params=SimpleNamespace() )
        model_msc_R = sc_4band.MetallicSC1D_x( params=SimpleNamespace() )
    else:
        raise ValueError( model + ", is not implemented. Possible models are pdotsigma_4band" )

    # lattices
    lat_e = model_wsm.lat_e
    lat_h = model_wsm.lat_h

    # builder
    sys = kwant.Builder()

    # first, define all sites and their onsite energies
    x1=wx_sc_left; x2=x1+wx_tb_l; x3=x2+wx_wsm; x4=x3+wx_tb_r; x5=x4+wx_sc_right

    # a) SC (left)
    for nx in range(x1):
        sys[lat_e(nx,)]=model_msc_L.onsite_e
        sys[lat_h(nx,)]=model_msc_L.onsite_h
        sys[lat_h(nx,),lat_e(nx,)]=model_msc_L.pairing

    # b) WSM-TB (left)
    for nx in range(x1,x2):
        sys[lat_e(nx,)]=model_wsm_tb.onsite_e
        sys[lat_h(nx,)]=model_wsm_tb.onsite_h        
        
    # c) WSM (left)
    for nx in range(x2,x3):
        sys[lat_e(nx,)]=model_wsm.onsite_e
        sys[lat_h(nx,)]=model_wsm.onsite_h

    # b) WSM-TB (right)
    for nx in range(x3,x4):
        sys[lat_e(nx,)]=model_wsm_tb.onsite_e
        sys[lat_h(nx,)]=model_wsm_tb.onsite_h 
        
    # e) SC (right)
    for nx in range(x4,x5):
        sys[lat_e(nx,)]=model_msc_R.onsite_e
        sys[lat_h(nx,)]=model_msc_R.onsite_h
        sys[lat_h(nx,),lat_e(nx,)]=model_msc_R.pairing
        
    # second, set the hoppings
    # a) sc left
    for nx in range(x1):
        if nx<x4-1:
            sys[lat_e(nx+1,),lat_e(nx,)]=model_msc_L.hop_e
            sys[lat_h(nx+1,),lat_h(nx,)]=model_msc_L.hop_h

    # c) WSM
    for nx in range(x1,x4-1):
        if nx<x5-1:
            sys[lat_e(nx+1,),lat_e(nx,)]=model_wsm.hop_e
            sys[lat_h(nx+1,),lat_h(nx,)]=model_wsm.hop_h

    # e) sc right
    for nx in range(x4-1,x5-1):
        sys[lat_e(nx+1,),lat_e(nx,)]=model_msc_R.hop_e
        sys[lat_h(nx+1,),lat_h(nx,)]=model_msc_R.hop_h

    # finalize the system
    fsys = sys.finalized()

    # plot lattice and hoppings if desired
    if plot_sys:
        plot_system(sys,fsys,p,12,1)        
    
    return fsys


def make_finite_1D_sns_junction__SC_TB( wx_sc_left,wx_wsm,wx_sc_right, wx_tb_l, wx_tb_r, \
                                     model, \
                                     plot_sys=False,p=None ):

    if model=='pdotsigma_4band':
        model_wsm = weyl_pdotsigma_4band.WeylSC1D_x()
        model_wsm_tb = weyl_pdotsigma_4band.WeylSC1D_x( params=SimpleNamespace( mu_W=p.mu_TB, Delta_W=p.Delta_TB ) )
        model_msc_L = sc_4band.MetallicSC1D_x( params=SimpleNamespace() )
        model_msc_R = sc_4band.MetallicSC1D_x( params=SimpleNamespace() )
    else:
        raise ValueError( model + ", is not implemented. Possible models are pdotsigma_4band" )

    # lattices
    lat_e = model_wsm.lat_e
    lat_h = model_wsm.lat_h

    # builder
    sys = kwant.Builder()

    # first, define all sites and their onsite energies
    x1=wx_sc_left; x2=x1+wx_tb_l; x3=x2+wx_wsm; x4=x3+wx_tb_r; x5=x4+wx_sc_right

    # a) SC (left)
    for nx in range(x1):
        sys[lat_e(nx,)]=model_msc_L.onsite_e
        sys[lat_h(nx,)]=model_msc_L.onsite_h
        sys[lat_h(nx,),lat_e(nx,)]=model_msc_L.pairing

    # b) WSM-TB (left)
    for nx in range(x1,x2):
        sys[lat_e(nx,)]=model_wsm_tb.onsite_e
        sys[lat_h(nx,)]=model_wsm_tb.onsite_h
        sys[lat_h(nx,),lat_e(nx,)]=model_wsm_tb.pairing
        
    # c) WSM 
    for nx in range(x2,x3):
        sys[lat_e(nx,)]=model_wsm.onsite_e
        sys[lat_h(nx,)]=model_wsm.onsite_h

    # b) WSM-TB (right)
    for nx in range(x3,x4):
        sys[lat_e(nx,)]=model_wsm_tb.onsite_e
        sys[lat_h(nx,)]=model_wsm_tb.onsite_h
        sys[lat_h(nx,),lat_e(nx,)]=model_wsm_tb.pairing
        
    # e) SC (right)
    for nx in range(x4,x5):
        sys[lat_e(nx,)]=model_msc_R.onsite_e
        sys[lat_h(nx,)]=model_msc_R.onsite_h
        sys[lat_h(nx,),lat_e(nx,)]=model_msc_R.pairing
        
    # second, set the hoppings
    # a) sc left
    for nx in range(x1):
        if nx<x4-1:
            sys[lat_e(nx+1,),lat_e(nx,)]=model_msc_L.hop_e
            sys[lat_h(nx+1,),lat_h(nx,)]=model_msc_L.hop_h

    # c) WSM
    for nx in range(x1,x4-1):
        if nx<x5-1:
            sys[lat_e(nx+1,),lat_e(nx,)]=model_wsm.hop_e
            sys[lat_h(nx+1,),lat_h(nx,)]=model_wsm.hop_h

    # e) sc right
    for nx in range(x4-1,x5-1):
        sys[lat_e(nx+1,),lat_e(nx,)]=model_msc_R.hop_e
        sys[lat_h(nx+1,),lat_h(nx,)]=model_msc_R.hop_h

    # finalize the system
    fsys = sys.finalized()

    # plot lattice and hoppings if desired
    if plot_sys:
        plot_system(sys,fsys,p,12,1)        
    
    return fsys





def make_finite_2D_sns_junction__xy( wx_sc_left,wx_wsm,wx_sc_right,wy,model,pbc_y,\
                                     berry_phase=True,plot_sys=False,p=None ):

    # ky_shift
    # we need to determine Ay at the ends of the Weyl semimetal
    Ay_left  = - float(wx_sc_left-p.x_shift)*float(p.lBinv2)
    Ay_right = - float(wx_sc_left+wx_wsm-1-p.x_shift)*float(p.lBinv2)

    
    if model=='pdotsigma_4band':
        model_wsm = weyl_pdotsigma_4band.WeylSC2D_xy()
        model_msc_L = sc_4band.MetallicSC2D_xy( params=SimpleNamespace( ky_shift=Ay_left ) )
        model_msc_R = sc_4band.MetallicSC2D_xy( params=SimpleNamespace( ky_shift=Ay_right ) )
    elif model=='maxim_4band':
        model_wsm = weyl_maxim_4band.WeylSC2D_xy()
        model_msc_L = sc_4band.MetallicSC2D_xy( params=SimpleNamespace( ky_shift=Ay_left ) )
        model_msc_R = sc_4band.MetallicSC2D_xy( params=SimpleNamespace( ky_shift=Ay_right ) )
    elif model=='maxim_2band':
        model_wsm = weyl_maxim_2band.Twoband_2D_xy()
        model_msc_L = sc_2band.MetallicSC2D_xy()
        model_msc_R = sc_2band.MetallicSC2D_xy()
    elif model=='jakub_2band':
        model_wsm = weyl_jakub_2band.Twoband_2D_xy()
        model_msc_L = sc_2band.MetallicSC2D_xy()
        model_msc_R = sc_2band.MetallicSC2D_xy()
    else:
        raise ValueError( model + ", is not implemented. Possible models are pdotsigma_4band")

        
    # lattices
    lat_e = model_wsm.lat_e
    lat_h = model_wsm.lat_h

    # builder
    sys = kwant.Builder()

    # first, define all sites and their onsite energies
    x1=wx_sc_left; x2=x1+wx_wsm; x3=x2+wx_sc_right

    # a) SC (left)
    for nx in range(x1):
        for ny in range(wy):
            sys[lat_e(nx,ny)]=model_msc_L.onsite_e
            sys[lat_h(nx,ny)]=model_msc_L.onsite_h
            sys[lat_h(nx,ny),lat_e(nx,ny)]=model_msc_L.pairing

    # b) WSM (left)
    for nx in range(x1,x2):
        for ny in range(wy):
            sys[lat_e(nx,ny)]=model_wsm.onsite_e
            sys[lat_h(nx,ny)]=model_wsm.onsite_h
        
    # c) SC (right)
    for nx in range(x2,x3):
        for ny in range(wy):
            sys[lat_e(nx,ny)]=model_msc_R.onsite_e
            sys[lat_h(nx,ny)]=model_msc_R.onsite_h
            sys[lat_h(nx,ny),lat_e(nx,ny)]=model_msc_R.pairing
        
    # second, set the hoppings in x-direction
    # a) sc left
    for nx in range(x1):
        for ny in range(wy):
            sys[lat_e(nx+1,ny),lat_e(nx,ny)]=model_msc_L.hop_e
            sys[lat_h(nx+1,ny),lat_h(nx,ny)]=model_msc_L.hop_h
        
    # b) WSM
    for nx in range(x1,x2-1):
        for ny in range(wy):
            sys[lat_e(nx+1,ny),lat_e(nx,ny)]=model_wsm.hop_e
            sys[lat_h(nx+1,ny),lat_h(nx,ny)]=model_wsm.hop_h
    
    # c) sc hoppings
    for nx in range(x2-1,x3-1):
        for ny in range(wy):
            sys[lat_e(nx+1,ny),lat_e(nx,ny)]=model_msc_R.hop_e
            sys[lat_h(nx+1,ny),lat_h(nx,ny)]=model_msc_R.hop_h

    # second, set the hoppings in y-direction
    # a) sc left
    for nx in range(x1):
        for ny in range(wy-1):
            sys[lat_e(nx,ny+1),lat_e(nx,ny)]=model_msc_L.hop_e
            sys[lat_h(nx,ny+1),lat_h(nx,ny)]=model_msc_L.hop_h
        if pbc_y:
            if berry_phase:
                sys[lat_e(nx,0),lat_e(nx,wy-1)]=model_msc_L.hop_h
                sys[lat_h(nx,0),lat_h(nx,wy-1)]=model_msc_L.hop_e
            else:
                sys[lat_e(nx,0),lat_e(nx,wy-1)]=model_msc_L.hop_e
                sys[lat_h(nx,0),lat_h(nx,wy-1)]=model_msc_L.hop_h
        
    # b) WSM
    for nx in range(x1,x2):
        for ny in range(wy-1):
            sys[lat_e(nx,ny+1),lat_e(nx,ny)]=model_wsm.hop_e
            sys[lat_h(nx,ny+1),lat_h(nx,ny)]=model_wsm.hop_h
        if pbc_y:
            if berry_phase:
                sys[lat_e(nx,0),lat_e(nx,wy-1)]=model_wsm.hop_h
                sys[lat_h(nx,0),lat_h(nx,wy-1)]=model_wsm.hop_e
            else:
                sys[lat_e(nx,0),lat_e(nx,wy-1)]=model_wsm.hop_e
                sys[lat_h(nx,0),lat_h(nx,wy-1)]=model_wsm.hop_h
    
    # c) sc hoppings
    for nx in range(x2,x3):
        for ny in range(wy-1):
            sys[lat_e(nx,ny+1),lat_e(nx,ny)]=model_msc_R.hop_e
            sys[lat_h(nx,ny+1),lat_h(nx,ny)]=model_msc_R.hop_h
        if pbc_y:
            if berry_phase:
                sys[lat_e(nx,0),lat_e(nx,wy-1)]=model_msc_R.hop_h
                sys[lat_h(nx,0),lat_h(nx,wy-1)]=model_msc_R.hop_e
            else:
                sys[lat_e(nx,0),lat_e(nx,wy-1)]=model_msc_R.hop_e
                sys[lat_h(nx,0),lat_h(nx,wy-1)]=model_msc_R.hop_h
                
            

    # finalize the system
    fsys = sys.finalized()

    # plot lattice and hoppings if desired
    if plot_sys:
        plot_system(sys,fsys,p,12,10)        
    
    return fsys

def make_finite_2D_sns_junction__xz( wx_sc_left,wx_wsm,wx_sc_right,wz,plot_sys=False,p=None ):

    # get models
    model_wsm   = weyl_4band.WeylSC2D_xz()
    model_msc_L = sc_4band.MetallicSC2D_xz()
    model_msc_R = sc_4band.MetallicSC2D_xz()

    # lattices
    lat_e = model_wsm.lat_e
    lat_h = model_wsm.lat_h

    # builder
    sys = kwant.Builder()

    # first, define all sites and their onsite energies
    x1=wx_sc_left; x2=x1+wx_wsm; x3=x2+wx_sc_right

    # a) SC (left)
    for nx in range(x1):
        for nz in range(wz):
            sys[lat_e(nx,nz)]=model_msc_L.onsite_e
            sys[lat_h(nx,nz)]=model_msc_L.onsite_h
            sys[lat_h(nx,nz),lat_e(nx,nz)]=model_msc_L.pairing

    # b) WSM (left)
    for nx in range(x1,x2):
        for nz in range(wz):
            sys[lat_e(nx,nz)]=model_wsm.onsite_e
            sys[lat_h(nx,nz)]=model_wsm.onsite_h
        
    # c) SC (right)
    for nx in range(x2,x3):
        for nz in range(wz):
            sys[lat_e(nx,nz)]=model_msc_R.onsite_e
            sys[lat_h(nx,nz)]=model_msc_R.onsite_h
            sys[lat_h(nx,nz),lat_e(nx,nz)]=model_msc_R.pairing
        
    # second, set the hoppings in x-direction
    # a) sc left
    for nx in range(x1):
        for nz in range(wz):
            sys[lat_e(nx+1,nz),lat_e(nx,nz)]=model_msc_L.hop_e
            sys[lat_h(nx+1,nz),lat_h(nx,nz)]=model_msc_L.hop_h
        
    # b) WSM
    for nx in range(x1,x2-1):
        for nz in range(wz):
            sys[lat_e(nx+1,nz),lat_e(nx,nz)]=model_wsm.hop_e
            sys[lat_h(nx+1,nz),lat_h(nx,nz)]=model_wsm.hop_h
    
    # c) barrier and sc hoppings
    for nx in range(x2-1,x3-1):
        for nz in range(wz):
            sys[lat_e(nx+1,nz),lat_e(nx,nz)]=model_msc_R.hop_e
            sys[lat_h(nx+1,nz),lat_h(nx,nz)]=model_msc_R.hop_h

    # second, set the hoppings
    # a) sc left
    for nx in range(x1):
        for nz in range(wz-1):
            sys[lat_e(nx,nz+1),lat_e(nx,nz)]=sc_hop_z_e#model_msc_L.hop_e
            sys[lat_h(nx,nz+1),lat_h(nx,nz)]=sc_hop_z_h#model_msc_L.hop_h
        
    # b) WSM
    for nx in range(x1,x2):
        for nz in range(wz-1):
            sys[lat_e(nx,nz+1),lat_e(nx,nz)]=model_wsm.hop_e
            sys[lat_h(nx,nz+1),lat_h(nx,nz)]=model_wsm.hop_h
    
    # c) barrier and sc hoppings
    for nx in range(x2,x3):
        for nz in range(wz-1):
            sys[lat_e(nx,nz+1),lat_e(nx,nz)]=sc_hop_z_e#model_msc_R.hop_e
            sys[lat_h(nx,nz+1),lat_h(nx,nz)]=sc_hop_z_h#model_msc_R.hop_h
            

    # finalize the system
    fsys = sys.finalized()

    # plot lattice and hoppings if desired
    if plot_sys:
        plot_system(sys,fsys,p,12,5)        
    
    return fsys


def make_finite_2D_sns_junction__xz__domainwalls( wx_sc_left,wx_wsm,wx_sc_right,\
                                                  wx_tb_l,wx_tb_r,\
                                                  wz_B,wz_M,wz_T, pbc_z=True,\
                                                  plot_sys=False,p=None ):

    
    # get models
    model_wsm   = weyl_pdotsigma_4band.WeylSC2D_xz()
    model_msc_L = sc_4band.MetallicSC2D_xz()
    model_msc_R = sc_4band.MetallicSC2D_xz()

    # tunnel barrier
    model_tb_low  = weyl_pdotsigma_4band.WeylSC2D_xz( params=SimpleNamespace( mu_W=p.mu_TB_min ) )
    model_tb_high = weyl_pdotsigma_4band.WeylSC2D_xz( params=SimpleNamespace( mu_W=p.mu_TB_max ) )
    model_tb_dw_l = []
    mu_dw_l = np.linspace( p.mu_TB_min,p.mu_TB_max,wz_M+2 )
    for n in range(1,wz_M+1):
        model_tb_dw_l.append( weyl_pdotsigma_4band.WeylSC2D_xz( params=SimpleNamespace( mu_W=mu_dw_l[n] ) ) )

    # lattices
    lat_e = model_wsm.lat_e
    lat_h = model_wsm.lat_h

    # builder
    sys = kwant.Builder()

    # first, define all sites and their onsite energies
    x1=wx_sc_left; x2=x1+wx_tb_l; x3=x2+wx_wsm; x4=x3+wx_tb_r; x5=x4+wx_sc_right
    z1=wz_B; z2=z1+wz_M; z3=z2+wz_T; z4=z3+wz_M;

    # a) SC (left)
    for nx in range(x1):
        for nz in range(z4):
            sys[lat_e(nx,nz)]=model_msc_L.onsite_e
            sys[lat_h(nx,nz)]=model_msc_L.onsite_h
            sys[lat_h(nx,nz),lat_e(nx,nz)]=model_msc_L.pairing

    # b) TB (left)
    for nx in range(x1,x2):
        for nz in range(z1):
            model=model_tb_low
            sys[lat_e(nx,nz)]=model.onsite_e
            sys[lat_h(nx,nz)]=model.onsite_h
        for nz in range(z1,z2):
            n=nz-z1
            model=model_tb_dw_l[n]
            sys[lat_e(nx,nz)]=model.onsite_e
            sys[lat_h(nx,nz)]=model.onsite_h
        for nz in range(z2,z3):
            model=model_tb_high
            sys[lat_e(nx,nz)]=model.onsite_e
            sys[lat_h(nx,nz)]=model.onsite_h
        for nz in range(z3,z4):
            n=nz-z3
            model=model_tb_dw_l[-n-1]
            sys[lat_e(nx,nz)]=model.onsite_e
            sys[lat_h(nx,nz)]=model.onsite_h

    # c) WSM (middle)
    for nx in range(x2,x3):
        for nz in range(z4):
            sys[lat_e(nx,nz)]=model_wsm.onsite_e
            sys[lat_h(nx,nz)]=model_wsm.onsite_h

    # d) TB (right)
    for nx in range(x3,x4):
        for nz in range(z1):
            model=model_tb_low
            sys[lat_e(nx,nz)]=model.onsite_e
            sys[lat_h(nx,nz)]=model.onsite_h
        for nz in range(z1,z2):
            #print nz
            n=nz-z1
            model=model_tb_dw_l[n]
            sys[lat_e(nx,nz)]=model.onsite_e
            sys[lat_h(nx,nz)]=model.onsite_h
            
        for nz in range(z2,z3):
            model=model_tb_high
            sys[lat_e(nx,nz)]=model.onsite_e
            sys[lat_h(nx,nz)]=model.onsite_h
        for nz in range(z3,z4):
            #print nz
            n=nz-z3
            model=model_tb_dw_l[-n-1]
            sys[lat_e(nx,nz)]=model.onsite_e
            sys[lat_h(nx,nz)]=model.onsite_h
            
    # e) SC (right)
    for nx in range(x4,x5):
        for nz in range(z4):
            sys[lat_e(nx,nz)]=model_msc_R.onsite_e
            sys[lat_h(nx,nz)]=model_msc_R.onsite_h
            sys[lat_h(nx,nz),lat_e(nx,nz)]=model_msc_R.pairing
            
        
    # second, set the hoppings in x-direction
    # a) sc left
    for nx in range(x1):
        for nz in range(z4):
            if nx<x4-1:
                sys[lat_e(nx+1,nz),lat_e(nx,nz)]=model_msc_L.hop_e
                sys[lat_h(nx+1,nz),lat_h(nx,nz)]=model_msc_L.hop_h
        
    # b) WSM and TB
    for nx in range(x1,x4-1):
        for nz in range(z4):
            sys[lat_e(nx+1,nz),lat_e(nx,nz)]=model_wsm.hop_e
            sys[lat_h(nx+1,nz),lat_h(nx,nz)]=model_wsm.hop_h
    
    # c) sc hoppings
    for nx in range(x4-1,x5-1):
        for nz in range(z4):
            sys[lat_e(nx+1,nz),lat_e(nx,nz)]=model_msc_R.hop_e
            sys[lat_h(nx+1,nz),lat_h(nx,nz)]=model_msc_R.hop_h

    # third, set the hoppings in z-direction
    # a) sc left
    for nx in range(x1):
        for nz in range(z4-1):
            sys[lat_e(nx,nz+1),lat_e(nx,nz)]=model_msc_L.hop_e
            sys[lat_h(nx,nz+1),lat_h(nx,nz)]=model_msc_L.hop_h
        if pbc_z:
            sys[lat_e(nx,0),lat_e(nx,z4-1)]=model_msc_L.hop_e
            sys[lat_h(nx,0),lat_h(nx,z4-1)]=model_msc_L.hop_h
        
    # b) WSM
    for nx in range(x1,x4):
        for nz in range(z4-1):
            sys[lat_e(nx,nz+1),lat_e(nx,nz)]=model_wsm.hop_e
            sys[lat_h(nx,nz+1),lat_h(nx,nz)]=model_wsm.hop_h
        if pbc_z:
            sys[lat_e(nx,0),lat_e(nx,z4-1)]=model_wsm.hop_e
            sys[lat_h(nx,0),lat_h(nx,z4-1)]=model_wsm.hop_h
                
    # c) barrier and sc hoppings
    for nx in range(x4,x5):
        for nz in range(z4-1):
            sys[lat_e(nx,nz+1),lat_e(nx,nz)]=model_msc_R.hop_e
            sys[lat_h(nx,nz+1),lat_h(nx,nz)]=model_msc_R.hop_h
        if pbc_z:
            sys[lat_e(nx,0),lat_e(nx,z4-1)]=model_msc_R.hop_e
            sys[lat_h(nx,0),lat_h(nx,z4-1)]=model_msc_R.hop_h

    # finalize the system
    fsys = sys.finalized()

    # plot lattice and hoppings if desired
    if plot_sys:
        plot_system(sys,fsys,p,12,10)        
    
    return fsys


""" 1.2b SC coated WSM wire """
def make_coated_wire_xy(R1,R2,plot_sys=False,p=None):

    # shape
    margin=10**(-3)
    def disk( x,y,R ):
        if x**2+y**2<R**2-margin:
            return True
        else:
            return False
        
    # get model
    model_wsm = weyl_4band.WeylSC2D_xy()
    model_sc  = sc_4band.MetallicSC2D_xy()

    # lattices
    lat_e = model_wsm.lat_e
    lat_h = model_wsm.lat_h

    # builder
    sys = kwant.Builder()

    # onsite energies
    for nx in range(-R2,R2+1):
        for ny in range(-R2,R2+1):
            if disk(nx,ny,R1):
                sys[lat_e(nx,ny)]=model_wsm.onsite_e
                sys[lat_h(nx,ny)]=model_wsm.onsite_h
            elif disk(nx,ny,R2):
                sys[lat_e(nx,ny)]=model_sc.onsite_e
                sys[lat_h(nx,ny)]=model_sc.onsite_h
                sys[lat_h(nx,ny),lat_e(nx,ny)]=model_sc.pairing

    # hoppings
    for nx in range(-R2,R2+1):
        for ny in range(-R2,R2+1):
            if disk(nx,ny,R1):
                if disk(nx+1,ny,R1):
                    sys[lat_e(nx+1,ny),lat_e(nx,ny)]=model_wsm.hop_e
                    sys[lat_h(nx+1,ny),lat_h(nx,ny)]=model_wsm.hop_h
                if disk(nx,ny+1,R1):
                    sys[lat_e(nx,ny+1),lat_e(nx,ny)]=model_wsm.hop_e
                    sys[lat_h(nx,ny+1),lat_h(nx,ny)]=model_wsm.hop_h
                if disk(nx+1,ny,R2) and not disk(nx+1,ny,R1):
                    sys[lat_e(nx+1,ny),lat_e(nx,ny)]=model_sc.hop_e
                    sys[lat_h(nx+1,ny),lat_h(nx,ny)]=model_sc.hop_h
                if disk(nx,ny+1,R2) and not disk(nx,ny+1,R1):
                    sys[lat_e(nx,ny+1),lat_e(nx,ny)]=model_sc.hop_e
                    sys[lat_h(nx,ny+1),lat_h(nx,ny)]=model_sc.hop_h
            
            elif disk(nx,ny,R2):
                if disk(nx+1,ny,R2):
                    sys[lat_e(nx+1,ny),lat_e(nx,ny)]=model_sc.hop_e
                    sys[lat_h(nx+1,ny),lat_h(nx,ny)]=model_sc.hop_h
                if disk(nx,ny+1,R2):
                    sys[lat_e(nx,ny+1),lat_e(nx,ny)]=model_sc.hop_e
                    sys[lat_h(nx,ny+1),lat_h(nx,ny)]=model_sc.hop_h

    fsys = sys.finalized()
                    
    if plot_sys:
        plot_system(sys,fsys,p,8,8)

    return fsys


""" 1.2b SC coated WSM square wire """
def make_coated_square_wire_xy(R1,R2,Rtb,plot_sys=False,p=None):


    model_wsm    = weyl_pdotsigma_4band.WeylSC2D_xy()
    model_wsm_tb = weyl_pdotsigma_4band.WeylSC2D_xy( params=SimpleNamespace( mu_W=p.mu_TB ) )
    model_sc     = sc_4band.MetallicSC2D_xy()
             
    # shape
    margin=10**(-3)
    def square( x,y,W ):
        if x**2<W**2-margin and y**2<W**2-margin:
            return True
        else:
            return False
        
    # lattices
    lat_e = model_wsm.lat_e
    lat_h = model_wsm.lat_h

    # builder
    sys = kwant.Builder()

    # onsite energies
    for nx in range(-R2,R2+1):
        for ny in range(-R2,R2+1):
            if square(nx,ny,R1-Rtb):
                sys[lat_e(nx,ny)]=model_wsm.onsite_e
                sys[lat_h(nx,ny)]=model_wsm.onsite_h
            elif square(nx,ny,R1):
                sys[lat_e(nx,ny)]=model_wsm_tb.onsite_e
                sys[lat_h(nx,ny)]=model_wsm_tb.onsite_h
            elif square(nx,ny,R2):
                sys[lat_e(nx,ny)]=model_sc.onsite_e
                sys[lat_h(nx,ny)]=model_sc.onsite_h
                sys[lat_h(nx,ny),lat_e(nx,ny)]=model_sc.pairing

    # hoppings
    for nx in range(-R2,R2+1):
        for ny in range(-R2,R2+1):
            if square(nx,ny,R1):
                if square(nx+1,ny,R1):
                    sys[lat_e(nx+1,ny),lat_e(nx,ny)]=model_wsm.hop_e
                    sys[lat_h(nx+1,ny),lat_h(nx,ny)]=model_wsm.hop_h
                if square(nx,ny+1,R1):
                    sys[lat_e(nx,ny+1),lat_e(nx,ny)]=model_wsm.hop_e
                    sys[lat_h(nx,ny+1),lat_h(nx,ny)]=model_wsm.hop_h
                if square(nx+1,ny,R2) and not square(nx+1,ny,R1):
                    sys[lat_e(nx+1,ny),lat_e(nx,ny)]=model_sc.hop_e
                    sys[lat_h(nx+1,ny),lat_h(nx,ny)]=model_sc.hop_h
                if square(nx,ny+1,R2) and not square(nx,ny+1,R1):
                    sys[lat_e(nx,ny+1),lat_e(nx,ny)]=model_sc.hop_e
                    sys[lat_h(nx,ny+1),lat_h(nx,ny)]=model_sc.hop_h
            
            elif square(nx,ny,R2):
                if square(nx+1,ny,R2):
                    sys[lat_e(nx+1,ny),lat_e(nx,ny)]=model_sc.hop_e
                    sys[lat_h(nx+1,ny),lat_h(nx,ny)]=model_sc.hop_h
                if square(nx,ny+1,R2):
                    sys[lat_e(nx,ny+1),lat_e(nx,ny)]=model_sc.hop_e
                    sys[lat_h(nx,ny+1),lat_h(nx,ny)]=model_sc.hop_h

    fsys = sys.finalized()
                    
    if plot_sys:
        plot_system(sys,fsys,p,8,8)

    return fsys



def weyl_andreev_solenoid( wx_sc_left,wx_wsm,wx_sc_right,wz,model,\
                                     berry_phase=True,plot_sys=False,p=None,testing=False ):

    
    if model=='pdotsigma_4band':
        model_wsm = weyl_pdotsigma_4band.WeylSC2D_xz()
        model_msc_L = sc_4band.MetallicSC2D_xz()
        model_msc_R = sc_4band.MetallicSC2D_xz()
    elif model=='maxim_4band':
        model_wsm = weyl_maxim_4band.WeylSC2D_xz()
        model_msc_L = sc_4band.MetallicSC2D_xz()
        model_msc_R = sc_4band.MetallicSC2D_xz()
    elif model=='maxim_2band':
        model_wsm = weyl_maxim_2band.Twoband_2D_xz()
        model_msc_L = sc_2band.MetallicSC2D_xz()
        model_msc_R = sc_2band.MetallicSC2D_xz()
    elif model=='jakub_2band':
        model_wsm = weyl_jakub_2band.Twoband_2D_xz()
        model_msc_L = sc_2band.MetallicSC2D_xz()
        model_msc_R = sc_2band.MetallicSC2D_xz()
    else:
        raise ValueError( model + ", is not implemented. Possible models are pdotsigma_4band")

        
    # lattices
    lat_e = model_wsm.lat_e
    lat_h = model_wsm.lat_h

    # builder
    sys = kwant.Builder()

    # first, define all sites and their onsite energies
    x1=wx_sc_left; x2=x1+wx_wsm; x3=x2+wx_sc_right

    # a) SC (left)
    for nx in range(x1):
        for nz in range(wz):
            sys[lat_e(nx,nz)]=model_msc_L.onsite_e
            sys[lat_h(nx,nz)]=model_msc_L.onsite_h
            sys[lat_h(nx,nz),lat_e(nx,nz)]=model_msc_L.pairing

    # b) WSM (left)
    for nx in range(x1,x2):
        for nz in range(wz):
            sys[lat_e(nx,nz)]=model_wsm.onsite_e
            sys[lat_h(nx,nz)]=model_wsm.onsite_h
        
    # c) SC (right)
    for nx in range(x2,x3):
        for nz in range(wz):
            sys[lat_e(nx,nz)]=model_msc_R.onsite_e
            sys[lat_h(nx,nz)]=model_msc_R.onsite_h
            sys[lat_h(nx,nz),lat_e(nx,nz)]=model_msc_R.pairing
        
    # second, set the hoppings in x-direction
    # a) sc left
    for nx in range(x1):
        for nz in range(wz):
            sys[lat_e(nx+1,nz),lat_e(nx,nz)]=model_msc_L.hop_e
            sys[lat_h(nx+1,nz),lat_h(nx,nz)]=model_msc_L.hop_h
        
    # b) WSM
    for nx in range(x1,x2-1):
        for nz in range(wz):
            sys[lat_e(nx+1,nz),lat_e(nx,nz)]=model_wsm.hop_e
            sys[lat_h(nx+1,nz),lat_h(nx,nz)]=model_wsm.hop_h
    
    # c) sc hoppings
    for nx in range(x2-1,x3-1):
        for nz in range(wz):
            sys[lat_e(nx+1,nz),lat_e(nx,nz)]=model_msc_R.hop_e
            sys[lat_h(nx+1,nz),lat_h(nx,nz)]=model_msc_R.hop_h

    # second, set the hoppings in z-direction
    # a) sc left
    for nx in range(x1):
        for nz in range(wz-1):
            sys[lat_e(nx,nz+1),lat_e(nx,nz)]=model_msc_L.hop_e
            sys[lat_h(nx,nz+1),lat_h(nx,nz)]=model_msc_L.hop_h
        
    # b) WSM
    for nx in range(x1,x2):
        for nz in range(wz-1):
            sys[lat_e(nx,nz+1),lat_e(nx,nz)]=model_wsm.hop_e
            sys[lat_h(nx,nz+1),lat_h(nx,nz)]=model_wsm.hop_h
    
    # c) sc hoppings
    for nx in range(x2,x3):
        for nz in range(wz-1):
            sys[lat_e(nx,nz+1),lat_e(nx,nz)]=model_msc_R.hop_e
            sys[lat_h(nx,nz+1),lat_h(nx,nz)]=model_msc_R.hop_h


    # LEADS
    # builder
    sym_b=kwant.TranslationalSymmetry( (0,-1) )
    sym_t=kwant.TranslationalSymmetry( (0,1) )
    lead_eb = kwant.Builder( sym_b )
    lead_hb = kwant.Builder( sym_b )
    lead_et = kwant.Builder( sym_t )
    lead_ht = kwant.Builder( sym_t )

    for nx in range(x1,x2):
        lead_eb[lat_e(nx,0)]=model_wsm.onsite_e
        lead_hb[lat_h(nx,0)]=model_wsm.onsite_h
        lead_et[lat_e(nx,0)]=model_wsm.onsite_e
        lead_ht[lat_h(nx,0)]=model_wsm.onsite_h
    
    for nx in range(x1,x2-1):
        lead_eb[lat_e(nx+1,0),lat_e(nx,0)]=model_wsm.hop_e
        lead_hb[lat_h(nx+1,0),lat_h(nx,0)]=model_wsm.hop_h
        lead_et[lat_e(nx+1,0),lat_e(nx,0)]=model_wsm.hop_e
        lead_ht[lat_h(nx+1,0),lat_h(nx,0)]=model_wsm.hop_h

    for nx in range(x1,x2):
        lead_eb[lat_e(nx,1),lat_e(nx,0)]=model_wsm.hop_e
        lead_hb[lat_h(nx,1),lat_h(nx,0)]=model_wsm.hop_h
        lead_et[lat_e(nx,1),lat_e(nx,0)]=model_wsm.hop_e
        lead_ht[lat_h(nx,1),lat_h(nx,0)]=model_wsm.hop_h

    sys.attach_lead( lead_eb )
    sys.attach_lead( lead_hb )
    sys.attach_lead( lead_et )
    sys.attach_lead( lead_ht )

    # finalize the system
    fsys = sys.finalized()

    # plot lattice and hoppings if desired
    if plot_sys:
        plot_system(sys,fsys,p,12,6)

    if not testing:
        return fsys
    else:
        sys_lead = kwant.Builder( sym_t )
        for nx in range(x1):
            sys_lead[lat_e(nx,0)]=model_msc_L.onsite_e
            sys_lead[lat_h(nx,0)]=model_msc_L.onsite_h
            sys_lead[lat_h(nx,0),lat_e(nx,0)]=model_msc_L.pairing
        for nx in range(x1,x2):
            sys_lead[lat_e(nx,0)]=model_wsm.onsite_e
            sys_lead[lat_h(nx,0)]=model_wsm.onsite_h
        for nx in range(x2,x3):
            sys_lead[lat_e(nx,0)]=model_msc_R.onsite_e
            sys_lead[lat_h(nx,0)]=model_msc_R.onsite_h
            sys_lead[lat_h(nx,0),lat_e(nx,0)]=model_msc_R.pairing
        for nx in range(x1):
            sys_lead[lat_e(nx+1,0),lat_e(nx,0)]=model_msc_L.hop_e
            sys_lead[lat_h(nx+1,0),lat_h(nx,0)]=model_msc_L.hop_h
        for nx in range(x1,x2-1):
            sys_lead[lat_e(nx+1,0),lat_e(nx,0)]=model_wsm.hop_e
            sys_lead[lat_h(nx+1,0),lat_h(nx,0)]=model_wsm.hop_h
        for nx in range(x2-1,x3-1):
            sys_lead[lat_e(nx+1,0),lat_e(nx,0)]=model_msc_R.hop_e
            sys_lead[lat_h(nx+1,0),lat_h(nx,0)]=model_msc_R.hop_h
        for nx in range(x1):
            sys_lead[lat_e(nx,1),lat_e(nx,0)]=model_msc_L.hop_e
            sys_lead[lat_h(nx,1),lat_h(nx,0)]=model_msc_L.hop_h
        for nx in range(x1,x2):
            sys_lead[lat_e(nx,1),lat_e(nx,0)]=model_wsm.hop_e
            sys_lead[lat_h(nx,1),lat_h(nx,0)]=model_wsm.hop_h
        for nx in range(x2,x3):
            sys_lead[lat_e(nx,1),lat_e(nx,0)]=model_msc_R.hop_e
            sys_lead[lat_h(nx,1),lat_h(nx,0)]=model_msc_R.hop_h
    
    return fsys,sys_lead,lead_eb,lead_hb,lead_et,lead_ht


def weyl_andreev_solenoid__test( wx_sc_left,wx_wsm,wx_sc_right,wz,model,\
                                     berry_phase=True,plot_sys=False,p=None,testing=False ):

    
    if model=='pdotsigma_4band':
        model_wsm = weyl_pdotsigma_4band.WeylSC2D_xz()
        model_msc_L = sc_4band.MetallicSC2D_xz()
        model_msc_R = sc_4band.MetallicSC2D_xz()
    elif model=='maxim_4band':
        model_wsm = weyl_maxim_4band.WeylSC2D_xz()
        model_msc_L = sc_4band.MetallicSC2D_xz()
        model_msc_R = sc_4band.MetallicSC2D_xz()
    elif model=='maxim_2band':
        model_wsm = weyl_maxim_2band.Twoband_2D_xz()
        model_msc_L = sc_2band.MetallicSC2D_xz()
        model_msc_R = sc_2band.MetallicSC2D_xz()
    elif model=='jakub_2band':
        model_wsm = weyl_jakub_2band.Twoband_2D_xz()
        model_msc_L = sc_2band.MetallicSC2D_xz()
        model_msc_R = sc_2band.MetallicSC2D_xz()
    else:
        raise ValueError( model + ", is not implemented. Possible models are pdotsigma_4band")

        
    # lattices
    lat_e = model_wsm.lat_e
    lat_h = model_wsm.lat_h

    # builder
    sys = kwant.Builder()

    # first, define all sites and their onsite energies
    x1=wx_sc_left; x2=x1+wx_wsm; x3=x2+wx_sc_right

    # a) SC (left)
    for nx in range(x1):
        for nz in range(wz):
            sys[lat_e(nx,nz)]=model_msc_L.onsite_e
            sys[lat_h(nx,nz)]=model_msc_L.onsite_h
            sys[lat_h(nx,nz),lat_e(nx,nz)]=model_msc_L.pairing

    # b) WSM (left)
    for nx in range(x1,x2):
        for nz in range(wz):
            sys[lat_e(nx,nz)]=model_wsm.onsite_e
            sys[lat_h(nx,nz)]=model_wsm.onsite_h
        
    # c) SC (right)
    for nx in range(x2,x3):
        for nz in range(wz):
            sys[lat_e(nx,nz)]=model_msc_R.onsite_e
            sys[lat_h(nx,nz)]=model_msc_R.onsite_h
            sys[lat_h(nx,nz),lat_e(nx,nz)]=model_msc_R.pairing
        
    # second, set the hoppings in x-direction
    # a) sc left
    for nx in range(x1):
        for nz in range(wz):
            sys[lat_e(nx+1,nz),lat_e(nx,nz)]=model_msc_L.hop_e
            sys[lat_h(nx+1,nz),lat_h(nx,nz)]=model_msc_L.hop_h
        
    # b) WSM
    for nx in range(x1,x2-1):
        for nz in range(wz):
            sys[lat_e(nx+1,nz),lat_e(nx,nz)]=model_wsm.hop_e
            sys[lat_h(nx+1,nz),lat_h(nx,nz)]=model_wsm.hop_h
    
    # c) sc hoppings
    for nx in range(x2-1,x3-1):
        for nz in range(wz):
            sys[lat_e(nx+1,nz),lat_e(nx,nz)]=model_msc_R.hop_e
            sys[lat_h(nx+1,nz),lat_h(nx,nz)]=model_msc_R.hop_h

    # second, set the hoppings in z-direction
    # a) sc left
    for nx in range(x1):
        for nz in range(wz-1):
            sys[lat_e(nx,nz+1),lat_e(nx,nz)]=model_msc_L.hop_e
            sys[lat_h(nx,nz+1),lat_h(nx,nz)]=model_msc_L.hop_h
        
    # b) WSM
    for nx in range(x1,x2):
        for nz in range(wz-1):
            sys[lat_e(nx,nz+1),lat_e(nx,nz)]=model_wsm.hop_e
            sys[lat_h(nx,nz+1),lat_h(nx,nz)]=model_wsm.hop_h
    
    # c) sc hoppings
    for nx in range(x2,x3):
        for nz in range(wz-1):
            sys[lat_e(nx,nz+1),lat_e(nx,nz)]=model_msc_R.hop_e
            sys[lat_h(nx,nz+1),lat_h(nx,nz)]=model_msc_R.hop_h


    # LEADS
    # builder
    sym_b=kwant.TranslationalSymmetry( (0,-1) )
    sym_t=kwant.TranslationalSymmetry( (0,1) )
    lead_eb = kwant.Builder( sym_b )
    lead_hb = kwant.Builder( sym_b )
    
    for nx in range(x1,x2):
        lead_eb[lat_e(nx,0)]=model_wsm.onsite_e
        lead_hb[lat_h(nx,0)]=model_wsm.onsite_h
        
    for nx in range(x1,x2-1):
        lead_eb[lat_e(nx+1,0),lat_e(nx,0)]=model_wsm.hop_e
        lead_hb[lat_h(nx+1,0),lat_h(nx,0)]=model_wsm.hop_h
    
    for nx in range(x1,x2):
        lead_eb[lat_e(nx,1),lat_e(nx,0)]=model_wsm.hop_e
        lead_hb[lat_h(nx,1),lat_h(nx,0)]=model_wsm.hop_h
    
    sys_lead = kwant.Builder( sym_t )
    for nx in range(x1):
        sys_lead[lat_e(nx,0)]=model_msc_L.onsite_e
        sys_lead[lat_h(nx,0)]=model_msc_L.onsite_h
        sys_lead[lat_h(nx,0),lat_e(nx,0)]=model_msc_L.pairing
    for nx in range(x1,x2):
        sys_lead[lat_e(nx,0)]=model_wsm.onsite_e
        sys_lead[lat_h(nx,0)]=model_wsm.onsite_h
    for nx in range(x2,x3):
        sys_lead[lat_e(nx,0)]=model_msc_R.onsite_e
        sys_lead[lat_h(nx,0)]=model_msc_R.onsite_h
        sys_lead[lat_h(nx,0),lat_e(nx,0)]=model_msc_R.pairing
    for nx in range(x1):
        sys_lead[lat_e(nx+1,0),lat_e(nx,0)]=model_msc_L.hop_e
        sys_lead[lat_h(nx+1,0),lat_h(nx,0)]=model_msc_L.hop_h
    for nx in range(x1,x2-1):
        sys_lead[lat_e(nx+1,0),lat_e(nx,0)]=model_wsm.hop_e
        sys_lead[lat_h(nx+1,0),lat_h(nx,0)]=model_wsm.hop_h
    for nx in range(x2-1,x3-1):
        sys_lead[lat_e(nx+1,0),lat_e(nx,0)]=model_msc_R.hop_e
        sys_lead[lat_h(nx+1,0),lat_h(nx,0)]=model_msc_R.hop_h
    for nx in range(x1):
        sys_lead[lat_e(nx,1),lat_e(nx,0)]=model_msc_L.hop_e
        sys_lead[lat_h(nx,1),lat_h(nx,0)]=model_msc_L.hop_h
    for nx in range(x1,x2):
        sys_lead[lat_e(nx,1),lat_e(nx,0)]=model_wsm.hop_e
        sys_lead[lat_h(nx,1),lat_h(nx,0)]=model_wsm.hop_h
    for nx in range(x2,x3):
        sys_lead[lat_e(nx,1),lat_e(nx,0)]=model_msc_R.hop_e
        sys_lead[lat_h(nx,1),lat_h(nx,0)]=model_msc_R.hop_h

    sys.attach_lead( lead_eb )
    sys.attach_lead( lead_hb )
    sys.attach_lead( sys_lead )

    # finalize the system
    fsys = sys.finalized()

    # plot lattice and hoppings if desired
    if plot_sys:
        plot_system(sys,fsys,p,12,6)

    if not testing:
        return fsys
    else:
        return fsys,sys_lead,lead_eb,lead_hb



""" 1.1c finite 1D SC-WSM-SC junction """
def make_finite_1D_sns_junction__2band_model( wx_sc_left,wx_wsm,wx_sc_right,plot_sys=False,p=None ):

    # get models
    model_wsm = weyl_2band.Twoband_1D()
    model_msc_L = sc_2band.MetallicSC1D_x()
    model_msc_R = sc_2band.MetallicSC1D_x()
    #print model_msc_R.params

    
    # lattices
    lat_e = model_wsm.lat_e
    lat_h = model_wsm.lat_h

    # builder
    sys = kwant.Builder()

    # first, define all sites and their onsite energies
    x1=wx_sc_left; x2=x1+wx_wsm; x3=x2+wx_sc_right

    # a) SC (left)
    for nx in range(x1):
        sys[lat_e(nx,)]=model_msc_L.onsite_e
        sys[lat_h(nx,)]=model_msc_L.onsite_h
        sys[lat_h(nx,),lat_e(nx,)]=model_msc_L.pairing

    # b) WSM (left)
    for nx in range(x1,x2):
        sys[lat_e(nx,)]=model_wsm.onsite_e
        sys[lat_h(nx,)]=model_wsm.onsite_h
        
    # c) SC (right)
    for nx in range(x2,x3):
        sys[lat_e(nx,)]=model_msc_R.onsite_e
        sys[lat_h(nx,)]=model_msc_R.onsite_h
        sys[lat_h(nx,),lat_e(nx,)]=model_msc_R.pairing
        
    # second, set the hoppings
    # a) sc left
    for nx in range(x1-1):
        sys[lat_e(nx+1,),lat_e(nx,)]=model_msc_L.hop_e
        sys[lat_h(nx+1,),lat_h(nx,)]=model_msc_L.hop_h
    if wx_sc_left>0 and wx_wsm>0:
        sys[lat_e(x1,),lat_e(x1-1,)]=model_msc_L.hop_e
        sys[lat_h(x1,),lat_h(x1-1,)]=model_msc_L.hop_h
        
    # b) WSM
    for nx in range(x1,x2-1):
        sys[lat_e(nx+1,),lat_e(nx,)]=model_wsm.hop_e
        sys[lat_h(nx+1,),lat_h(nx,)]=model_wsm.hop_h
    
    # c) barrier and sc hoppings
    for nx in range(x2-1,x3-1):
        sys[lat_e(nx+1,),lat_e(nx,)]=model_msc_R.hop_e
        sys[lat_h(nx+1,),lat_h(nx,)]=model_msc_R.hop_h

    # finalize the system
    fsys = sys.finalized()

    # plot lattice and hoppings if desired
    if plot_sys:
        plot_system(sys,fsys,p,12,1)        
    
    return fsys



""" 1.1c finite 1D SC-WSM-SC junction """
def make_finite_smooth_2band_1D_sns_junction( wx_sc_left,wx_wsm,wx_sc_right,len_int,plot_sys=False,p=None ):

    # get models
    model_wsm = weyl_2band.Twoband_1D()
    model_msc_L = sc_2band.MetallicSC1D_x()
    model_msc_R = sc_2band.MetallicSC1D_x()
    
    def slider_onsite(site,p):
        len_sc_left =p.alpha*(wx_sc_left-.5)
        len_wsm     =p.alpha*(wx_wsm)
        len_sc_right=p.alpha*(wx_sc_right-.5)
        len_int_half=len_int/2.

        nx,=site.pos
        x=nx*p.alpha

        left_site=True
        if x<=len_sc_left-len_int_half:
            beta=0.
        elif x<len_sc_left+len_int_half:
            beta = (x-len_sc_left+len_int_half)/len_int
        elif x<len_sc_left+len_wsm-len_int_half:
            beta = 1.
        elif x<len_sc_left+len_wsm+len_int_half:
            left_site=False
            beta = 1.- (x-len_sc_left-len_wsm+len_int_half)/len_int
        else:
            left_site=False
            beta=0

        return left_site,beta

    def slider_hop(site1,site2,p):
        len_sc_left =p.alpha*(wx_sc_left-.5)
        len_wsm     =p.alpha*(wx_wsm)
        len_sc_right=p.alpha*(wx_sc_right-.5)
        len_int_half=len_int/2.

        nx1,=site1.pos
        nx2,=site2.pos
        x=(nx1+nx2)*p.alpha/2.

        left_site=True
        if x<=len_sc_left-len_int_half:
            beta=0.
        elif x<len_sc_left+len_int_half:
            beta = (x-len_sc_left+len_int_half)/len_int
        elif x<len_sc_left+len_wsm-len_int_half:
            beta = 1.
        elif x<len_sc_left+len_wsm+len_int_half:
            left_site=False
            beta = 1.- (x-len_sc_left-len_wsm+len_int_half)/len_int
        else:
            left_site=False
            beta=0
                                    
        return left_site,beta
    
    
    def onsite_e(site,p):
        left,beta=slider_onsite(site,p)
        if left:
            return (1-beta)*model_msc_L.onsite_e(site,p) + beta*model_wsm.onsite_e(site,p)
        else:
            return (1-beta)*model_msc_R.onsite_e(site,p) + beta*model_wsm.onsite_e(site,p)
    def onsite_h(site,p):
        left,beta=slider_onsite(site,p)
        if left:
            return (1-beta)*model_msc_L.onsite_h(site,p) + beta*model_wsm.onsite_h(site,p)
        else:
            return (1-beta)*model_msc_R.onsite_h(site,p) + beta*model_wsm.onsite_h(site,p)


    def hop_e(site1,site2,p):
        left,beta=slider_hop(site1,site2,p)
        if left:
            return (1-beta)*model_msc_L.hop_e(site1,site2,p) + beta*model_wsm.hop_e(site1,site2,p)
        else:
            return (1-beta)*model_msc_R.hop_e(site1,site2,p) + beta*model_wsm.hop_e(site1,site2,p)
    def hop_h(site1,site2,p):
        left,beta=slider_hop(site1,site2,p)
        if left:
            return (1-beta)*model_msc_L.hop_h(site1,site2,p) + beta*model_wsm.hop_h(site1,site2,p)
        else:
            return (1-beta)*model_msc_R.hop_h(site1,site2,p) + beta*model_wsm.hop_h(site1,site2,p)


    def pairing(site1,site2,p):
        left,beta=slider_hop(site1,site2,p)
        if left:
            return (1-beta)*model_msc_L.pairing(site1,site2,p)
        else:
            return (1-beta)*model_msc_R.pairing(site1,site2,p)
        
    # lattices
    lat_e = model_wsm.lat_e
    lat_h = model_wsm.lat_h

    # builder
    sys = kwant.Builder()

    # first, define all sites and their onsite energies
    x1=wx_sc_left; x2=x1+wx_wsm; x3=x2+wx_sc_right

    for nx in range(x3):
        sys[lat_e(nx,)]=onsite_e
        sys[lat_h(nx,)]=onsite_h
        sys[lat_h(nx,),lat_e(nx,)]=pairing

    # second, set the hoppings
    # a) sc left
    for nx in range(x3-1):
        sys[lat_e(nx+1,),lat_e(nx,)]=hop_e
        sys[lat_h(nx+1,),lat_h(nx,)]=hop_h

    # finalize the system
    fsys = sys.finalized()

    # plot lattice and hoppings if desired
    if plot_sys:
        plot_system(sys,fsys,p,12,1)        
    
    return fsys



""" 2. SPECTRA AND WAVE FUNCTIONS """

"""2.1 calc_ens calculates the 10 lowest eigenvalues of a
tight binding Hamiltonian"""
def calc_ens(fsys,p,return_vecs=False,no_states=10,e0=0):
    ham_sparse_coo = fsys.hamiltonian_submatrix( args=([p]),sparse=True )
    ham_sparse = ham_sparse_coo.tocsc()

    if return_vecs:
        evals,evecsT = lag.eigsh( ham_sparse,k=no_states,return_eigenvectors=True, \
                                  which='LM',sigma=e0, tol=10**(-3) )
        return evals, evecsT.T
    else:
        evals = lag.eigsh( ham_sparse,k=no_states,return_eigenvectors=False, \
                              which='LM',sigma=e0, tol=10**(-3) )
        return evals


"""2.2 calc_ens_with_charge calculated the eigenvalues of a
tight-binding hamiltonian together with the charge of the
corresponding quasiparticles. We use the convention where the
electrons have positive charge."""
def calc_ens_with_charge(fsys,p,return_vecs=False,no_states=10):
    ham_sparse_coo = fsys.hamiltonian_submatrix( args=([p]),sparse=True )
    ham_sparse = ham_sparse_coo.tocsc()
    evals,evecsT = lag.eigsh( ham_sparse,k=no_states,return_eigenvectors=True, \
                              which='LM',sigma=0, tol=10**(-3) )
    evecs=evecsT.T

    sites=[ s.pos[0] for s in fsys.sites ]
    families=[ s.family.name for s in fsys.sites ]
    
    no_sites=len(sites)
    no_orbs =int(len(evecs[0])/no_sites)
        
    ens=[]; charges=[]; vecs=[]
    for n in range(no_states):

        wf=np.reshape(evecs[n],(no_sites,no_orbs))
        en=evals[n]
        e_w,h_w=get_e_h_weights(wf,families)

        ens.append(en)
        charges.append(e_w-h_w)
        vecs.append( wf )

    if return_vecs:
        return ens,charges,vecs,sites,families
    else:
        return ens,charges


"""2.2a get_e_h_weights is a function that takes a wave function and
reports back how much weight is on the electron part and how much is
on the hole part. This requires that there are separate lattices for
electrons and holes which are named 'e' and 'h'.

"""
def get_e_h_weights(wf,families):
    no_sites = len(wf)
       
    norm = np.vdot(wf,wf)
    weights = [ np.vdot(v,v)/norm for v in wf ]

    e_weight=0; h_weight=0;
    for n in range(no_sites):
        if families[n]=='e':
            e_weight+=weights[n]
        elif families[n]=='h':
            h_weight+=weights[n]
    if abs(e_weight+h_weight-1)>10**(-3):
        raise ValueError( "The sum of electron and hole weights is not 1" )

    return e_weight,h_weight


""" 2.3 get_surface_states gets only states localized at certain hotsites """
def get_surface_states(fsys,p,hotsites,treshold=.5,no_states=10):
    ham_sparse_coo = fsys.hamiltonian_submatrix( args=([p]),sparse=True )
    ham_sparse = ham_sparse_coo.tocsc()
    evals,evecsT = lag.eigsh( ham_sparse,k=no_states,return_eigenvectors=True,which='LM',sigma=0, tol=10**(-3) )
    evecs=evecsT.T

    sites=[ s.pos[0] for s in fsys.sites ]
    families=[ s.family.name for s in fsys.sites ]

    no_sites=len(sites)
    no_orbs =int(len(evecs[0])/no_sites)

    surf_states=[]
    for n in range(no_states):
        wf=np.reshape(evecs[n],(no_sites,no_orbs))
        en=evals[n]

        is_loc=is_localized_state(wf,sites,hotsites,treshold=treshold )
        if is_loc:
            surf_states.append( {'en':en,'wf':wf} )
                
    return {"sites":sites,"families":families,"surf_states":surf_states}


"""2.3a is_localized_state checks if more than a certain treshold of the weight of a
wavefunction is localized at certain 'hotsites'"""
def is_localized_state(wf,sites,hotsites,treshold=.4):
    no_sites = len(wf)
    s_max=max(sites)
    norm = np.vdot(wf,wf)
    weights = [ np.vdot(v,v)/norm for v in wf ]
    
    hot_weights = []
    for n in range(no_sites):
        if sites[n] in hotsites:
            hot_weights.append( weights[n] )
    
    hot_weight=sum(hot_weights)
    if hot_weight>treshold:
        return True
    else:
        return False


""" 3.2 find_zero_modes calculates the zero modes using a parallelized zero finder
input
-----

fsys     -- finalized system
p        -- parameters of system
interval -- energy window in which we are looking for zeros
no_modes -- minimum number of states to be calculated


return
------
zero_modes, crossing_bands, other_bands, other_bands_2, bands
"""
def trace_bands( bands ):

    skzs=sorted( bands.keys() )
    no_modes=len(bands[skzs[0]]['ens'])
        
    # storage for the traced bands
    traced_modes=[]
    kz0=skzs[0]
    
    
    # follow those evecs in the interval
    for n in range(no_modes):
        traced_mode={}

        m0=sorted( enumerate(bands[kz0]['ens']), key=lambda x: abs(x[1]) )[0][0]
        e0=bands[kz0]['ens'][m0]
        v0=bands[kz0]['vecs'][m0]
        for kz in skzs:
            es = bands[kz]['ens']
            vs = bands[kz]['vecs']
            chrgs = bands[kz]['charges']

            # get all wave functions and check their overlap with v0
            overlap = [ np.abs( np.vdot(v0,vs[m]) ) for m in xrange(len(vs)) ]
            n_best = np.argmax( overlap )
            traced_mode[kz]={}
            traced_mode[kz]['en']=es[n_best]
            traced_mode[kz]['charge']=chrgs[n_best]
            v0=vs[n_best]

            # remove this data point from work_bands to avoid double tracing
            del bands[kz]['ens'][n_best]
            del bands[kz]['vecs'][n_best]
            del bands[kz]['charges'][n_best]
        traced_modes.append(traced_mode)
    return traced_modes



""" 3. DATA STORAGE """

""" 3.1 make a simple namespace with parameters of system """
def make_p( **kwargs ):
    p = SimpleNamespace()
    p.__dict__.update(kwargs)
    return p

""" 3.2 make a simple namespace with parameters of system """
def make_p_HACK( **kwargs ):
    p = SimpleNamespace()
    p.__dict__.update(kwargs)
    if hasattr( p,"filling" ) and hasattr( p,"t_M" ):
        p.met_mu=2*p.ai*p.t_M*p.filling
        p.met_tx=p.ai*p.t_M
        p.met_ty=p.ai*p.t_M
        p.met_tz=p.t_M
    return p



""" 4. VISUALIZATION """

""" 4.1 function that plots the lattice with onsite-energies and hoppings """
def plot_system(sys,fsys,p,L=6,H=4):
    mysites = fsys.sites
        
    def onsite(s1):
        i=0; ni=0
        for s in mysites:
            if s==s1:
                i=ni
            ni+=1

        a= fsys.hamiltonian_submatrix( args=([p]),to_sites=[i],from_sites=[i] )
        el = a[0][1]+a[1][1]
        return 6*np.log(el)

    def hop(s1,s2):
        i=0; j=0; ni=0
        for s in mysites:
            if s==s1:
                i=ni
            if s==s2:
                j=ni
            ni+=1

        pdiff = s2.pos-s1.pos
        if np.all( [diff>=0 for diff in pdiff] ):
            a= fsys.hamiltonian_submatrix( args=([p]),to_sites=[i],from_sites=[j] )
        else:
            a= fsys.hamiltonian_submatrix( args=([p]),to_sites=[j],from_sites=[i] )

        if len(a)==2:
            v = (1,0)
        elif len(a)==4:
            v = (1,0,1,1)
        v2 = np.dot(a,v)
        q  = np.vdot(v,v2)
    
        return abs(q)#np.cos(np.angle(q))

    def hop_lw(s1,s2):
        if s1.family.name=='e' and s2.family.name=='e':
            i=0; j=0; ni=0
            for s in mysites:
                if s==s1:
                    i=ni
                if s==s2:
                    j=ni
                ni+=1

            pdiff = s2.pos-s1.pos
            if np.all( [diff>=0 for diff in pdiff] ):
                a= fsys.hamiltonian_submatrix( args=([p]),to_sites=[i],from_sites=[j] )
            else:
                a= fsys.hamiltonian_submatrix( args=([p]),to_sites=[j],from_sites=[i] )

            if len(a)==2:
                v = (1,0)
            elif len(a)==4:
                v = (1,0,1,1)
            v2 = np.dot(a,v)
            q  = np.vdot(v,v2)
    
            return .2*np.cos(np.angle(q))
        else:
            return 0

    fig, (ax11) = plt.subplots(1,1,figsize=(L,H) )
    kwant.plotter.plot( sys,site_size=onsite,hop_color=hop,hop_lw=hop_lw, ax=ax11)


""" 5. Transport """
def get_smatrix(fsys,p):
    S=kwant.smatrix( fsys,args=([p]) )
    R_ee=S.submatrix(0,0)
    R_eh=S.submatrix(1,0)
    T_ee=S.submatrix(2,0)
    T_eh=S.submatrix(3,0)
    return  S,[R_ee,R_eh,T_ee,T_eh]

""" 5. Transport """
def get_smatrix__test(fsys,p):
    S=kwant.smatrix( fsys,args=([p]) )
    R_ee=S.submatrix(0,0)
    R_eh=S.submatrix(1,0)
    T=S.submatrix(2,0)
    return  S,[R_ee,R_eh,T]

    
