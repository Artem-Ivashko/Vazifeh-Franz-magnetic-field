# libraries
from __future__ import division

from tinyarray import array as ta

import numpy as np
from numpy import pi
from scipy import sparse as sp
from scipy.sparse import linalg as lag

import matplotlib.cm as cm; import matplotlib.pyplot as plt;

import kwant

# my libraries (use the NEW library!)
import use_lib_v2; use_lib_v2.init()
import weyl_sc_pdotsigma as weyl_SC
import metallic_sc
from memory import SimpleNamespace
from memory import get_var
#import standard_sys
#import shapes
from paulimatrices import *


"""
TABLE OF CONTENTS

1.   BUILDERS
1.1  effective 1D
1.1a finite N-S
1.1b infinite N-S
1.1c finite S-N-S
1.1d WSM lead
1.2  effective 2D
1.2a infinite N-S
1.2b coated cylindical wire

2.  SPECTRA AND WAVE FUNCTIONS
2.1 low energy spectrum as function of kz
2.2 low energy spectrum for finite effective 1D N-s junction. surface,bulk separation, electron-hole polarization
2.3 surface states only
2.4 check if state is localized at certain sites
2.5 get the electron-hole polarization of a wave function

3.  TRANSPORT
3.1 get_s_matrix
3.2 get_resolved_probs
3.3 get_reflection_probs
3.4 split_lead
3.5 supercurrent

4.  DATA STORAGE
4.1 make a simple namespace with parameters of system

5.  VISUALIZATION
5.1 function that plots the lattice with onsite-energies and hoppings

6. DISCARDED FUNCTIONS
"""


"""COMMENTS """
"""Will choose the following conventions: Transport will always be in
x-direction; in y-direction we have hardwall or periodic boundary
conditions and potentially a magnetic field; the Weyl cones are always
separated in z-direction.

"""


""" 1. Builders: The Builders we will need are on a lattice in x- or xy- direction """

""" 1.1 effective 1D """
""" 1.1a finite 1D WSM-SC junction """
def make_finite_1D_ns_junction( wx_wsm,wx_sc,wx_barrier=0,plot_sys=False,p=None ):
        
    # get models
    model_wsm = weyl_SC.WeylSC1D_x()
    model_msc = weyl_SC.MetallicSC1D_x()

    # lattices
    lat_e = model_wsm.lat_e
    lat_h = model_wsm.lat_h

    # builder
    sys = kwant.Builder()

    # first, define all sites and their onsite energies
    # a) WSM (left)
    for nx in range(wx_wsm):
        sys[lat_e(nx,)]=model_wsm.onsite_e
        sys[lat_h(nx,)]=model_wsm.onsite_h

    def onsite_barrier_e(site,p):
        return model_msc.onsite_e(site,p) - p.mu_B*s0s0
    def onsite_barrier_h(site,p):
        return model_msc.onsite_h(site,p) + p.mu_B*s0s0
    
    # b) metallic barrier
    for nx in range(wx_wsm,wx_wsm+wx_barrier):
        sys[lat_e(nx,)]=onsite_barrier_e
        sys[lat_h(nx,)]=onsite_barrier_h
        
    # b) SC (right)
    for nx in range(wx_wsm+wx_barrier,wx_wsm+wx_barrier+wx_sc):
        sys[lat_e(nx,)]=model_msc.onsite_e
        sys[lat_h(nx,)]=model_msc.onsite_h
        sys[lat_h(nx,),lat_e(nx,)]=model_msc.pairing
        
    # second, set the hoppings
    # a) WSM
    for nx in range(wx_wsm-1):
        sys[lat_e(nx+1,),lat_e(nx,)]=model_wsm.hop_e
        sys[lat_h(nx+1,),lat_h(nx,)]=model_wsm.hop_h
    
    # b) barrier and sc hoppings
    if wx_wsm>0:
        if wx_barrier>0 or wx_sc>0:
            sys[lat_e(wx_wsm,),lat_e(wx_wsm-1,)]=model_msc.hop_e
            sys[lat_h(wx_wsm,),lat_h(wx_wsm-1,)]=model_msc.hop_h
    for nx in range(wx_wsm,wx_wsm+wx_barrier+wx_sc-1):
        sys[lat_e(nx+1,),lat_e(nx,)]=model_msc.hop_e
        sys[lat_h(nx+1,),lat_h(nx,)]=model_msc.hop_h

        
    # finalize the system
    fsys = sys.finalized()

    # plot lattice and hoppings if desired
    if plot_sys:
        plot_system(sys,fsys,p,12,1)
    
    return fsys


""" 1.1b infinite 1D WSM-SC junction """
def make_infinite_1D_ns_junction( Wx,plot_sys=False ):
        
    # get models
    model_wsm = weyl_SC.WeylSC1D_x()
    model_msc = weyl_SC.MetallicSC1D_x()

    # lattices
    lat_e = model_wsm.lat_e
    lat_h = model_wsm.lat_h

    # builder
    sys = kwant.Builder()
    wsm_lead_e = kwant.Builder(  kwant.TranslationalSymmetry( (-1,) )  )
    wsm_lead_h = kwant.Builder(  kwant.TranslationalSymmetry( (-1,) )  )
    sc_lead  = kwant.Builder(  kwant.TranslationalSymmetry( (+1,) )  )

    # system
    for nx in range(Wx):
        sys[lat_e(nx,)]=model_wsm.onsite_e
        sys[lat_h(nx,)]=model_wsm.onsite_h
    for nx in range(Wx-1):
        sys[lat_e(nx+1,),lat_e(nx,)]=model_wsm.hop_e
        sys[lat_h(nx+1,),lat_h(nx,)]=model_wsm.hop_h
        

    # wsm lead
    wsm_lead_e[lat_e(0,)]=model_wsm.onsite_e
    wsm_lead_h[lat_h(0,)]=model_wsm.onsite_h
    wsm_lead_e[lat_e(1,),lat_e(0,)]=model_wsm.hop_e
    wsm_lead_h[lat_h(1,),lat_h(0,)]=model_wsm.hop_h

    # sc lead
    sc_lead[lat_e(0,)]=model_msc.onsite_e
    sc_lead[lat_h(0,)]=model_msc.onsite_h
    sc_lead[lat_h(0,),lat_e(0,)]=model_msc.pairing
    sc_lead[lat_e(1,),lat_e(0,)]=model_msc.hop_e
    sc_lead[lat_h(1,),lat_h(0,)]=model_msc.hop_h
    
    # finalize the system
    sys.attach_lead( wsm_lead_e )
    sys.attach_lead( wsm_lead_h )
    sys.attach_lead( sc_lead )
    fsys = sys.finalized()

    # plot lattice and hoppings if desired
    if plot_sys:
        plot_system(sys,fsys,p,12,1)
        
    
    return fsys


""" 1.1c finite 1D SC-WSM-SC junction """
def make_finite_1D_sns_junction( wx_sc_left,wx_wsm,wx_sc_right,plot_sys=False,p=None ):


    # get models
    model_wsm = weyl_SC.WeylSC1D_x()
    model_msc_L = weyl_SC.MetallicSC1D_x()
    model_msc_R = weyl_SC.MetallicSC1D_x()
    #print model_msc_R.params

    
    # lattices
    lat_e = model_wsm.lat_e
    lat_h = model_wsm.lat_h

    # builder
    sys = kwant.Builder()

    # first, define all sites and their onsite energies
    x1=wx_sc_left; x2=x1+wx_wsm; x3=x2+wx_sc_right

    # a) SC (left)
    for nx in range(x1):
        sys[lat_e(nx,)]=model_msc_L.onsite_e
        sys[lat_h(nx,)]=model_msc_L.onsite_h
        sys[lat_h(nx,),lat_e(nx,)]=model_msc_L.pairing

    # b) WSM (left)
    for nx in range(x1,x2):
        sys[lat_e(nx,)]=model_wsm.onsite_e
        sys[lat_h(nx,)]=model_wsm.onsite_h
        
    # c) SC (right)
    for nx in range(x2,x3):
        sys[lat_e(nx,)]=model_msc_R.onsite_e
        sys[lat_h(nx,)]=model_msc_R.onsite_h
        sys[lat_h(nx,),lat_e(nx,)]=model_msc_R.pairing
        
    # second, set the hoppings
    # a) sc left
    for nx in range(x1):
        sys[lat_e(nx+1,),lat_e(nx,)]=model_msc_L.hop_e
        sys[lat_h(nx+1,),lat_h(nx,)]=model_msc_L.hop_h
        
    # b) WSM
    for nx in range(x1,x2-1):
        sys[lat_e(nx+1,),lat_e(nx,)]=model_wsm.hop_e
        sys[lat_h(nx+1,),lat_h(nx,)]=model_wsm.hop_h
    
    # c) barrier and sc hoppings
    for nx in range(x2-1,x3-1):
        sys[lat_e(nx+1,),lat_e(nx,)]=model_msc_R.hop_e
        sys[lat_h(nx+1,),lat_h(nx,)]=model_msc_R.hop_h

    # finalize the system
    fsys = sys.finalized()

    # plot lattice and hoppings if desired
    if plot_sys:
        plot_system(sys,fsys,p,12,1)        
    
    return fsys



""" 1.1c finite 1D SC-WSM-SC junction """
def make_finite_1D_sns_junction__single_orbital_sc( wx_sc_left,wx_wsm,wx_sc_right,plot_sys=False,p=None ):

    # get models
    model_wsm = weyl_SC.WeylSC1D_x()
    if hasattr( p,'met_D_L') and hasattr( p,'met_D_R' ):
        model_msc_L = metallic_sc.MetallicSC1D_x( params=SimpleNamespace(met_D=p.met_D_L) )
        model_msc_R = metallic_sc.MetallicSC1D_x( params=SimpleNamespace(met_D=p.met_D_R) )
    else:
        model_msc_L = metallic_sc.MetallicSC1D_x()
        model_msc_R = metallic_sc.MetallicSC1D_x()
    #print model_msc_R.params

    # lattices
    lat_e = model_wsm.lat_e
    lat_h = model_wsm.lat_h

    # builder
    sys = kwant.Builder()

    # first, define all sites and their onsite energies
    x1=wx_sc_left; x2=x1+wx_wsm; x3=x2+wx_sc_right

    # a) SC (left)
    for nx in range(x1):
        sys[lat_e(nx,)]=model_msc_L.onsite_e
        sys[lat_h(nx,)]=model_msc_L.onsite_h
        sys[lat_h(nx,),lat_e(nx,)]=model_msc_L.pairing

    # b) WSM (left)
    for nx in range(x1,x2):
        sys[lat_e(nx,)]=model_wsm.onsite_e
        sys[lat_h(nx,)]=model_wsm.onsite_h
        
    # c) SC (right)
    for nx in range(x2,x3):
        sys[lat_e(nx,)]=model_msc_R.onsite_e
        sys[lat_h(nx,)]=model_msc_R.onsite_h
        sys[lat_h(nx,),lat_e(nx,)]=model_msc_R.pairing
        
    # second, set the hoppings
    # a) sc left
    for nx in range(x1-1):
        sys[lat_e(nx+1,),lat_e(nx,)]=model_msc_L.hop_e
        sys[lat_h(nx+1,),lat_h(nx,)]=model_msc_L.hop_h
        
    # b) WSM
    for nx in range(x1,x2-1):
        sys[lat_e(nx+1,),lat_e(nx,)]=model_wsm.hop_e
        sys[lat_h(nx+1,),lat_h(nx,)]=model_wsm.hop_h
    
    # c) barrier and sc hoppings
    for nx in range(x2,x3-1):
        sys[lat_e(nx+1,),lat_e(nx,)]=model_msc_R.hop_e
        sys[lat_h(nx+1,),lat_h(nx,)]=model_msc_R.hop_h

    def connect_left_e( s1,s2,p ):
        return -0.5*p.met_tx*ta( [[1./2.],[1./2.],[-1./2.],[-1./2.]] )
    def connect_left_h( s1,s2,p ):
        return -connect_left_e(s1,s2,p)

    def connect_right_e( s1,s2,p ):
        return -0.5*p.met_tx*ta( [[-1./2.,-1./2.,1./2.,1./2.]] )
    def connect_right_h( s1,s2,p ):
        return -connect_right_e(s1,s2,p)

    # connect left SC to WSM
    if wx_sc_left>0:
        sys[lat_e(x1,),lat_e(x1-1,)]=connect_left_e
        sys[lat_h(x1,),lat_h(x1-1,)]=connect_left_h

    # connect WSM to right SC
    if wx_sc_right>0:
        sys[lat_e(x2,),lat_e(x2-1,)]=connect_right_e
        sys[lat_h(x2,),lat_h(x2-1,)]=connect_right_h
        

        
    # finalize the system
    fsys = sys.finalized()

    # plot lattice and hoppings if desired
    if plot_sys:
        #plot_system(sys,fsys,p,12,1)
        fig, (ax11) = plt.subplots(1,1,figsize=(12,1) )
        kwant.plotter.plot( sys,ax=ax11 )
    
    return fsys







def make_finite_1D_sns_junction_2( wx_sc_left,wx_wsm,wx_sc_right,plot_sys=False,p=None ):

    # graphene sc
    def sc_hop_x_e( site2,site1,p ):
        return 0.5j*p.met_tx*s0s1
    def sc_hop_x_h( site2,site1,p):
        return -sc_hop_x_e(site2,site1,p)
    def sc_onsite_e( site,p ):
        return -p.met_mu*s0s0-p.met_ty*np.sin(p.ky)*s0s2
    def sc_onsite_h( site,p ):
        return -sc_onsite_e(site,p)
    def sc_pairing( site2,site1,p ):
        return p.Delta*s0s0
    
    # get models
    model_wsm = weyl_SC.WeylSC1D_x()
    #model_msc = weyl_SC.MetallicSC1D_x()

    # lattices
    lat_e = model_wsm.lat_e
    lat_h = model_wsm.lat_h

    # builder
    sys = kwant.Builder()

    # first, define all sites and their onsite energies
    x1=wx_sc_left; x2=x1+wx_wsm; x3=x2+wx_sc_right

    # a) SC (left)
    for nx in range(x1):
        sys[lat_e(nx,)]=sc_onsite_e
        sys[lat_h(nx,)]=sc_onsite_h
        sys[lat_h(nx,),lat_e(nx,)]=sc_pairing

    # b) WSM (left)
    for nx in range(x1,x2):
        sys[lat_e(nx,)]=model_wsm.onsite_e
        sys[lat_h(nx,)]=model_wsm.onsite_h
        
    # c) SC (right)
    for nx in range(x2,x3):
        sys[lat_e(nx,)]=sc_onsite_e
        sys[lat_h(nx,)]=sc_onsite_h
        sys[lat_h(nx,),lat_e(nx,)]=sc_pairing
        
    # second, set the hoppings
    # a) sc left
    for nx in range(x1):
        sys[lat_e(nx+1,),lat_e(nx,)]=sc_hop_x_e
        sys[lat_h(nx+1,),lat_h(nx,)]=sc_hop_x_h
        
    # b) WSM
    for nx in range(x1,x2-1):
        sys[lat_e(nx+1,),lat_e(nx,)]=model_wsm.hop_e
        sys[lat_h(nx+1,),lat_h(nx,)]=model_wsm.hop_h
    
    # c) barrier and sc hoppings
    for nx in range(x2-1,x3-1):
        sys[lat_e(nx+1,),lat_e(nx,)]=sc_hop_x_e
        sys[lat_h(nx+1,),lat_h(nx,)]=sc_hop_x_h

    # finalize the system
    fsys = sys.finalized()

    # plot lattice and hoppings if desired
    if plot_sys:
        plot_system(sys,fsys,p,12,1)        
    
    return fsys



    
""" 1.1d WSM lead """
def make_weyl_lead_x( Wy ):

    # get model
    model_wsm = weyl_SC.WeylSC2D_xy()

    # lattices
    lat_e = model_wsm.lat_e
    lat_h = model_wsm.lat_h

    # builder
    wsm_lead  = kwant.Builder(  kwant.TranslationalSymmetry( (1,0) )  )

    # wsm lead
    for ny in range(Wy):
        wsm_lead[lat_e(0,ny)]=model_wsm.onsite_e
        wsm_lead[lat_h(0,ny)]=model_wsm.onsite_h
        wsm_lead[lat_e(1,ny),lat_e(0,ny)]=model_wsm.hop_e
        wsm_lead[lat_h(1,ny),lat_h(0,ny)]=model_wsm.hop_h
        if ny>0:
            wsm_lead[lat_e(0,ny),lat_e(0,ny-1)]=model_wsm.hop_e
            wsm_lead[lat_h(0,ny),lat_h(0,ny-1)]=model_wsm.hop_h

    # finalize the system
    flead_kx = wsm_lead.finalized()

    return flead_kx



""" 1.2 effective 2D """

""" 1.2a infinite N-S junction """
def make_infinite_2D_ns_junction( Wx,Wy,pbc_y,plot_sys=False ):
        
    # get models
    model_wsm = weyl_SC.WeylSC2D_xy()
    model_msc = weyl_SC.MetallicSC2D_xy()

    # lattices
    lat_e = model_wsm.lat_e
    lat_h = model_wsm.lat_h

    # builder
    sys = kwant.Builder()
    wsm_lead_e = kwant.Builder(  kwant.TranslationalSymmetry( (-1,0) )  )
    wsm_lead_h = kwant.Builder(  kwant.TranslationalSymmetry( (-1,0) )  )
    sc_lead  = kwant.Builder(  kwant.TranslationalSymmetry( (+1,0) )  )

    # system
    for nx in range(Wx):
        for ny in range(Wy):
            sys[lat_e(nx,ny)]=model_wsm.onsite_e
            sys[lat_h(nx,ny)]=model_wsm.onsite_h
    for nx in range(Wx-1):
        for ny in range(Wy):
            sys[lat_e(nx+1,ny),lat_e(nx,ny)]=model_wsm.hop_e
            sys[lat_h(nx+1,ny),lat_h(nx,ny)]=model_wsm.hop_h
    for nx in range(Wx):
        for ny in range(Wy-1):
            sys[lat_e(nx,ny+1),lat_e(nx,ny)]=model_wsm.hop_e
            sys[lat_h(nx,ny+1),lat_h(nx,ny)]=model_wsm.hop_h
        if pbc_y:
            sys[lat_e(nx,0),lat_e(nx,Wy-1)]=model_wsm.hop_e
            sys[lat_h(nx,0),lat_h(nx,Wy-1)]=model_wsm.hop_h

    # wsm lead
    for ny in range(Wy):
        wsm_lead_e[lat_e(0,ny)]=model_wsm.onsite_e
        wsm_lead_h[lat_h(0,ny)]=model_wsm.onsite_h
        wsm_lead_e[lat_e(1,ny),lat_e(0,ny)]=model_wsm.hop_e
        wsm_lead_h[lat_h(1,ny),lat_h(0,ny)]=model_wsm.hop_h
    for ny in range(Wy-1):
         wsm_lead_e[lat_e(0,ny+1),lat_e(0,ny)]=model_wsm.hop_e
         wsm_lead_h[lat_h(0,ny+1),lat_h(0,ny)]=model_wsm.hop_h
    if pbc_y:
         wsm_lead_e[lat_e(0,0),lat_e(0,Wy-1)]=model_wsm.hop_e
         wsm_lead_h[lat_h(0,0),lat_h(0,Wy-1)]=model_wsm.hop_h
    
    # sc lead
    for ny in range(Wy):
        sc_lead[lat_e(0,ny)]=model_msc.onsite_e
        sc_lead[lat_h(0,ny)]=model_msc.onsite_h
        sc_lead[lat_h(0,ny),lat_e(0,ny)]=model_msc.pairing
        sc_lead[lat_e(1,ny),lat_e(0,ny)]=model_msc.hop_e
        sc_lead[lat_h(1,ny),lat_h(0,ny)]=model_msc.hop_h
    for ny in range(Wy-1):
        sc_lead[lat_e(0,ny+1),lat_e(0,ny)]=model_msc.hop_e
        sc_lead[lat_h(0,ny+1),lat_h(0,ny)]=model_msc.hop_h
    if pbc_y:
        sc_lead[lat_e(0,0),lat_e(0,Wy-1)]=model_msc.hop_e
        sc_lead[lat_h(0,0),lat_h(0,Wy-1)]=model_msc.hop_h
    
    
    # finalize the system
    sys.attach_lead( wsm_lead_e )
    sys.attach_lead( wsm_lead_h )
    sys.attach_lead( sc_lead )
    fsys = sys.finalized()

    # plot lattice and hoppings if desired
    if plot_sys:
        plot_system(sys,fsys,p,8,8)
            
    return fsys



""" 1.1c finite 1D SC-WSM-SC junction """
def make_finite_2D_sns_junction__xy( wx_sc_left,wx_wsm,wx_sc_right,wy,plot_sys=False,p=None ):

    # get models
    model_wsm = weyl_SC.WeylSC2D_xy()
    #if hasattr( p,'met_D_L') and hasattr( p,'met_D_R' ):
    #    model_msc_L = weyl_SC.MetallicSC2D_xz( params=SimpleNamespace(met_D=p.met_D_L) )
    #    model_msc_R = weyl_SC.MetallicSC2D_xz( params=SimpleNamespace(met_D=p.met_D_R) )
    #else:
    model_msc_L = weyl_SC.MetallicSC2D_xy()
    model_msc_R = weyl_SC.MetallicSC2D_xy()
    #print model_msc_R.params

    # lattices
    lat_e = model_wsm.lat_e
    lat_h = model_wsm.lat_h

    # builder
    sys = kwant.Builder()

    # first, define all sites and their onsite energies
    x1=wx_sc_left; x2=x1+wx_wsm; x3=x2+wx_sc_right

    # a) SC (left)
    for nx in range(x1):
        for ny in range(wy):
            sys[lat_e(nx,ny)]=model_msc_L.onsite_e
            sys[lat_h(nx,ny)]=model_msc_L.onsite_h
            sys[lat_h(nx,ny),lat_e(nx,ny)]=model_msc_L.pairing

    # b) WSM (left)
    for nx in range(x1,x2):
        for ny in range(wy):
            sys[lat_e(nx,ny)]=model_wsm.onsite_e
            sys[lat_h(nx,ny)]=model_wsm.onsite_h
        
    # c) SC (right)
    for nx in range(x2,x3):
        for ny in range(wy):
            sys[lat_e(nx,ny)]=model_msc_R.onsite_e
            sys[lat_h(nx,ny)]=model_msc_R.onsite_h
            sys[lat_h(nx,ny),lat_e(nx,ny)]=model_msc_R.pairing
        
    # second, set the hoppings in x-direction
    # a) sc left
    for nx in range(x1):
        for ny in range(wy):
            sys[lat_e(nx+1,ny),lat_e(nx,ny)]=model_msc_L.hop_e
            sys[lat_h(nx+1,ny),lat_h(nx,ny)]=model_msc_L.hop_h
        
    # b) WSM
    for nx in range(x1,x2-1):
        for ny in range(wy):
            sys[lat_e(nx+1,ny),lat_e(nx,ny)]=model_wsm.hop_e
            sys[lat_h(nx+1,ny),lat_h(nx,ny)]=model_wsm.hop_h
    
    # c) barrier and sc hoppings
    for nx in range(x2-1,x3-1):
        for ny in range(wy):
            sys[lat_e(nx+1,ny),lat_e(nx,ny)]=model_msc_R.hop_e
            sys[lat_h(nx+1,ny),lat_h(nx,ny)]=model_msc_R.hop_h

    # second, set the hoppings
    # a) sc left
    for nx in range(x1):
        for ny in range(wy-1):
            sys[lat_e(nx,ny+1),lat_e(nx,ny)]=model_msc_L.hop_e
            sys[lat_h(nx,ny+1),lat_h(nx,ny)]=model_msc_L.hop_h
        
    # b) WSM
    for nx in range(x1,x2):
        for ny in range(wy-1):
            sys[lat_e(nx,ny+1),lat_e(nx,ny)]=model_wsm.hop_e
            sys[lat_h(nx,ny+1),lat_h(nx,ny)]=model_wsm.hop_h
    
    # c) barrier and sc hoppings
    for nx in range(x2,x3):
        for ny in range(wy-1):
            sys[lat_e(nx,ny+1),lat_e(nx,ny)]=model_msc_R.hop_e
            sys[lat_h(nx,ny+1),lat_h(nx,ny)]=model_msc_R.hop_h
            

    # finalize the system
    fsys = sys.finalized()

    # plot lattice and hoppings if desired
    if plot_sys:
        plot_system(sys,fsys,p,12,5)        
    
    return fsys


""" 1.1c finite 1D SC-WSM-SC junction """
def make_finite_2D_sns_junction( wx_sc_left,wx_wsm,wx_sc_right,wz,plot_sys=False,p=None ):

    # get models
    model_wsm = weyl_SC.WeylSC2D_xz()
    #if hasattr( p,'met_D_L') and hasattr( p,'met_D_R' ):
    #    model_msc_L = weyl_SC.MetallicSC2D_xz( params=SimpleNamespace(met_D=p.met_D_L) )
    #    model_msc_R = weyl_SC.MetallicSC2D_xz( params=SimpleNamespace(met_D=p.met_D_R) )
    #else:
    model_msc_L = weyl_SC.MetallicSC2D_xz()
    model_msc_R = weyl_SC.MetallicSC2D_xz()
    #print model_msc_R.params

    # hotfix
    def sc_hop_z_e( s2,s1,p ):
        x1,z1=s1.pos
        x2,z2=s2.pos
        zavg=(z1+z2)/2.
        met_tz =get_var(self.params,p,'met_tz')
        met_tz_special =get_var(self.params,p,'met_tz_special')
        return -0.5*met_tz*s0s0 -0.5*met_tz_special*zavg*s0s0

    def sc_hop_z_h( site2,site1,p ):
        return -sc_hop_z_e(site2,site1,p)
        
    # lattices
    lat_e = model_wsm.lat_e
    lat_h = model_wsm.lat_h

    # builder
    sys = kwant.Builder()

    # first, define all sites and their onsite energies
    x1=wx_sc_left; x2=x1+wx_wsm; x3=x2+wx_sc_right

    # a) SC (left)
    for nx in range(x1):
        for nz in range(wz):
            sys[lat_e(nx,nz)]=model_msc_L.onsite_e
            sys[lat_h(nx,nz)]=model_msc_L.onsite_h
            sys[lat_h(nx,nz),lat_e(nx,nz)]=model_msc_L.pairing

    # b) WSM (left)
    for nx in range(x1,x2):
        for nz in range(wz):
            sys[lat_e(nx,nz)]=model_wsm.onsite_e
            sys[lat_h(nx,nz)]=model_wsm.onsite_h
        
    # c) SC (right)
    for nx in range(x2,x3):
        for nz in range(wz):
            sys[lat_e(nx,nz)]=model_msc_R.onsite_e
            sys[lat_h(nx,nz)]=model_msc_R.onsite_h
            sys[lat_h(nx,nz),lat_e(nx,nz)]=model_msc_R.pairing
        
    # second, set the hoppings in x-direction
    # a) sc left
    for nx in range(x1):
        for nz in range(wz):
            sys[lat_e(nx+1,nz),lat_e(nx,nz)]=model_msc_L.hop_e
            sys[lat_h(nx+1,nz),lat_h(nx,nz)]=model_msc_L.hop_h
        
    # b) WSM
    for nx in range(x1,x2-1):
        for nz in range(wz):
            sys[lat_e(nx+1,nz),lat_e(nx,nz)]=model_wsm.hop_e
            sys[lat_h(nx+1,nz),lat_h(nx,nz)]=model_wsm.hop_h
    
    # c) barrier and sc hoppings
    for nx in range(x2-1,x3-1):
        for nz in range(wz):
            sys[lat_e(nx+1,nz),lat_e(nx,nz)]=model_msc_R.hop_e
            sys[lat_h(nx+1,nz),lat_h(nx,nz)]=model_msc_R.hop_h

    # second, set the hoppings
    # a) sc left
    for nx in range(x1):
        for nz in range(wz-1):
            sys[lat_e(nx,nz+1),lat_e(nx,nz)]=sc_hop_z_e#model_msc_L.hop_e
            sys[lat_h(nx,nz+1),lat_h(nx,nz)]=sc_hop_z_h#model_msc_L.hop_h
        
    # b) WSM
    for nx in range(x1,x2):
        for nz in range(wz-1):
            sys[lat_e(nx,nz+1),lat_e(nx,nz)]=model_wsm.hop_e
            sys[lat_h(nx,nz+1),lat_h(nx,nz)]=model_wsm.hop_h
    
    # c) barrier and sc hoppings
    for nx in range(x2,x3):
        for nz in range(wz-1):
            sys[lat_e(nx,nz+1),lat_e(nx,nz)]=sc_hop_z_e#model_msc_R.hop_e
            sys[lat_h(nx,nz+1),lat_h(nx,nz)]=sc_hop_z_h#model_msc_R.hop_h
            

    # finalize the system
    fsys = sys.finalized()

    # plot lattice and hoppings if desired
    if plot_sys:
        plot_system(sys,fsys,p,12,5)        
    
    return fsys



""" 1.2a infinite N-S junction """
def make_infinite_xz_ns_junction( Wx,Wz,pbc_x,plot_sys=False,p=None ):
        
    # get models
    model_wsm = weyl_SC.WeylSC2D_xz()
    model_msc = weyl_SC.MetallicSC2D_xz()

    # lattices
    lat_e = model_wsm.lat_e
    lat_h = model_wsm.lat_h

    # builder
    sys = kwant.Builder()
    wsm_lead_e = kwant.Builder(  kwant.TranslationalSymmetry( (0,-1) )  )
    wsm_lead_h = kwant.Builder(  kwant.TranslationalSymmetry( (0,-1) )  )
    sc_lead    = kwant.Builder(  kwant.TranslationalSymmetry( (0,+1) )  )

    # system
    for nz in range(Wz):
        for nx in range(Wx):
            sys[lat_e(nx,nz)]=model_wsm.onsite_e
            sys[lat_h(nx,nz)]=model_wsm.onsite_h
    # x-hoppings
    for nz in range(Wz):
        for nx in range(Wx-1):
            sys[lat_e(nx+1,nz),lat_e(nx,nz)]=model_wsm.hop_e
            sys[lat_h(nx+1,nz),lat_h(nx,nz)]=model_wsm.hop_h
        if pbc_x:
            sys[lat_e(0,nz),lat_e(Wx-1,nz)]=model_wsm.hop_e
            sys[lat_h(0,nz),lat_h(Wx-1,nz)]=model_wsm.hop_h
    # z-hoppings
    for nx in range(Wx):
        for nz in range(Wz-1):
            sys[lat_e(nx,nz+1),lat_e(nx,nz)]=model_wsm.hop_e
            sys[lat_h(nx,nz+1),lat_h(nx,nz)]=model_wsm.hop_h

    # wsm lead
    for nx in range(Wx):
        wsm_lead_e[lat_e(nx,0)]=model_wsm.onsite_e
        wsm_lead_h[lat_h(nx,0)]=model_wsm.onsite_h
        wsm_lead_e[lat_e(nx,1),lat_e(nx,0)]=model_wsm.hop_e
        wsm_lead_h[lat_h(nx,1),lat_h(nx,0)]=model_wsm.hop_h
    for nx in range(Wx-1):
         wsm_lead_e[lat_e(nx+1,0),lat_e(nx,0)]=model_wsm.hop_e
         wsm_lead_h[lat_h(nx+1,0),lat_h(nx,0)]=model_wsm.hop_h
    if pbc_x:
         wsm_lead_e[lat_e(0,0),lat_e(Wx-1,0)]=model_wsm.hop_e
         wsm_lead_h[lat_h(0,0),lat_h(Wx-1,0)]=model_wsm.hop_h
    
    # sc lead
    for nx in range(Wx):
        sc_lead[lat_e(nx,0)]=model_msc.onsite_e
        sc_lead[lat_h(nx,0)]=model_msc.onsite_h
        sc_lead[lat_h(nx,0),lat_e(nx,0)]=model_msc.pairing
        sc_lead[lat_e(nx,1),lat_e(nx,0)]=model_msc.hop_e
        sc_lead[lat_h(nx,1),lat_h(nx,0)]=model_msc.hop_h
    for nx in range(Wx-1):
        sc_lead[lat_e(nx+1,0),lat_e(nx,0)]=model_msc.hop_e
        sc_lead[lat_h(nx+1,0),lat_h(nx,0)]=model_msc.hop_h
    if pbc_x:
        sc_lead[lat_e(0,0),lat_e(Wx-1,0)]=model_msc.hop_e
        sc_lead[lat_h(0,0),lat_h(Wx-1,0)]=model_msc.hop_h
    
    
    # finalize the system
    sys.attach_lead( wsm_lead_e )
    sys.attach_lead( wsm_lead_h )
    sys.attach_lead( sc_lead )
    fsys = sys.finalized()

    # plot lattice and hoppings if desired
    if plot_sys:
        plot_system(sys,fsys,p,8,3)
            
    return fsys


""" 1.2b SC coated WSM wire """
def make_coated_wire_xy(R1,R2,plot_sys=False,p=None):

    # shape
    margin=10**(-3)
    def disk( x,y,R ):
        if x**2+y**2<R**2-margin:
            return True
        else:
            return False
    
    # get model
    model_wsm = weyl_SC.WeylSC2D_xy()
    model_sc  = weyl_SC.MetallicSC2D_xy()

    # lattices
    lat_e = model_wsm.lat_e
    lat_h = model_wsm.lat_h

    # builder
    sys = kwant.Builder()

    # onsite energies
    for nx in range(-R2,R2+1):
        for ny in range(-R2,R2+1):
            if disk(nx,ny,R1):
                sys[lat_e(nx,ny)]=model_wsm.onsite_e
                sys[lat_h(nx,ny)]=model_wsm.onsite_h
            elif disk(nx,ny,R2):
                sys[lat_e(nx,ny)]=model_sc.onsite_e
                sys[lat_h(nx,ny)]=model_sc.onsite_h
                sys[lat_h(nx,ny),lat_e(nx,ny)]=model_sc.pairing

    # hoppings
    for nx in range(-R2,R2+1):
        for ny in range(-R2,R2+1):
            if disk(nx,ny,R1):
                if disk(nx+1,ny,R1):
                    sys[lat_e(nx+1,ny),lat_e(nx,ny)]=model_wsm.hop_e
                    sys[lat_h(nx+1,ny),lat_h(nx,ny)]=model_wsm.hop_h
                if disk(nx,ny+1,R1):
                    sys[lat_e(nx,ny+1),lat_e(nx,ny)]=model_wsm.hop_e
                    sys[lat_h(nx,ny+1),lat_h(nx,ny)]=model_wsm.hop_h
                if disk(nx+1,ny,R2) and not disk(nx+1,ny,R1):
                    sys[lat_e(nx+1,ny),lat_e(nx,ny)]=model_sc.hop_e
                    sys[lat_h(nx+1,ny),lat_h(nx,ny)]=model_sc.hop_h
                if disk(nx,ny+1,R2) and not disk(nx,ny+1,R1):
                    sys[lat_e(nx,ny+1),lat_e(nx,ny)]=model_sc.hop_e
                    sys[lat_h(nx,ny+1),lat_h(nx,ny)]=model_sc.hop_h
            
            elif disk(nx,ny,R2):
                if disk(nx+1,ny,R2):
                    sys[lat_e(nx+1,ny),lat_e(nx,ny)]=model_sc.hop_e
                    sys[lat_h(nx+1,ny),lat_h(nx,ny)]=model_sc.hop_h
                if disk(nx,ny+1,R2):
                    sys[lat_e(nx,ny+1),lat_e(nx,ny)]=model_sc.hop_e
                    sys[lat_h(nx,ny+1),lat_h(nx,ny)]=model_sc.hop_h

    fsys = sys.finalized()
                    
    if plot_sys:
        plot_system(sys,fsys,p,8,8)

    return fsys



""" 1.2b SC coated WSM wire """
def make_coated_wire_xy_2(R1,R2,plot_sys=False,p=None):

    # shape
    margin=10**(-3)
    def disk( x,y,R ):
        if x**2+y**2<R**2-margin:
            return True
        else:
            return False

        
    # get model
    model_wsm = weyl_SC.WeylSC2D_xy()
    model_sc  = weyl_SC.MetallicSC2D_xy()

    # lattices
    lat_e = model_wsm.lat_e
    lat_h = model_wsm.lat_h

    # builder
    sys = kwant.Builder()

    # onsite energies
    for nx in range(-R2,R2+1):
        for ny in range(-R2,R2+1):
            if disk(nx,ny,R1):
                sys[lat_e(nx,ny)]=model_wsm.onsite_e
                sys[lat_h(nx,ny)]=model_wsm.onsite_h
            elif disk(nx,ny,R2):
                sys[lat_e(nx,ny)]=model_sc.onsite_e
                sys[lat_h(nx,ny)]=model_sc.onsite_h
                sys[lat_h(nx,ny),lat_e(nx,ny)]=model_sc.pairing

    # hoppings
    for nx in range(-R2,R2+1):
        for ny in range(-R2,R2+1):
            if disk(nx,ny,R1):
                if disk(nx+1,ny,R1):
                    sys[lat_e(nx+1,ny),lat_e(nx,ny)]=model_wsm.hop_e
                    sys[lat_h(nx+1,ny),lat_h(nx,ny)]=model_wsm.hop_h
                if disk(nx,ny+1,R1):
                    sys[lat_e(nx,ny+1),lat_e(nx,ny)]=model_wsm.hop_e
                    sys[lat_h(nx,ny+1),lat_h(nx,ny)]=model_wsm.hop_h
                if disk(nx+1,ny,R2) and not disk(nx+1,ny,R1):
                    sys[lat_e(nx+1,ny),lat_e(nx,ny)]=model_sc.hop_e
                    sys[lat_h(nx+1,ny),lat_h(nx,ny)]=model_sc.hop_h
                if disk(nx,ny+1,R2) and not disk(nx,ny+1,R1):
                    sys[lat_e(nx,ny+1),lat_e(nx,ny)]=model_sc.hop_e
                    sys[lat_h(nx,ny+1),lat_h(nx,ny)]=model_sc.hop_h
            
            elif disk(nx,ny,R2):
                if disk(nx+1,ny,R2):
                    sys[lat_e(nx+1,ny),lat_e(nx,ny)]=model_sc.hop_e
                    sys[lat_h(nx+1,ny),lat_h(nx,ny)]=model_sc.hop_h
                if disk(nx,ny+1,R2):
                    sys[lat_e(nx,ny+1),lat_e(nx,ny)]=model_sc.hop_e
                    sys[lat_h(nx,ny+1),lat_h(nx,ny)]=model_sc.hop_h

    fsys = sys.finalized()
                    
    if plot_sys:
        plot_system(sys,fsys,p,8,8)

    return fsys





""" 1.2b SC coated WSM wire """
def graphene_SNS_x(L,M,R,plot_sys=False,q=None):

    # graphene 
    def g_hop_x_e( site2,site1,p ):
        return -0.5j*p.tx*sigma1
    def g_hop_x_h( site2,site1,p):
        return -g_hop_x_e(site2,site1,p)
    def g_onsite_e( site,p ):
        return -p.mu*sigma0-p.ty*np.sin(p.ky)*sigma2
    def g_onsite_h( site,p ):
        return -g_onsite_e(site,p)

    # sc
    def sc_hop_x_e( site2,site1,p ):
        return 0.5j*p.met_tx*sigma1
    def sc_hop_x_h( site2,site1,p):
        return -sc_hop_x_e(site2,site1,p)
    def sc_onsite_e( site,p ):
        return -p.met_mu*sigma0-p.met_ty*np.sin(p.ky)*sigma2
    def sc_onsite_h( site,p ):
        return -sc_onsite_e(site,p)
    def sc_pairing( site2,site1,p ):
        return p.Delta*sigma0

    lat_e = kwant.lattice.general( ( (1,), ), name='e' )
    lat_h = kwant.lattice.general( ( (1,), ), name='h' )

    # builder
    sys = kwant.Builder()


    # first, define all sites and their onsite energies
    x1=L
    x2=L+M
    x3=L+M+R

    # a) SC (left)
    for nx in range(x1):
        sys[lat_e(nx,)]=sc_onsite_e
        sys[lat_h(nx,)]=sc_onsite_h
        sys[lat_h(nx,),lat_e(nx,)]=sc_pairing

    # b) WSM (left)
    for nx in range(x1,x2):
        sys[lat_e(nx,)]=g_onsite_e
        sys[lat_h(nx,)]=g_onsite_h
        
    # c) SC (right)
    for nx in range(x2,x3):
        sys[lat_e(nx,)]=sc_onsite_e
        sys[lat_h(nx,)]=sc_onsite_h
        sys[lat_h(nx,),lat_e(nx,)]=sc_pairing
        
    # second, set the hoppings
    # a) sc left
    for nx in range(x1):
        sys[lat_e(nx+1,),lat_e(nx,)]=sc_hop_x_e
        sys[lat_h(nx+1,),lat_h(nx,)]=sc_hop_x_h
        
    # b) WSM
    for nx in range(x1,x2-1):
        sys[lat_e(nx+1,),lat_e(nx,)]=g_hop_x_e
        sys[lat_h(nx+1,),lat_h(nx,)]=g_hop_x_h
    
    # c) barrier and sc hoppings
    for nx in range(x2-1,x3-1):
        sys[lat_e(nx+1,),lat_e(nx,)]=sc_hop_x_e
        sys[lat_h(nx+1,),lat_h(nx,)]=sc_hop_x_h

    # finalize the system
    fsys = sys.finalized()

    # plot lattice and hoppings if desired
    if plot_sys:
        plot_system(sys,fsys,q,12,1)        
    
    return fsys




""" 2. SPECTRA AND WAVE FUNCTIONS """

""" 2.1 low energy spectrum as function of kz """
def get_low_en_spec(fsys,p,no_evals=8,eh_colors=False):
    ham_sparse_coo = fsys.hamiltonian_submatrix( args=([p]),sparse=True )
    ham_sparse = ham_sparse_coo.tocsc()

    if not eh_colors:
        # get at least all evals in interval
        try:
            evals = lag.eigsh( ham_sparse,k=no_evals,return_eigenvectors=False,which='LM',sigma=0, tol=10**(-6) )
        except:
            evals = lag.eigsh( ham_sparse,k=no_evals,return_eigenvectors=False,which='LM',sigma=10**(-6), tol=10**(-6) )
        return evals
    else:
        try:
            evals,evecsT = lag.eigsh( ham_sparse,k=no_evals,return_eigenvectors=True,which='LM',sigma=0, tol=10**(-6) )
        except:
            evals,evecsT = lag.eigsh( ham_sparse,k=no_evals,return_eigenvectors=True,which='LM',sigma=10**(-6), tol=10**(-6) )
        evecs=evecsT.T

        # lets color them
        sites=[ s.pos[0] for s in fsys.sites ]
        families=[ s.family.name for s in fsys.sites ]
        # separate bulk from vacuum-wsm and wsm-sc edge states
        ens=[]; polarizations=[];
        for n in range(no_evals):
            
            wf=np.reshape(evecs[n],(len(sites),4))
            en=evals[n]
            e_w,h_w=get_e_h_weights(wf,families)

            ens.append(en)
            polarizations.append(e_w-h_w)

        return {'ens':ens,'pols':polarizations}


"""2.2 low energy spectrum for finite effective 1D N-s junction. The
surface states are separated from the bulk states and also gives
information about the electron-hole polarization

"""
def calc_low_en_spec_special(fsys,p,wx_wsm,no_states=10):
    ham_sparse_coo = fsys.hamiltonian_submatrix( args=([p]),sparse=True )
    ham_sparse = ham_sparse_coo.tocsc()
    evals,evecsT = lag.eigsh( ham_sparse,k=no_states,return_eigenvectors=True, \
                              which='LM',sigma=0, tol=10**(-3) )
    evecs=evecsT.T

    sites=[ s.pos[0] for s in fsys.sites ]
    families=[ s.family.name for s in fsys.sites ]
    # separate bulk from vacuum-wsm and wsm-sc edge states
    ens_bulk=[];ens_left=[];ens_interface=[];mixings1=[];mixings2=[]
    for n in range(no_states):
            
            wf=np.reshape(evecs[n],(len(sites),4))
            en=evals[n]

            loc_left=is_localized_state(wf,sites,range(0,4),treshold=.4 )
            loc_int =is_localized_state(wf,sites,range(wx_wsm-4,wx_wsm+3),treshold=.3 )
            
            if loc_left and loc_int:
                e_w,h_w=get_e_h_weights(wf,families)
                ens_bulk.append(None)
                ens_left.append(en)
                ens_interface.append(en)
                mixings1.append( np.real(e_w-h_w) )
                mixings2.append( np.real(e_w-h_w) )
            elif loc_left:
                e_w,h_w=get_e_h_weights(wf,families)
                ens_bulk.append(None)
                ens_left.append(en)
                ens_interface.append(None)
                mixings1.append( np.real(e_w-h_w) )
                mixings2.append( None )
            elif loc_int:
                e_w,h_w=get_e_h_weights(wf,families)

                ens_bulk.append(None)
                ens_left.append(None)
                ens_interface.append(en)
                mixings1.append( None )
                mixings2.append( np.real(e_w-h_w) )
            else:
                ens_bulk.append(en)
                ens_left.append(None)
                ens_interface.append(None)
                mixings1.append( None )
                mixings2.append( None )
    return {"bulk":sorted(ens_bulk),"vac_wsm":sorted(ens_left),"wsm_sc":sorted(ens_interface), \
            "vac_wsm_mixing":mixings1,"wsm_sc_mixing":mixings2}


""" 2.3 calculates the surface states only for finite effective 1D N-S junction"""
def get_surface_states(fsys,p,wx_wsm,no_states=10):
    ham_sparse_coo = fsys.hamiltonian_submatrix( args=([p]),sparse=True )
    ham_sparse = ham_sparse_coo.tocsc()
    evals,evecsT = lag.eigsh( ham_sparse,k=no_states,return_eigenvectors=True,which='LM',sigma=0, tol=10**(-3) )
    evecs=evecsT.T

    sites=[ s.pos[0] for s in fsys.sites ]
    families=[ s.family.name for s in fsys.sites ]
    # separate bulk from vacuum-wsm and wsm-sc edge states
    surf_states=[]
    for n in range(no_states):
            
            wf=np.reshape(evecs[n],(len(sites),4))
            en=evals[n]

            loc_left=is_localized_state(wf,sites,range(0,4),treshold=.4 )
            loc_int =is_localized_state(wf,sites,range(wx_wsm-4,wx_wsm+3),treshold=.3 )

            if loc_left or loc_int:
                surf_states.append( {'en':en,'wf':wf} )
                
    return sites,families,surf_states


""" 2.4 check if state is localized at certain sites """
def is_localized_state(wf,sites,hotsites,treshold=.4):
    no_sites = len(wf)
    s_max=max(sites)
    
    norm = np.vdot(wf,wf)
    #print norm
    weights = [ np.vdot(v,v)/norm for v in wf ]
    
    # boundary weight is the combined weight on the outermost 5 sites
    hot_weights = []
    for n in range(no_sites):
        if sites[n] in hotsites:
            hot_weights.append( weights[n] )
    
    hot_weight=sum(hot_weights)
    if hot_weight>treshold:
        #plt.plot(sites,weights,'r.')
        #plt.show()
        #print hot_weight
        return True
    else:
        return False

""" 2.5 get the electron-hole polarization of a wave function """
def get_e_h_weights(wf,families):
    no_sites = len(wf)
       
    norm = np.vdot(wf,wf)
    weights = [ np.vdot(v,v)/norm for v in wf ]

    e_weight=0; h_weight=0;
    for n in range(no_sites):
        if families[n]=='e':
            e_weight+=weights[n]
        elif families[n]=='h':
            h_weight+=weights[n]
    #print e_weight,h_weight
    if abs(e_weight+h_weight-1)>10**(-3):
        raise ValueError( "The sum of electron and hole weights is not 1" )

    return e_weight,h_weight



""" 3. TRANSPORT """

""" 3.1 get_s_matrix """
def get_s_matrix( fsys,p,eF ):

    S  = kwant.smatrix( fsys,args=([p]), energy=eF )

    # get lead info
    leads = S.lead_info
    lead_e = leads[0]
    lead_h = leads[1]
    lead_sc = leads[2]

#    lead_e_sites = [ s.pos[1] for s in fsys.leads[0].sites if s.pos[0]==0 ]
#    lead_h_sites = [ s.pos[1] for s in fsys.leads[1].sites if s.pos[0]==0 ]
    lead_e_sites = [ s.pos[0] for s in fsys.leads[0].sites if s.pos[1]==0 ]
    lead_h_sites = [ s.pos[0] for s in fsys.leads[1].sites if s.pos[1]==0 ]

    print lead_e,lead_e_sites
    
    #return lead_e,lead_e_sites
    e_in, e_out = split_lead( lead_e,lead_e_sites )
    h_in, h_out = split_lead( lead_h,lead_h_sites )
    
    return { "lead_info": {"lead_e":{"sites":lead_e_sites,"in":e_in,"out":e_out},
                           "lead_h":{"sites":lead_h_sites,"in":h_in,"out":h_out}},
             "smatrix_ee":S.submatrix(0,0),
             "smatrix_eh":S.submatrix(1,0) }

""" 3.2 get_resolved_probs """
def get_resolved_probs(s_matrix_detailed):
    smd = s_matrix_detailed

    lead_info =smd['lead_info']
    smatrix_ee=smd['smatrix_ee']
    smatrix_eh=smd['smatrix_eh']

    P_ee, P_eh = get_reflection_probs( smatrix_ee,smatrix_eh,lead_info['lead_e'],lead_info['lead_h'] )

    return P_ee,P_eh


""" 3.3 get_reflection_probs """
def get_reflection_probs(S_ee,S_eh,lead_e,lead_h,k0=0):

    P_ee = {"bulk_bulk":0,"bulk_surf":0,"surf_bulk":0,"surf_surf":0 }
    P_eh = {"bulk_bulk":0,"bulk_surf":0,"surf_bulk":0,"surf_surf":0 }
        
    for ni in lead_e['in']['bulk']:
        for no in lead_e['out']['bulk']:
            P_ee["bulk_bulk"]+=abs(S_ee[no,ni])**2
        for no in lead_e['out']['surf']:
            P_ee["bulk_surf"]+=abs(S_ee[no,ni])**2
        for no in lead_h['out']['bulk']:
            P_eh["bulk_bulk"]+=abs(S_eh[no,ni])**2
        for no in lead_h['out']['surf']:
            P_eh["bulk_surf"]+=abs(S_eh[no,ni])**2
        
    for ni in lead_e['in']['surf']:
        for no in lead_e['out']['bulk']:
            P_ee["surf_bulk"]+=abs(S_ee[no,ni])**2
        for no in lead_e['out']['surf']:
            P_ee["surf_surf"]+=abs(S_ee[no,ni])**2
        for no in lead_h['out']['bulk']:
            P_eh["surf_bulk"]+=abs(S_eh[no,ni])**2
        for no in lead_h['out']['surf']:
            P_eh["surf_surf"]+=abs(S_eh[no,ni])**2
            
    return P_ee, P_eh
       
    
""" 3.4 split_lead """
def split_lead( lead,sites,k0=0 ):

    # info about propagating modes
    no_sites = len(sites)
    vels = lead.velocities
    moms = lead.momenta
    wfsT = lead.wave_functions
    wfs  = wfsT.transpose()
    print len(wfs),len(wfs[0]),no_sites
    nhalf = int(len(vels)/2)

    # container for results
    in_dict  = {"bulk":[],"surf":[]}
    out_dict = {"bulk":[],"surf":[]}

    for i in range(len(vels)):
        v=vels[i]
        k=moms[i]
        wf = np.reshape(wfs[i],[no_sites,4])
        on_surf = is_localized_state(wf,sites,range(7)+range(no_sites-7,no_sites),treshold=.6)
        
        # incoming modes have negative veloctiy
        if v<0:
            if on_surf:
                in_dict["surf"].append(i)
            else:
                in_dict["bulk"].append(i)
        elif v>0:
            if on_surf:
                out_dict["surf"].append(i-nhalf)
            else:
                out_dict["bulk"].append(i-nhalf)
        else:
            raise ValueError( "There was a mode wih zero velocity" )
            
    return in_dict, out_dict


""" 3.5 Supercurrent """
def supercurrent(fsys,p,wx_sc_left,wx_wsm,wx_sc_right,k=0,details=False):
    jz_wsm = p.tzp*np.cos(p.kz)*s2s0 + p.tz*np.sin(p.kz)*s1s0
    jz_sc  = p.tzp*np.sin(p.kz)*s0s0

    OP_space_L = sp.identity( wx_sc_left, dtype=np.complex_)
    OP_space_M = sp.identity( wx_wsm, dtype=np.complex_)
    OP_space_R = sp.identity( wx_sc_right, dtype=np.complex_)

    OP_L = sp.kron( OP_space_L,jz_sc )
    OP_M = sp.kron( OP_space_M,jz_wsm )
    OP_R = sp.kron( OP_space_R,jz_sc )

    # eigensystem
    if k>0:
        # eigensystem
        ham = fsys.hamiltonian_submatrix( args=([p]),sparse=True )
        ens,vecsT = lag.eigsh( ham,k=k,return_eigenvectors=True,\
                               which='LM',sigma=0, tol=10**(-6) )
    else:
        ham = fsys.hamiltonian_submatrix( args=([p]),sparse=False )
        ens,vecsT = np.linalg.eig(ham)
    vecs=vecsT.T

    # current
    if details:
        Js=[]
    else:
        J=0
    for n in range(len(ens)):
        wf_raw = vecs[n]
        en = ens[n]
        if en<=0:
            wf=np.reshape(wf_raw,(len(fsys.sites),4))
            wf_ordered = [x for (x,y) in sorted( zip(wf,fsys.sites), \
                                                 key=lambda (x,y): [y.family.name,y.pos[0]] ) ]
            wf_L = np.reshape( wf_ordered[:wx_sc_left], (wx_sc_left*4) )
            wf_M = np.reshape( wf_ordered[wx_sc_left:wx_sc_left+wx_wsm], (wx_wsm*4) )
            wf_R = np.reshape( wf_ordered[wx_sc_left+wx_wsm:wx_sc_left+wx_wsm+wx_sc_right], \
                               (wx_sc_right*4) )
            #len(wf_L),len(wf_M),len(wf_R)
            term_e = np.vdot( wf_L, OP_L.dot(wf_L) ) + np.vdot( wf_M, OP_M.dot(wf_M) ) \
                     + np.vdot( wf_R, OP_R.dot(wf_R) )
            if details:
                Js.append( [en, term_e] )
            else:
                J += term_e
    if details:
        return Js
    else:
        return J



""" 3.5 Supercurrent """
def supercurrent_v2(fsys,p,wx_sc_left,wx_wsm,wx_sc_right,k=0,details=False):
    jz_wsm_e = p.tzp*np.cos(p.kz)*s2s0 + p.tz*np.sin(p.kz)*s1s0
    jz_wsm_h = - p.tzp*np.cos(p.kz)*s2s0 - p.tz*np.sin(p.kz)*s1s0

    jz_sc_e  = p.tzp*np.sin(p.kz)*s0s0
    jz_sc_h  = -p.tzp*np.sin(p.kz)*s0s0

    OP_space_L = sp.identity( wx_sc_left, dtype=np.complex_)
    OP_space_M = sp.identity( wx_wsm, dtype=np.complex_)
    OP_space_R = sp.identity( wx_sc_right, dtype=np.complex_)

    OP_L_e = sp.kron( OP_space_L,jz_sc_e )
    OP_M_e = sp.kron( OP_space_M,jz_wsm_e )
    OP_R_e = sp.kron( OP_space_R,jz_sc_e )

    OP_L_h = sp.kron( OP_space_L,jz_sc_h )
    OP_M_h = sp.kron( OP_space_M,jz_wsm_h )
    OP_R_h = sp.kron( OP_space_R,jz_sc_h )

    # eigensystem
    if k>0:
        # eigensystem
        ham = fsys.hamiltonian_submatrix( args=([p]),sparse=True )
        ens,vecsT = lag.eigsh( ham,k=k,return_eigenvectors=True,\
                               which='LM',sigma=0, tol=10**(-6) )
    else:
        ham = fsys.hamiltonian_submatrix( args=([p]),sparse=False )
        ens,vecsT = np.linalg.eig(ham)
    vecs=vecsT.T
    
    for vec in vecs:
        if abs(np.vdot( vec,vec )-1)>10**(-6):
            raise ValueError( "wave functions are not normalized" )

    # current
    if details:
        Js=[]
    else:
        J=0
    for n in range(len(ens)):
        wf_raw = vecs[n]
        en = ens[n]

        if en>0:
            wf=np.reshape(wf_raw,(len(fsys.sites),4))
            wf_ordered = [x for (x,y) in sorted( zip(wf,fsys.sites), \
                                                 key=lambda (x,y): [y.family.name,y.pos[0]] ) ]

            wf_L_e = np.reshape( wf_ordered[                 :wx_sc_left], (wx_sc_left*4) )
            wf_M_e = np.reshape( wf_ordered[wx_sc_left       :wx_sc_left+wx_wsm], (wx_wsm*4) )
            wf_R_e = np.reshape( wf_ordered[wx_sc_left+wx_wsm:wx_sc_left+wx_wsm+wx_sc_right], \
                                 (wx_sc_right*4) )
        
            x_h=wx_sc_left+wx_wsm+wx_sc_right
            wf_L_h = np.reshape( wf_ordered[x_h                  :x_h+wx_sc_left], (wx_sc_left*4) )
            wf_M_h = np.reshape( wf_ordered[x_h+wx_sc_left       :x_h+wx_sc_left+wx_wsm], (wx_wsm*4) )
            wf_R_h = np.reshape( wf_ordered[x_h+wx_sc_left+wx_wsm:x_h+wx_sc_left+wx_wsm+wx_sc_right], \
                                 (wx_sc_right*4) )

            term_e = np.vdot( wf_L_e, OP_L_e.dot(wf_L_e) ) + np.vdot( wf_M_e, OP_M_e.dot(wf_M_e) ) \
                     + np.vdot( wf_R_e, OP_R_e.dot(wf_R_e) )
            term_h = np.vdot( wf_L_h, OP_L_h.dot(wf_L_h) ) + np.vdot( wf_M_h, OP_M_h.dot(wf_M_h) ) \
                     + np.vdot( wf_R_h, OP_R_h.dot(wf_R_h) )

            if details:
                Js.append( [en,-( term_e-term_h )/2.] )
            else:
                J += -( term_e-term_h )/2.
    if details:
        return Js
    else:
        return J



""" 4. DATA STORAGE """

""" 4.1 make a simple namespace with parameters of system """
def make_p( **kwargs ):
    p = SimpleNamespace()
    p.__dict__.update(kwargs)
    return p



""" 5. VISUALIZATION """

""" 5.1 function that plots the lattice with onsite-energies and hoppings """
def plot_system(sys,fsys,p,L=6,H=4):
    mysites = fsys.sites
        
    def onsite(s1):
        i=0; ni=0
        for s in mysites:
            if s==s1:
                i=ni
            ni+=1

        a= fsys.hamiltonian_submatrix( args=([p]),to_sites=[i],from_sites=[i] )
        el = a[0][0]
        return 10*np.log(el)

    def hop(s1,s2):
        i=0; j=0; ni=0
        for s in mysites:
            if s==s1:
                i=ni
            if s==s2:
                j=ni
            ni+=1

        pdiff = s2.pos-s1.pos
        if np.all( [diff>=0 for diff in pdiff] ):
            a= fsys.hamiltonian_submatrix( args=([p]),to_sites=[i],from_sites=[j] )
        else:
            a= fsys.hamiltonian_submatrix( args=([p]),to_sites=[j],from_sites=[i] )
        v = (1,0,1,1)
        v2 = np.dot(a,v)
        q  = np.vdot(v,v2)
    
        return abs(q)

    fig, (ax11) = plt.subplots(1,1,figsize=(L,H) )
    kwant.plotter.plot( sys,site_size=onsite,hop_color=hop,ax=ax11)



""" 6. DISCARDED FUNCTIONS """


def calc_ens_special(fsys,p,no_states=10):
    ham_sparse_coo = fsys.hamiltonian_submatrix( args=([p]),sparse=True )
    ham_sparse = ham_sparse_coo.tocsc()
    evals,evecsT = lag.eigsh( ham_sparse,k=no_states,return_eigenvectors=True, \
                              which='LM',sigma=0, tol=10**(-3) )
    evecs=evecsT.T

    sites=[ s.pos[0] for s in fsys.sites ]
    families=[ s.family.name for s in fsys.sites ]
    # separate bulk from vacuum-wsm and wsm-sc edge states
    ens=[]; polarizations=[];
    for n in range(no_states):
            
        wf=np.reshape(evecs[n],(len(sites),4))
        en=evals[n]
        e_w,h_w=get_e_h_weights(wf,families)

        ens.append(en)
        polarizations.append(e_w-h_w)

    return ens,polarizations
 


def calc_ens_special_2(fsys,p,no_states=10):
    ham_sparse_coo = fsys.hamiltonian_submatrix( args=([p]),sparse=True )
    ham_sparse = ham_sparse_coo.tocsc()
    evals,evecsT = lag.eigsh( ham_sparse,k=no_states,return_eigenvectors=True,which='LM',sigma=0, tol=10**(-3) )
    evecs=evecsT.T

    sites=[ s.pos[0] for s in fsys.sites ]
    families=[ s.family.name for s in fsys.sites ]
    # separate bulk from vacuum-wsm and wsm-sc edge states
    ens=[]; polarizations=[];
    for n in range(no_states):
            
        wf=np.reshape(evecs[n],(len(sites),2))
        en=evals[n]
        e_w,h_w=e_w,h_w=get_e_h_weights(wf,families)

        ens.append(en)
        polarizations.append(e_w-h_w)

    return ens,polarizations
